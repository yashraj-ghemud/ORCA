import { describe, expect, test } from "bun:test";
import {
  distanceKm,
  bearingBetween,
  compass16,
  pointInPolygon,
  intersectsHazard,
  nearestPFZ,
  beyondBoundary,
  geojsonRingToLatLng,
} from "../../src/services/risk/geospatial";

describe("haversine distance (§29)", () => {
  test("Mumbai → Pune ≈ 119 km", () => {
    const d = distanceKm({ lat: 18.92, lon: 72.83 }, { lat: 18.52, lon: 73.86 });
    expect(d).toBeGreaterThan(105);
    expect(d).toBeLessThan(130);
  });

  test("zero distance", () => {
    expect(distanceKm({ lat: 15, lon: 70 }, { lat: 15, lon: 70 })).toBe(0);
  });

  test("1 degree latitude ≈ 111 km", () => {
    const d = distanceKm({ lat: 10, lon: 75 }, { lat: 11, lon: 75 });
    expect(d).toBeGreaterThan(110);
    expect(d).toBeLessThan(112);
  });
});

describe("bearing", () => {
  test("north/east bearings", () => {
    expect(bearingBetween({ lat: 10, lon: 75 }, { lat: 11, lon: 75 })).toBeCloseTo(0, 0);
    expect(bearingBetween({ lat: 10, lon: 75 }, { lat: 10, lon: 76 })).toBeCloseTo(90, 0);
    expect(compass16(bearingBetween({ lat: 10, lon: 75 }, { lat: 10.7, lon: 75.7 }))).toBe("NE");
  });
});

describe("point-in-polygon", () => {
  const square: [number, number][] = [
    [10, 70],
    [10, 72],
    [12, 72],
    [12, 70],
  ];

  test("inside / outside", () => {
    expect(pointInPolygon(11, 71, square)).toBe(true);
    expect(pointInPolygon(13, 71, square)).toBe(false);
    expect(pointInPolygon(11, 73, square)).toBe(false);
  });

  test("geojson ring conversion ([lng,lat] → [lat,lng])", () => {
    const gj: [number, number][] = [
      [70, 10],
      [72, 10],
      [72, 12],
      [70, 12],
    ];
    const ring = geojsonRingToLatLng(gj);
    expect(pointInPolygon(11, 71, ring)).toBe(true);
  });
});

describe("hazard intersection", () => {
  test("circle hazard", () => {
    const h = { center: { lat: 19, lon: 72.5 }, radiusKm: 30 };
    expect(intersectsHazard({ lat: 19.05, lon: 72.55 }, h).hit).toBe(true);
    const r = intersectsHazard({ lat: 20.5, lon: 72.5 }, h);
    expect(r.hit).toBe(false);
    expect(r.distanceKm).toBeGreaterThan(100);
  });

  test("polygon hazard", () => {
    const h = {
      polygonRings: [
        [
          [10, 70],
          [10, 72],
          [12, 72],
          [12, 70],
        ] as [number, number][],
      ],
    };
    expect(intersectsHazard({ lat: 11, lon: 71 }, h).hit).toBe(true);
    expect(intersectsHazard({ lat: 14, lon: 71 }, h).hit).toBe(false);
  });
});

describe("nearest PFZ by distance (§14)", () => {
  test("picks the closest advisory", () => {
    const list = [
      { latitude: 12.0, longitude: 80.2 },
      { latitude: 12.6, longitude: 80.4 },
    ];
    const best = nearestPFZ({ lat: 12.5, lon: 80.3 }, list);
    expect(best?.advisory).toBe(list[1]);
    expect(best!.distanceKm).toBeLessThan(30);
  });

  test("empty list → null", () => {
    expect(nearestPFZ({ lat: 12, lon: 80 }, [])).toBeNull();
  });
});

describe("prototype boundary side check", () => {
  const boundary: [number, number][] = [
    [19.1, 72.55],
    [18.18, 72.92],
  ];
  const shoreRef = { lat: 19.0, lon: 72.85 }; /* shore side of the line */

  test("seaward point detected as beyond", () => {
    const seaPoint = { lat: 18.5, lon: 72.0 }; /* west of the line = seaward */
    const r = beyondBoundary(seaPoint, boundary, shoreRef);
    expect(r.beyond).toBe(true);
  });

  test("shore-side point is not beyond", () => {
    const r = beyondBoundary({ lat: 19.05, lon: 72.87 }, boundary, shoreRef);
    expect(r.beyond).toBe(false);
  });
});
