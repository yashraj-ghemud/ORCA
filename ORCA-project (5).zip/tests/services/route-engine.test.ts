import { describe, expect, test } from "bun:test";
import { computeSaferRoute } from "../../src/services/risk/route-engine";
import { VESSEL_PROFILES } from "../../src/services/risk/profiles";
import { distanceKm } from "../../src/services/risk/geospatial";

const mech = VESSEL_PROFILES.mechanised;

/* deterministic sampler: calm sea everywhere */
const calm = async () => ({ wave: 0.8, wind: 5, gust: 6, current: 0.2 });

/* sampler that injects a wall of dangerous cells along the direct path */
function stormWall(stormLon: number) {
  return async (lat: number, lon: number) => {
    const nearWall = Math.abs(lon - stormLon) < 0.02;
    return {
      wave: nearWall ? 4.5 : 0.8,
      wind: nearWall ? 18 : 5,
      gust: nearWall ? 22 : 6,
      current: 0.2,
    };
  };
}

describe("A* route engine (§15, §16, §29)", () => {
  test("finds a path through calm seas", async () => {
    const r = await computeSaferRoute({
      start: { lat: 18.9, lon: 72.8 },
      goal: { lat: 18.75, lon: 72.95 },
      profile: mech,
      sampleMarineFn: calm,
    });
    expect(r.status).toBe("FOUND");
    expect(r.points.length).toBeGreaterThanOrEqual(2);
    expect(r.distanceKm).toBeGreaterThan(5);
    expect(r.estimatedTravelTimeHours).toBeGreaterThan(0);
    /* endpoints near start & goal */
    const first = r.points[0];
    const last = r.points[r.points.length - 1];
    expect(distanceKm({ lat: first[0], lon: first[1] }, { lat: 18.9, lon: 72.8 })).toBeLessThan(10);
    expect(distanceKm({ lat: last[0], lon: last[1] }, { lat: 18.75, lon: 72.95 })).toBeLessThan(10);
  });

  test("routes through the gap in a hazard wall (A* detour behaviour)", async () => {
    /* two blocked strips at lon≈72.9 leaving a gap between lat 18.94–19.02 */
    const wallLow: [number, number][] = [
      [18.72, 72.88],
      [18.72, 72.92],
      [18.94, 72.92],
      [18.94, 72.88],
    ];
    const wallHigh: [number, number][] = [
      [19.02, 72.88],
      [19.02, 72.92],
      [19.08, 72.92],
      [19.08, 72.88],
    ];
    const r = await computeSaferRoute({
      start: { lat: 18.9, lon: 72.75 },
      goal: { lat: 18.9, lon: 73.05 },
      profile: mech,
      sampleMarineFn: calm,
      hazardRings: [wallLow, wallHigh],
    });
    expect(r.status).toBe("FOUND");
    /* the wall line may only be crossed inside the gap */
    for (const [lat, lon] of r.points) {
      if (Math.abs(lon - 72.9) < 0.02) {
        expect(lat).toBeGreaterThanOrEqual(18.92);
        expect(lat).toBeLessThanOrEqual(19.04);
      }
    }
    /* detour: path longer than the straight-line distance */
    const direct = distanceKm({ lat: 18.9, lon: 72.75 }, { lat: 18.9, lon: 73.05 });
    expect(r.distanceKm).toBeGreaterThanOrEqual(Math.round(direct));
  });

  test("NO_SAFE_PATH when the goal is sealed inside a hazard ring", async () => {
    const ring: [number, number][] = [
      [18.86, 73.0],
      [18.86, 73.12],
      [18.94, 73.12],
      [18.94, 73.0],
    ];
    const r = await computeSaferRoute({
      start: { lat: 18.9, lon: 72.8 },
      goal: { lat: 18.9, lon: 73.06 },
      profile: mech,
      sampleMarineFn: calm,
      hazardRings: [ring],
    });
    expect(r.status).toBe("NO_SAFE_PATH");
    expect(r.points.length).toBe(0);
    expect(r.explanation.length).toBeGreaterThan(0);
  });

  test("boundary blocks seaward cells (entry prohibited)", async () => {
    const boundary = {
      points: [
        [18.98, 72.7] as [number, number],
        [18.82, 73.1] as [number, number],
      ],
      label: "test boundary",
    };
    /* goal is on the seaward (west) side of the boundary */
    const r = await computeSaferRoute({
      start: { lat: 18.95, lon: 73.0 },
      goal: { lat: 18.88, lon: 72.72 },
      profile: mech,
      boundary,
      sampleMarineFn: calm,
    });
    expect(r.status).toBe("NO_SAFE_PATH");
  });
});
