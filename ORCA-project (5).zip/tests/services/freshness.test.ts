import { describe, expect, test } from "bun:test";
import { getFreshnessStatus, humanizeAge, formatIst } from "../../src/services/marine/freshness";

const NOW = new Date("2026-09-04T06:00:00Z");

describe("freshness calculation (§6)", () => {
  test("fresh within TTL", () => {
    const r = getFreshnessStatus({
      observedAt: "2026-09-04T05:30:00Z",
      ttlKey: "openmeteo_marine",
      now: NOW,
    });
    expect(r.status).toBe("fresh");
    expect(r.level).toBe("FRESH");
    expect(r.freshnessSeconds).toBe(1800);
  });

  test("recent between fresh and stale TTL", () => {
    const r = getFreshnessStatus({
      observedAt: "2026-09-04T02:30:00Z",
      ttlKey: "openmeteo_marine",
      now: NOW,
    });
    expect(r.status).toBe("recent");
  });

  test("stale beyond TTL", () => {
    const r = getFreshnessStatus({
      observedAt: "2026-09-03T06:00:00Z",
      ttlKey: "openmeteo_marine",
      now: NOW,
    });
    expect(r.status).toBe("stale");
    expect(r.level).toBe("STALE");
  });

  test("validUntil in the past → stale", () => {
    const r = getFreshnessStatus({
      retrievedAt: "2026-09-04T05:00:00Z",
      validUntil: "2026-09-04T01:00:00Z",
      now: NOW,
    });
    expect(r.status).toBe("stale");
  });

  test("missing timestamps → unavailable", () => {
    const r = getFreshnessStatus({ now: NOW });
    expect(r.status).toBe("unavailable");
    expect(r.level).toBe("UNAVAILABLE");
  });
});

describe("display helpers", () => {
  test("humanizeAge", () => {
    expect(humanizeAge(30)).toBe("just now");
    expect(humanizeAge(240)).toBe("4 min ago");
    expect(humanizeAge(7200)).toBe("2 h ago");
  });

  test("formatIst renders IST", () => {
    const s = formatIst("2026-09-04T06:00:00Z");
    expect(s).toContain("IST");
    expect(s).toContain("11:30");
  });

  test("formatIst null-safe", () => {
    expect(formatIst(undefined)).toBeNull();
  });
});
