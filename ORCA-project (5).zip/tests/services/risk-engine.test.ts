import { describe, expect, test } from "bun:test";
import { evaluateMarineRisk } from "../../src/services/risk/risk-engine";
import { VESSEL_PROFILES } from "../../src/services/risk/profiles";
import type { MarineContext } from "../../src/services/marine/types";
import {
  baseContext,
  mumbaiHighRisk,
  keralaLowRisk,
  insufficientData,
  staleData,
  TEST_NOW,
} from "../fixtures/marine";

const small = VESSEL_PROFILES.small_fibre;
const mech = VESSEL_PROFILES.mechanised;

function withWarnings(ctx: MarineContext, severity: "warning" | "watch" | "advisory"): MarineContext {
  return {
    ...ctx,
    warnings: {
      fishermen: [
        {
          id: "imd-1",
          title: "Squally weather warning",
          severity,
          source: "IMD",
        },
      ],
    },
    sourceMeta: [
      ...ctx.sourceMeta,
      { source: "IMD", kind: "fishermen_warning", retrievedAt: TEST_NOW, status: "fresh" },
    ],
  };
}

describe("risk rules (§11, §22)", () => {
  test("high waves + strong wind → HIGH", () => {
    const { context, profile } = mumbaiHighRisk();
    const r = evaluateMarineRisk({ context, vesselProfile: profile });
    expect(r.level).toBe("HIGH");
    expect(r.blocked).toBe(false);
    expect(r.dataQuality).toBe("GOOD");
    expect(r.reasons.some((x) => x.code.startsWith("wave") || x.code.startsWith("wind"))).toBe(true);
  });

  test("calm conditions → LOW", () => {
    const { context, profile } = keralaLowRisk();
    const r = evaluateMarineRisk({ context, vesselProfile: profile });
    expect(r.level).toBe("LOW");
  });

  test("official IMD warning dominates → CRITICAL + blocked", () => {
    const { context, profile } = keralaLowRisk();
    const r = evaluateMarineRisk({ context: withWarnings(context, "warning"), vesselProfile: profile });
    expect(r.level).toBe("CRITICAL");
    expect(r.blocked).toBe(true);
    expect(r.reasons[0].code).toBe("official_warning");
  });

  test("watch-level warning also escalates to CRITICAL (authoritative)", () => {
    const { context, profile } = keralaLowRisk();
    const r = evaluateMarineRisk({ context: withWarnings(context, "watch"), vesselProfile: profile });
    expect(r.level).toBe("CRITICAL");
  });

  test("missing marine data → UNKNOWN, never LOW", () => {
    const { context, profile } = insufficientData();
    const r = evaluateMarineRisk({ context, vesselProfile: profile });
    expect(r.level).toBe("UNKNOWN");
    expect(r.dataQuality).toBe("INSUFFICIENT");
  });

  test("stale data caps LOW at MODERATE and flags quality", () => {
    const { context, profile } = staleData();
    const r = evaluateMarineRisk({ context, vesselProfile: profile });
    expect(r.dataQuality).toBe("STALE");
    expect(r.level).not.toBe("LOW");
  });

  test("small boat profile is stricter than mechanised", () => {
    const ctx = baseContext({ ocean: { waveHeightM: 1.8 } });
    const rSmall = evaluateMarineRisk({ context: ctx, vesselProfile: small });
    const rMech = evaluateMarineRisk({ context: ctx, vesselProfile: mech });
    expect(rSmall.level).toBe("HIGH");
    expect(["MODERATE", "LOW"]).toContain(rMech.level);
  });

  test("cyclone within profile advisory distance → escalation", () => {
    const { context, profile } = keralaLowRisk();
    const ctx: MarineContext = {
      ...context,
      warnings: {
        cyclone: [
          {
            id: "cy-1",
            name: "TestCyclone",
            position: { lat: 10.3, lon: 76.0 },
            source: "IMD",
          },
        ],
      },
    };
    const r = evaluateMarineRisk({ context: ctx, vesselProfile: profile });
    expect(["HIGH", "MODERATE"]).toContain(r.level);
    expect(r.reasons.some((x) => x.code.startsWith("cyclone"))).toBe(true);
  });

  test("cyclone inside official polygon → CRITICAL", () => {
    const { context, profile } = keralaLowRisk();
    const ctx: MarineContext = {
      ...context,
      warnings: {
        cyclone: [
          {
            id: "cy-2",
            name: "ConeTest",
            position: { lat: 10.0, lon: 75.8 },
            warningGeometry: {
              type: "Polygon",
              coordinates: [
                [
                  [75.6, 9.8],
                  [76.0, 9.8],
                  [76.0, 10.2],
                  [75.6, 10.2],
                  [75.6, 9.8],
                ],
              ],
            },
            source: "IMD",
          },
        ],
      },
    };
    const r = evaluateMarineRisk({ context: ctx, vesselProfile: profile });
    expect(r.level).toBe("CRITICAL");
    expect(r.blocked).toBe(true);
  });
});
