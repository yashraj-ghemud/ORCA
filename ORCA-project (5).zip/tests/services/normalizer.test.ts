import { describe, expect, test } from "bun:test";
import {
  kmhToMps,
  mpsToKmh,
  knotsToMps,
  fToC,
  num,
  round,
  degToCompass,
  wmoCondition,
} from "../../src/services/marine/normalizer";

describe("unit conversion (§28)", () => {
  test("km/h → m/s", () => {
    expect(kmhToMps(36)).toBe(10);
    expect(kmhToMps(0)).toBe(0);
    expect(kmhToMps(null)).toBeUndefined();
    expect(kmhToMps(undefined)).toBeUndefined();
  });

  test("m/s → km/h", () => {
    expect(mpsToKmh(10)).toBe(36);
    expect(mpsToKmh(5.14)).toBe(18.5);
  });

  test("knots → m/s", () => {
    expect(knotsToMps(20)).toBeCloseTo(10.29, 1);
    expect(knotsToMps(0)).toBe(0);
  });

  test("°F → °C", () => {
    expect(fToC(32)).toBe(0);
    expect(fToC(100)).toBeCloseTo(37.8, 1);
  });

  test("num guards sentinels and non-finite", () => {
    expect(num(-9999, 0, 100)).toBeUndefined();
    expect(num(NaN)).toBeUndefined();
    expect(num(Infinity)).toBeUndefined();
    expect(num(50, 0, 100)).toBe(50);
  });

  test("round keeps undefined", () => {
    expect(round(1.234, 1)).toBe(1.2);
    expect(round(null, 1)).toBeUndefined();
  });
});

describe("direction + WMO codes", () => {
  test("degToCompass 16-point", () => {
    expect(degToCompass(0)).toBe("N");
    expect(degToCompass(90)).toBe("E");
    expect(degToCompass(135)).toBe("SE");
    expect(degToCompass(359)).toBe("N");
    expect(degToCompass(null)).toBeUndefined();
  });

  test("WMO code bilingual", () => {
    expect(wmoCondition(0)).toBe("Clear sky");
    expect(wmoCondition(95, "hi")).toBe("आंधी-तूफ़ान");
    expect(wmoCondition(999)).toBeUndefined();
  });
});
