/**
 * Fixed test fixtures (§29) — deterministic marine snapshots for the four
 * monitored locations. Values are TEST FIXTURES, not live data and not
 * claims about real conditions.
 */

import type { MarineContext, VesselSafetyProfile } from "../../src/services/marine/types";
import { VESSEL_PROFILES } from "../../src/services/risk/profiles";

const NOW = "2026-09-04T06:00:00Z"; /* 11:30 IST */

export function baseContext(overrides: Partial<MarineContext> = {}): MarineContext {
  return {
    location: { lat: 18.92, lon: 72.83, name: "Test Coast" },
    observedAt: NOW,
    forecastFor: undefined,
    weather: {
      windSpeedMps: 6,
      windDirectionDeg: 250,
      gustSpeedMps: 8,
      temperatureC: 29,
      visibilityKm: 8,
      pressureHpa: 1008,
    },
    ocean: {
      waveHeightM: 1.0,
      wavePeriodS: 7,
      swellHeightM: 0.8,
      sstC: 28.5,
    },
    warnings: {},
    pfz: undefined,
    sourceMeta: [
      {
        source: "OPEN_METEO",
        kind: "ocean_forecast",
        retrievedAt: NOW,
        observedAt: NOW,
        status: "fresh",
      },
      {
        source: "OPEN_METEO",
        kind: "weather_forecast",
        retrievedAt: NOW,
        observedAt: NOW,
        status: "fresh",
      },
    ],
    targetTime: NOW,
    boundary: {
      points: [
        [19.1, 72.55],
        [18.45, 72.62],
        [18.18, 72.92],
      ],
      label: "prototype boundary",
    },
    ...overrides,
  };
}

/** Mumbai-like: high waves + strong wind → HIGH */
export function mumbaiHighRisk(profile: VesselSafetyProfile = VESSEL_PROFILES.mechanised) {
  return {
    context: baseContext({
      ocean: { waveHeightM: 3.2, wavePeriodS: 9, swellHeightM: 2.6, sstC: 29.4 },
      weather: { windSpeedMps: 12, windDirectionDeg: 45, gustSpeedMps: 16, visibilityKm: 4 },
    }),
    profile,
  };
}

/** Kerala-like: calm → LOW */
export function keralaLowRisk(profile: VesselSafetyProfile = VESSEL_PROFILES.mechanised) {
  return {
    context: baseContext({
      location: { lat: 9.98, lon: 75.83, name: "Kerala Test" },
      ocean: { waveHeightM: 1.1, wavePeriodS: 8, swellHeightM: 0.9, sstC: 28.9 },
      weather: { windSpeedMps: 4, windDirectionDeg: 250, gustSpeedMps: 5, visibilityKm: 9 },
    }),
    profile,
  };
}

/** Missing marine data → UNKNOWN */
export function insufficientData(profile: VesselSafetyProfile = VESSEL_PROFILES.small_fibre) {
  return {
    context: baseContext({
      weather: undefined,
      ocean: undefined,
      sourceMeta: [
        {
          source: "OPEN_METEO",
          kind: "ocean_forecast",
          retrievedAt: NOW,
          status: "unavailable",
          note: "rate limited",
        },
      ],
    }),
    profile,
  };
}

/** Stale sources → quality STALE, conclusion capped */
export function staleData(profile: VesselSafetyProfile = VESSEL_PROFILES.mechanised) {
  const old = "2026-09-03T06:00:00Z";
  return {
    context: baseContext({
      observedAt: old,
      sourceMeta: [
        {
          source: "OPEN_METEO",
          kind: "ocean_forecast",
          retrievedAt: old,
          observedAt: old,
          status: "stale",
        },
        {
          source: "OPEN_METEO",
          kind: "weather_forecast",
          retrievedAt: old,
          observedAt: old,
          status: "stale",
        },
      ],
    }),
    profile,
  };
}

export const TEST_NOW = NOW;
