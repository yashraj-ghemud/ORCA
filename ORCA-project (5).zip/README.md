# ORCA — Marine Intelligence Platform

A split-screen marine decision-support assistant: **chat (35%) + interactive Leaflet map (65%)**.
Ask ORCA about sailing safety, fishing zones (PFZ), hazards, routes and sea conditions —
tap any ocean spot for an instant spot-check card, and use your **voice** (mic input +
spoken briefings). English + Hindi supported.

ORCA runs in two data modes (**Demo / Live** toggle in the header, default **live**):

- **Live mode** — real normalized data from external sources, a deterministic risk
  engine, geospatial hazard checks and an A* lower-risk route engine.
- **Demo mode** — the original simulated dataset (clearly labeled DEMO DATA) for
  presentations and offline demos. Demo and live values are never mixed.

> ⚠️ ORCA is a safety-oriented **prototype**. It never claims certainty: model data is
> labeled "(model)", official warnings are attributed to their source, and missing or
> stale data produces explicit degraded states ("INSUFFICIENT DATA", "stale",
> "PFZ advisory unavailable") instead of invented values.

---

## Live data integration status (honest disclosure)

| Source | Role | Status | How to enable |
|---|---|---|---|
| **Open-Meteo Marine + Weather** | Free marine/weather **model** (fallback/supplement) | ✅ **Working** (key-less) — waves, swell, period, SST, currents, wind, gusts | Works out of the box; base URLs configurable via `OPEN_METEO_*` |
| **IMD** (imdapi.org) | AUTHORITATIVE warnings: fishermen / coastal / sea-area bulletins, cyclone track + cone | ⚙️ Adapter ready — requires **official subscription**; until connected a clearly-labeled **DEMO (simulated)** substitute fills the gap | Set `IMD_API_BASE_URL` + `IMD_API_KEY` (verify paths against current IMD docs) |
| **INCOIS OSF** | AUTHORITATIVE ocean state forecast | ⚙️ Adapter ready — **no verified public JSON API** (GIS/bulletin products); Open-Meteo covers the gap as labeled model data | Set `INCOIS_API_BASE_URL` with an official data interface |
| **INCOIS PFZ** | AUTHORITATIVE Potential Fishing Zone advisories | ⚙️ Adapter ready — same access situation; until connected a clearly-labeled **DEMO (simulated)** zone set is shown | Same env; set `DEMO_FALLBACK=off` for strict "unavailable" states instead |

**Demo substitution (`DEMO_FALLBACK`, default `on`):** when an official source is not
configured, ORCA generates a deterministic simulated scenario (demo cyclone with track,
demo fishermen/coastal advisories, demo PFZ zones) so the map stays rich. Every demo
object is flagged end-to-end and labeled — "DEMO · simulated" chips in DATA SOURCES,
"Cyclone (DEMO)" on the map, "DEMO ADVISORY (SIMULATED)" toasts — and demo data can
never trigger an official-warning CRITICAL (capped at HIGH/MODERATE with explicit
"demo scenario" reasons).

Source priority is enforced server-side: official IMD warnings can never be overwritten
by the Open-Meteo fallback, INCOIS ocean data takes precedence over the model, and PFZ
comes only from INCOIS. Probe the current status any time:

```bash
curl "http://localhost:3000/api/marine/status?probe=1"
bun run test:marine   # live integration check for all enabled providers
```

## Architecture

```
Frontend (chat + map UI, unchanged shapes)
  → POST /api/orca/query        (all secrets stay server-side)
    → services/marine/*         source adapters + normalizer + freshness + cache
    → MarineContext             canonical, unit-normalized snapshot (m/s, m, °C, km, ISO UTC)
    → services/risk/*           deterministic risk engine · cyclone proximity ·
                                polygon hazards · nearest-PFZ · A* route engine
    → OrcaResponse + mapData    UI-compatible response + dynamic layers + provenance
```

Key server modules:

- `src/services/marine/` — `types` (canonical model), `imd`, `incois`, `pfz`, `openMeteo`
  adapters, `demo-fallback` (labeled simulated substitutes), `normalizer` (units/WMO/compass),
  `freshness` (fresh/recent/stale TTLs), `cache` (TTL + bucketed keys, no negative-caching),
  `index` (`getMarineContext`).
- `src/services/risk/` — `geospatial` (haversine, bearing, point-in-polygon, boundary
  side check), `cyclone` (track/forecast proximity + official polygon intersection),
  `risk-engine` (deterministic rules over a configurable `VesselSafetyProfile` —
  thresholds are labeled **prototype safety policy**), `route-engine` (A* over a bounded
  marine grid with wave/wind/current/cyclone/boundary costs and blocked cells),
  `profiles` (small fibre / mechanised / larger vessel presets).
- `src/services/orca/query-service.ts` — intent → context → risk → response + map data;
  bilingual, honesty-enforced wording ("Suggested lower-risk path", "Based on available data").
- `src/lib/demo-data/mock-marine-data.ts` — the original simulated dataset (demo mode only).

## Features

- **Safety checks** — deterministic risk verdict (LOW / MODERATE / HIGH / CRITICAL / UNKNOWN)
  with evidence, reasons and data-quality flag
- **Potential Fishing Zones** — official INCOIS PFZ geometry when available; a clearly
  labeled DEMO zone set otherwise
- **Cyclone intelligence** — IMD track positions, nearest forecast point for the target
  time, geodesic distance + bearing, official warning polygon intersection (or the
  labeled demo scenario when IMD is not connected)
- **Safer routes** — real A* search over a sampled marine grid; output is always
  "suggested lower-risk path", never an absolute safety claim
- **Spot check (tap)** — tap anywhere in the sea: live model verdict or UNKNOWN when
  data is missing; demo mode keeps the simulated zones
- **Voice (STT/TTS)** — mic input with live transcription, spoken evidence-backed
  briefings, auto-speak mode (`/api/asr`, `/api/tts`)
- **Intro & motion design** — cinematic ORCA intro splash (ripple logo, staggered
  wordmark, drifting waves, once per session), map fly-in on load, staggered
  entrance animations, count-up condition values, animated zone/route layer reveals
- **Provenance everywhere** — "DATA SOURCES" expander on every answer, source chips on
  the map, freshness ("IMD · updated 4 min ago", "Open-Meteo · model updated 10:00 IST",
  "DEMO · simulated")
- **Honest error states** — source unavailable, stale, rate-limited, no PFZ, no safe
  path, insufficient data — never silently fabricated
- **Bilingual UI** — full English / Hindi switch, spoken in both

## Tech Stack

| Layer | Tech |
|---|---|
| Framework | Next.js 16 (App Router) + React 19 + TypeScript |
| Styling | Tailwind CSS 4 + shadcn/ui components |
| Map | Leaflet + react-leaflet v5 |
| Voice | z-ai-web-dev-sdk (server-side ASR + TTS routes) |
| Marine data | Open-Meteo (live), IMD/INCOIS adapters (credential-gated) |
| Tests | bun:test (41 unit tests) + Playwright verification scripts |

## Getting Started

```bash
# 1. Install dependencies (bun recommended; npm/pnpm also works)
bun install

# 2. Configure sources (optional for live marine — Open-Meteo needs no key)
cp .env.example .env   # add IMD/INCOIS credentials if you have them

# 3. Set up the database (optional — app runs with mock/demo data)
bun run db:push

# 4. Start the dev server
bun run dev
# → http://localhost:3000

# Production
bun run build
bun run start
```

> Voice features (mic + TTS) call the server routes `/api/asr` and `/api/tts`,
> which use `z-ai-web-dev-sdk` — run inside an environment where the SDK is configured.
> Browsers block the microphone on insecure origins; use `localhost` or HTTPS.

## Tests

```bash
bun test            # 41 unit tests: conversions, freshness, haversine, polygons,
                    # risk rules, A* routing, missing/stale-data behaviour
bun run test:marine # live provider check — prints per-source status + freshness,
                    # skips credential-gated sources with clear messages
```

Browser verification (optional, Playwright):

```bash
bun scripts/verify_live.mjs   # 9 live-mode UI checks
bun scripts/verify_tap.mjs    # 8 tap-interaction scenarios (demo mode)
bun scripts/verify_voice.mjs  # 12 voice (STT/TTS) scenarios
```

## Project Structure

```
src/
  app/
    page.tsx               # state machine — demo pipeline + live pipeline
    api/orca/query/        # aggregate live-mode endpoint
    api/marine/context/    # raw normalized MarineContext (debug/tests)
    api/marine/status/     # source availability report
    api/asr/, api/tts/     # voice routes
  services/
    marine/                # adapters, normalizer, freshness, cache, aggregator
    risk/                  # geospatial, cyclone, risk-engine, route-engine, profiles
    orca/                  # query-service (response builder)
  components/
    chat/                  # ChatPanel, MessageList/Bubble (DATA SOURCES), Composer (mic)
    map/                   # MarineMap (demo + live layers), SpotCard, MapControls
    analysis/, alerts/, ui/
  lib/
    demo-data/             # simulated dataset (demo mode only)
    mock-orca.ts           # demo intent router + response builder
    i18n.ts, spot-analysis.ts, voice-client.ts, audio-record.ts, speakable.ts
  types/                   # marine.ts, orca.ts
```
