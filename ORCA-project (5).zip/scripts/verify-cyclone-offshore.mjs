/* Verify: demo cyclone must be OFFSHORE (sea-side) for every location */
const LOCATIONS = [
  { id: "mumbai", lat: 18.92, lon: 72.83, coast: "west" },
  { id: "goa", lat: 15.42, lon: 73.78, coast: "west" },
  { id: "kerala", lat: 9.98, lon: 75.83, coast: "west" },
  { id: "chennai", lat: 13.05, lon: 80.3, coast: "east" },
];

function bearingDeg(lat1, lon1, lat2, lon2) {
  const toRad = (d) => (d * Math.PI) / 180;
  const y = Math.sin(toRad(lon2 - lon1)) * Math.cos(toRad(lat2));
  const x =
    Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
    Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(toRad(lon2 - lon1));
  return (Math.atan2(y, x) * 180) / Math.PI;
}
function distKm(lat1, lon1, lat2, lon2) {
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return Math.round(6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

let pass = 0, fail = 0;
for (const L of LOCATIONS) {
  const r = await fetch(`http://localhost:3000/api/marine/map?id=${L.id}`);
  const j = await r.json();
  const cy = j?.mapData?.cyclone;
  if (!cy) { console.log(`✗ ${L.id}: no cyclone in response`); fail++; continue; }
  const c = cy.center ?? cy.position; const cLat = c.lat, cLon = c.lng ?? c.lon;
  const b = (bearingDeg(L.lat, L.lon, cLat, cLon) + 360) % 360;
  const d = distKm(L.lat, L.lon, cLat, cLon);
  /* sea-side check: west coast → cyclone must be WEST of coast (bearing 180–360); east coast → EAST (0–180) */
  const seaSide = L.coast === "west" ? b >= 180 : b < 180;
  const compass = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"][Math.round(b / 22.5) % 16];
  const ok = seaSide && d >= 60 && d <= 140;
  console.log(`${ok ? "✓" : "✗"} ${L.id}: ${cy.name} @ (${cLat}, ${cLon}) · ${d} km ${compass} · ${L.coast} coast → ${seaSide ? "OVER SEA ✓" : "ON LAND ✗"}`);
  ok ? pass++ : fail++;
  /* track points also over sea? */
  const bad = (cy.track || []).filter((p) => (L.coast === "west" ? p.lon > L.lon + 0.15 : p.lon < L.lon - 0.15));
  if (bad.length) { console.log(`  ⚠ ${bad.length} track points drift onshore`); }
}
console.log(`\nRESULT: ${pass} pass / ${fail} fail`);
process.exit(fail ? 1 : 0);
