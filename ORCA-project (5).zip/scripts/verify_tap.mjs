/**
 * ORCA — map tap spot-check verification (v2)
 * Fix: close the open card before tapping the next point (card blocks clicks).
 */
import { chromium } from "playwright";
import fs from "node:fs";

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/download/orca-review/tap";
fs.mkdirSync(OUT, { recursive: true });

const shot = async (page, name) => {
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${OUT}/${name}.png` });
  console.log("shot:", name);
};

async function canvasCenter(page) {
  const box = await page.locator(".leaflet-container").boundingBox();
  return { x: box.x + box.width / 2, y: box.y + box.height / 2 };
}

async function tapAt(page, dx, dy) {
  const c = await canvasCenter(page);
  await page.mouse.click(c.x + dx, c.y + dy);
  await page.waitForTimeout(400);
}

async function closeCard(page) {
  const x = page.locator('[role="dialog"] [aria-label="Close"]');
  if (await x.count()) {
    await x.click();
    await page.waitForTimeout(250);
  }
}

async function cardVerdict(page) {
  const t = await page.locator('[role="dialog"]').innerText();
  return t.replace(/\n+/g, " | ").slice(0, 320);
}

const run = async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));

  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForSelector(".leaflet-container", { timeout: 30000 });
  await page.waitForTimeout(2500);

  /* ---- 1. Mumbai center (vessel pos, inside hazard radius) → UNSAFE ---- */
  await tapAt(page, 0, 0);
  console.log("card1:", await cardVerdict(page));
  await shot(page, "01_mumbai_hazard_unsafe");
  await closeCard(page);

  /* ---- 2. Mumbai PFZ point → PFZ banner + verdict ---- */
  await tapAt(page, -70, 41);
  console.log("card2:", await cardVerdict(page));
  await shot(page, "02_mumbai_pfz");
  await closeCard(page);

  /* ---- 3. Mumbai safe zone (18.62,72.86) → sheltered ---- */
  await tapAt(page, 14, 152);
  console.log("card3:", await cardVerdict(page));
  await shot(page, "03_mumbai_sheltered");

  /* ---- 4. Ask ORCA about this spot → chat flow ---- */
  const askBtn = page.getByRole("button", { name: /Ask ORCA about this spot/i });
  if (await askBtn.count()) {
    await askBtn.click();
    await page.waitForTimeout(5200);
    await shot(page, "04_ask_orca_response");
  } else {
    console.log("WARN: ask button not found");
  }

  /* ---- 5. Kerala open sea → SAFE ---- */
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".leaflet-container", { timeout: 30000 });
  await page.waitForTimeout(1800);
  await page.locator('[aria-label="Location"]').click();
  await page.getByText("Kerala Coast").click();
  await page.waitForTimeout(2600);
  await tapAt(page, 160, -52);
  console.log("card5:", await cardVerdict(page));
  await shot(page, "05_kerala_open_sea_safe");
  await closeCard(page);

  /* ---- 6. Kerala beyond offshore boundary → RESTRICTED ---- */
  await tapAt(page, -459, 22);
  console.log("card6:", await cardVerdict(page));
  await shot(page, "06_kerala_restricted");

  /* ---- 7. Hindi card (Kerala, safe point) ---- */
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".leaflet-container", { timeout: 30000 });
  await page.waitForTimeout(1800);
  await page.locator('[aria-label="Location"]').click();
  await page.getByText("Kerala Coast").click();
  await page.waitForTimeout(2400);
  await page.locator('[aria-label="Language"]').click();
  await page.getByText("हिन्दी", { exact: true }).click();
  await page.waitForTimeout(600);
  await tapAt(page, 160, -52);
  console.log("card7:", await cardVerdict(page));
  await shot(page, "07_kerala_hindi_safe");

  /* ---- 8. Mobile 390px (Mumbai, tap vessel area = center) ---- */
  await page.setViewportSize({ width: 390, height: 844 });
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".leaflet-container", { timeout: 30000 });
  await page.waitForTimeout(2200);
  await page.locator(".leaflet-container").scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  const c = await canvasCenter(page);
  await page.mouse.click(c.x, c.y);
  await page.waitForTimeout(400);
  console.log("card8:", await cardVerdict(page));
  await shot(page, "08_mobile_spot_check");

  console.log("pageerrors:", errors.length ? errors : "none");
  await browser.close();
};

run().catch((e) => {
  console.error("FAILED:", e);
  process.exit(1);
});
