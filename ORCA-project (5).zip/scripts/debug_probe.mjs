import { chromium } from "playwright";

const run = async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });
  await page.waitForSelector(".leaflet-container", { timeout: 30000 });
  await page.waitForTimeout(2500);

  const box = await page.locator(".leaflet-container").boundingBox();
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  console.log("canvas box:", box, "center:", cx, cy);

  // first tap at center
  await page.mouse.click(cx, cy);
  await page.waitForTimeout(500);

  // probe what's at the offset points
  for (const [dx, dy] of [[-70, 41], [14, 152], [160, -52]]) {
    const el = await page.evaluate(([x, y]) => {
      const e = document.elementFromPoint(x, y);
      if (!e) return "null";
      const path = [];
      let n = e;
      while (n && path.length < 5) {
        path.push(`${n.tagName}.${(n.className && n.className.toString ? n.className.toString() : "").slice(0, 60)}`);
        n = n.parentElement;
      }
      return path.join(" <- ");
    }, [cx + dx, cy + dy]);
    console.log(`probe(${dx},${dy}) @${cx + dx},${cy + dy}:`, el);
  }

  await browser.close();
};
run().catch((e) => { console.error(e); process.exit(1); });
