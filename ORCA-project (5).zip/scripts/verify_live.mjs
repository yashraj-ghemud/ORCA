/**
 * Live-mode browser verification (Playwright).
 * Verifies: live empty-state strip, ask flow → response card, DATA SOURCES
 * expander, dynamic map layers, demo/live toggle, no page errors.
 *
 * Run: bun scripts/verify_live.mjs
 */

import { chromium } from "playwright";
import fs from "node:fs";

const OUT = "download/orca-review/live";
fs.mkdirSync(OUT, { recursive: true });

const results = [];
const ok = (name, pass, detail = "") => {
  results.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"} — ${name}${detail ? ` · ${detail}` : ""}`);
};

const run = async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const pageErrors = [];
  page.on("pageerror", (e) => pageErrors.push(e.message));

  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });
  await page.waitForTimeout(2500);
  await page.screenshot({ path: `${OUT}/01-live-empty.png` });

  /* 1. live strip present (MARINE DATA badge) */
  const badge = await page.getByText("MARINE DATA").count();
  ok("live badge (MARINE DATA) visible", badge > 0);

  /* 2. live strip shows real values or honest dashes */
  const strip = await page.locator("text=/Live|Data unavailable/").count();
  ok("live conditions strip", strip > 0);

  /* 3. ask a live safety query */
  await page.getByLabel(/Ask ORCA/).fill("Is it safe to sail today?");
  await page.getByLabel(/Send/).click();

  /* staged activity shows LIVE steps */
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/02-processing.png` });
  const liveStep = await page.getByText("Fetching marine conditions").count();
  ok("live processing steps shown", liveStep > 0);

  /* answer arrives */
  await page.waitForSelector("text=/MARINE RISK|MODERATE|LOW RISK|INSUFFICIENT DATA|FAVOURABLE/", { timeout: 60000 });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: `${OUT}/03-live-answer.png` });
  const answer = await page.getByText(/HIGH MARINE RISK|LOW RISK|MODERATE|INSUFFICIENT DATA/).count();
  ok("live answer card rendered", answer > 0);

  /* 4. DATA SOURCES expander */
  const ds = page.getByText("DATA SOURCES");
  if ((await ds.count()) > 0) {
    await ds.first().click();
    await page.waitForTimeout(500);
    const srcRow = await page.getByText(/OPEN_METEO|IMD/).count();
    ok("DATA SOURCES expander lists sources", srcRow > 0);
    await page.screenshot({ path: `${OUT}/04-data-sources.png` });
  } else {
    ok("DATA SOURCES expander lists sources", false, "expander not found");
  }

  /* 5. tap a sea spot → live spot card */
  await page.mouse.click(980, 320);
  await page.waitForTimeout(1200);
  const spotCard = await page.getByText(/SPOT CHECK/).count();
  if (spotCard > 0) {
    const note = await page.getByText(/Open-Meteo model estimate|Not enough live data/).count();
    ok("live spot card with source note", note > 0);
    await page.screenshot({ path: `${OUT}/05-live-spot-card.png` });
  } else {
    ok("live spot card with source note", false, "card did not open");
  }

  /* 6. demo mode toggle → DEMO DATA badge + demo vessel flow */
  await page.getByRole("switch").click();
  await page.waitForTimeout(1000);
  const demoBadge = await page.getByText("DEMO DATA").count();
  ok("demo mode toggle → DEMO DATA badge", demoBadge > 0);
  await page.screenshot({ path: `${OUT}/06-demo-mode.png` });

  /* 7. demo pipeline still works */
  await page.getByLabel(/Ask ORCA/).fill("Is it safe to go fishing tomorrow?");
  await page.getByLabel(/Send/).click();
  await page.waitForSelector("text=/MARINE RISK|RISK|OUTLOOK/", { timeout: 20000 });
  await page.waitForTimeout(800);
  ok("demo pipeline still functional", true);
  await page.screenshot({ path: `${OUT}/07-demo-answer.png` });

  ok("no page errors", pageErrors.length === 0, pageErrors.slice(0, 3).join(" | "));

  await browser.close();

  const failed = results.filter((r) => !r.pass);
  console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
  if (failed.length > 0) process.exit(1);
};

run().catch((e) => {
  console.error("verify_live crashed:", e);
  process.exit(1);
});
