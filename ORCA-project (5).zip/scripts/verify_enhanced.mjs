import { chromium } from "playwright";

const OUT = "/home/z/my-project/download/orca-review/enhanced";
const BASE = "http://localhost:3000";

const run = async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 860 } });
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));

  // 1. intro splash (fresh session)
  await page.goto(BASE, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(900);
  await page.screenshot({ path: `${OUT}/01-intro-splash.png` });

  // 2. intro mid-fade / workspace revealed
  await page.waitForTimeout(1900);
  await page.screenshot({ path: `${OUT}/02-after-intro.png` });

  // 3. ask a live question (rich map with demo cyclone + PFZ)
  await page.waitForSelector("textarea", { timeout: 15000 });
  await page.fill("textarea", "Is it safe to sail near Mumbai today?");
  await page.keyboard.press("Enter");
  await page.waitForSelector("text=HIGH MARINE RISK, text=MODERATE RISK, text=LOW RISK, text=INSUFFICIENT DATA", { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(4500);
  await page.screenshot({ path: `${OUT}/03-live-answer-rich-map.png` });

  // 4. DATA SOURCES panel (demo chips)
  const ds = page.locator("text=DATA SOURCES").first();
  if (await ds.count()) {
    await ds.click().catch(() => {});
    await page.waitForTimeout(700);
    await page.screenshot({ path: `${OUT}/04-data-sources-demo-chips.png` });
  }

  // 5. route view (cyclone DEMO label + A* path)
  await page.fill("textarea", "Show me a safer route from Mumbai");
  await page.keyboard.press("Enter");
  await page.waitForSelector("text=SUGGESTED LOWER-RISK PATH", { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(4500);
  await page.screenshot({ path: `${OUT}/05-route-with-demo-cyclone.png` });

  console.log("errors:", errors.length ? errors : "none");
  await browser.close();
};

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
