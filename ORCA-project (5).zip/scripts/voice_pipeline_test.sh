#!/bin/bash
# Voice pipeline test: TTS -> ASR round trip + API route checks
set -e
cd /home/z/my-project
mkdir -p scripts/build

echo "=== 1. Generate speech WAV via z-ai CLI (simulating a user mic input) ==="
z-ai tts -i "Is it safe to sail near Mumbai today" -o scripts/build/voice_test_q.wav --format wav 2>&1 | tail -1
ls -la scripts/build/voice_test_q.wav

echo ""
echo "=== 2. Transcribe locally via CLI (ASR sanity) ==="
z-ai asr -f scripts/build/voice_test_q.wav -o scripts/build/voice_test_asr.json 2>&1 | tail -1
cat scripts/build/voice_test_asr.json
echo ""

echo "=== 3. Test /api/tts route (English briefing) ==="
curl -s -X POST http://localhost:3000/api/tts \
  -H "Content-Type: application/json" \
  -d '{"text":"HIGH MARINE RISK. Waves near 2.4 m and wind 32 km/h expected. Avoid venturing into open sea today.","lang":"en"}' \
  -o scripts/build/tts_route_en.json
node -e '
const d = JSON.parse(require("fs").readFileSync("scripts/build/tts_route_en.json", "utf8"));
console.log("segments:", d.segments?.length ?? "NONE", "| voice:", d.voice, "| chunks:", d.chunks);
if (!d.segments?.length) { console.log("BODY:", JSON.stringify(d).slice(0, 300)); process.exit(1); }
const b64 = d.segments[0];
const buf = Buffer.from(b64, "base64");
console.log("seg0 bytes:", buf.length, "| RIFF magic:", buf.slice(0, 4).toString("ascii"));
'

echo ""
echo "=== 4. Test /api/tts route (Hindi transliteration) ==="
curl -s -X POST http://localhost:3000/api/tts \
  -H "Content-Type: application/json" \
  -d '{"text":"उच्च समुद्री जोखिम। लहरें 2.4 मीटर तक पहुँच सकती हैं।","lang":"hi"}' \
  -o scripts/build/tts_route_hi.json
node -e '
const d = JSON.parse(require("fs").readFileSync("scripts/build/tts_route_hi.json", "utf8"));
console.log("segments:", d.segments?.length ?? "NONE", "| voice:", d.voice);
if (!d.segments?.length) { console.log("BODY:", JSON.stringify(d).slice(0, 300)); process.exit(1); }
console.log("OK: Hindi text produced", d.segments.length, "audio segment(s)");
'

echo ""
echo "=== 5. Test /api/asr route with the CLI-generated WAV ==="
node -e '
const fs = require("fs");
const b64 = fs.readFileSync("scripts/build/voice_test_q.wav").toString("base64");
fs.writeFileSync("scripts/build/asr_req.json", JSON.stringify({ audio: b64 }));
console.log("payload bytes:", b64.length);
'
curl -s -X POST http://localhost:3000/api/asr \
  -H "Content-Type: application/json" \
  -d @scripts/build/asr_req.json -o scripts/build/asr_route_res.json
cat scripts/build/asr_route_res.json
echo ""

echo "=== 6. Test /api/tts error paths ==="
curl -s -X POST http://localhost:3000/api/tts -H "Content-Type: application/json" -d '{"text":""}' | head -c 200; echo ""
curl -s -X POST http://localhost:3000/api/asr -H "Content-Type: application/json" -d '{}' | head -c 200; echo ""
echo "DONE"
