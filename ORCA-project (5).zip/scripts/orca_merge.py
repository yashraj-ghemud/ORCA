#!/usr/bin/env python3
"""Merge cover (Playwright) + body (ReportLab) into the final ORCA project idea PDF."""
from pypdf import PdfReader, PdfWriter

A4_W, A4_H = 595.28, 841.89

COVER = '/home/z/my-project/scripts/build/orca_cover.pdf'
BODY = '/home/z/my-project/scripts/build/orca_body.pdf'
OUT = '/home/z/my-project/download/ORCA_Project_Idea.pdf'


def normalize_page_to_a4(page):
    box = page.mediabox
    w, h = float(box.width), float(box.height)
    if abs(w - A4_W) > 0.1 or abs(h - A4_H) > 0.1:
        page.scale_to(A4_W, A4_H)
        page.mediabox.lower_left = (0, 0)
        page.mediabox.upper_right = (A4_W, A4_H)
    return page


writer = PdfWriter()
cover_page = PdfReader(COVER).pages[0]
writer.add_page(normalize_page_to_a4(cover_page))
for page in PdfReader(BODY).pages:
    writer.add_page(normalize_page_to_a4(page))

writer.add_metadata({
    '/Title': 'ORCA - Marine Intelligence Platform - Project Idea',
    '/Author': 'Z.ai',
    '/Creator': 'Z.ai',
    '/Subject': 'Project idea document for the ORCA agentic marine intelligence platform (Smart India Hackathon)',
})
with open(OUT, 'wb') as f:
    writer.write(f)

r = PdfReader(OUT)
print('Final PDF:', OUT)
print('Pages:', len(r.pages))
for i, p in enumerate(r.pages[:3]):
    print(f'  page {i+1}: {float(p.mediabox.width):.1f} x {float(p.mediabox.height):.1f} pt')
