#!/bin/bash
# Flow-level smoke test for /api/orca/query (live mode)
set -e

post() {
  curl -s --max-time 120 -X POST http://localhost:3000/api/orca/query \
    -H "Content-Type: application/json" -d "$1"
}

show() {
python3 -c '
import json, sys
d = json.load(sys.stdin)
r = d.get("response", {})
print(" flow:", d.get("flow"), "| headline:", r.get("headline"))
print(" summary:", (r.get("summary") or "")[:180])
md = d.get("mapData", {})
route = md.get("route")
routeTxt = "-"
if md.get("routeStatus") == "NO_SAFE_PATH":
    routeTxt = "NO_SAFE_PATH"
elif md.get("routeStatus"):
    routeTxt = str(route.get("distanceKm")) + " km"
pfz = md.get("pfz")
pfzTxt = "unavail" if pfz is None else str(len(pfz))
print(" route:", routeTxt, "| pfz:", pfzTxt, "| quality:", d.get("dataQuality"))
'
}

echo "=== PFZ (Mumbai) ==="
post '{"query":"Nearest fishing zone?","location":{"lat":18.92,"lon":72.83,"name":"Mumbai Coast","id":"mumbai"},"lang":"en"}' | show

echo "=== Route (Mumbai) ==="
post '{"query":"How can I avoid the hazard zone?","location":{"lat":18.92,"lon":72.83,"name":"Mumbai Coast","id":"mumbai"},"lang":"en"}' | show

echo "=== Conditions tomorrow (Mumbai) ==="
post '{"query":"What are conditions tomorrow?","location":{"lat":18.92,"lon":72.83,"name":"Mumbai Coast","id":"mumbai"},"lang":"en"}' | show

echo "=== Safety Hindi (Kerala) ==="
post '{"query":"क्या कल मछली पकड़ना सुरक्षित है?","location":{"lat":9.98,"lon":75.83,"name":"Kerala Coast","id":"kerala"},"lang":"hi"}' | show
