// Screenshot the ORCA architecture diagram at 2x device scale (300dpi print quality)
import { chromium } from 'playwright';
import path from 'node:path';

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({
    viewport: { width: 1000, height: 900 },
    deviceScaleFactor: 2,
  });
  const htmlPath = 'file://' + path.resolve('/home/z/my-project/scripts/orca_diagram.html');
  await page.goto(htmlPath, { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const el = await page.$('#diagram');
  await el.screenshot({ path: '/home/z/my-project/scripts/build/orca_architecture.png' });
  await browser.close();
  console.log('Diagram PNG saved: scripts/build/orca_architecture.png');
})();
