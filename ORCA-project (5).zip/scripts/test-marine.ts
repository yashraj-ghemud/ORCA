/**
 * Live marine source integration check (§30) — run manually:
 *
 *   bun run test:marine
 *
 * Calls every ENABLED provider, validates response shape, prints source
 * status + freshness. Skips credential-gated sources with a clear message.
 * Never prints secrets.
 */

import { getOpenMeteoMarineForecast, getOpenMeteoWeather } from "../src/services/marine/openMeteo";
import { imdConfigured } from "../src/services/marine/imd";
import { incoisConfigured } from "../src/services/marine/incois";
import { pfzConfigured } from "../src/services/marine/pfz";
import { formatIst, humanizeAge } from "../src/services/marine/freshness";

const PROBES = [
  { name: "Mumbai", lat: 18.92, lon: 72.83 },
  { name: "Goa", lat: 15.42, lon: 73.78 },
  { name: "Chennai", lat: 13.05, lon: 80.3 },
  { name: "Kerala", lat: 9.98, lon: 75.83 },
];

function line(label: string, ok: boolean) {
  console.log(`${ok ? "✓" : "✗"} ${label}`);
}

async function main() {
  console.log("=== ORCA marine source integration check ===\n");

  /* --- configuration report (no secrets) --- */
  console.log("Configuration:");
  line(`IMD configured: ${imdConfigured()}`, true);
  if (!imdConfigured()) {
    console.log("  ↳ SKIP: IMD requires an official subscription (imdapi.org).");
    console.log("    Set IMD_API_BASE_URL + IMD_API_KEY to enable.");
  }
  line(`INCOIS OSF configured: ${incoisConfigured()}`, true);
  if (!incoisConfigured()) {
    console.log("  ↳ SKIP: no verified public JSON API for INCOIS OSF.");
    console.log("    Set INCOIS_API_BASE_URL with an official interface to enable.");
  }
  line(`INCOIS PFZ configured: ${pfzConfigured()}`, true);
  if (!pfzConfigured()) {
    console.log("  ↳ SKIP: PFZ advisories are bulletin/GIS products; official interface required.");
  }
  console.log("");

  /* --- Open-Meteo live probes --- */
  console.log("Open-Meteo (free model, key-less):");
  for (const p of PROBES) {
    const [marine, weather] = await Promise.all([
      getOpenMeteoMarineForecast(p.lat, p.lon),
      getOpenMeteoWeather(p.lat, p.lon),
    ]);

    if (marine.ok) {
      const age = humanizeAge(marine.meta.freshnessSeconds);
      console.log(
        `  ✓ ${p.name} marine — Hs ${marine.ocean.waveHeightM ?? "—"} m · swell ${marine.ocean.swellHeightM ?? "—"} m · SST ${marine.ocean.sstC ?? "—"} °C · ${marine.meta.status}${age ? ` (${age})` : ""} · observed ${formatIst(marine.meta.observedAt) ?? "—"}`
      );
    } else {
      console.log(`  ✗ ${p.name} marine — unavailable: ${marine.meta.note}`);
    }

    if (weather.ok) {
      console.log(
        `  ✓ ${p.name} weather — wind ${(weather.weather.windSpeedMps ?? 0) * 3.6 | 0} km/h · ${weather.weather.conditionText ?? "—"} · ${weather.meta.status}`
      );
    } else {
      console.log(`  ✗ ${p.name} weather — unavailable: ${weather.meta.note}`);
    }
  }

  console.log("\nDone. States shown are exactly what the UI will display.");
}

main().catch((err) => {
  console.error("test:marine crashed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
