/**
 * ORCA — voice (TTS + STT) verification
 * Scenarios:
 *  1. Speaker button on ORCA answer → /api/tts called → WAV received → playing state on → stop works
 *  2. Auto-speak toggle → new answer is spoken automatically
 *  3. Mic flow: fake-media chromium → recording UI → stop → /api/asr round trip (fake tone may
 *     yield empty transcript → error toast is the correct UX)
 *  4. Mic permission-denied path (context without mic) → red toast
 *  5. Hindi: speaker on Hindi answer (transliteration path)
 *  6. Mobile 390px composer with voice controls
 *  7. Zero page errors throughout
 */
import { chromium } from "playwright";
import fs from "node:fs";

const BASE = "http://localhost:3000";
const OUT = "/home/z/my-project/download/orca-review/voice";
fs.mkdirSync(OUT, { recursive: true });

const shot = async (page, name) => {
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${OUT}/${name}.png` });
  console.log("shot:", name);
};

const results = [];
const record = (name, pass, note = "") => {
  results.push({ name, pass, note });
  console.log(`${pass ? "PASS" : "FAIL"} — ${name}${note ? " | " + note : ""}`);
};

const run = async () => {
  /* browser with fake mic so getUserMedia resolves */
  const browser = await chromium.launch({
    args: [
      "--use-fake-ui-for-media-stream",
      "--use-fake-device-for-media-stream",
      "--autoplay-policy=no-user-gesture-required",
    ],
  });
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    permissions: ["microphone"],
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));

  /* track API calls */
  const ttsCalls = [];
  const asrCalls = [];
  page.on("response", (res) => {
    if (res.url().includes("/api/tts")) ttsCalls.push(res.status());
    if (res.url().includes("/api/asr")) asrCalls.push(res.status());
  });

  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForSelector(".leaflet-container", { timeout: 30000 });
  await page.waitForTimeout(2000);

  /* ---------- Scenario 1: type a question → speaker button plays briefing ---------- */
  await page.locator("textarea").fill("Is it safe to sail near Mumbai?");
  await page.locator("textarea").press("Enter");
  await page.waitForSelector("text=ORCA ANALYSIS", { timeout: 12000 });
  const speakBtn = page
    .locator('button[aria-label="Play voice briefing"]')
    .first();
  let hasSpeak = true;
  try {
    await speakBtn.waitFor({ state: "visible", timeout: 20000 });
  } catch {
    hasSpeak = false;
  }
  record("1a. Speaker button on ORCA answer", hasSpeak);
  await shot(page, "01_answer_with_speaker");

  if (hasSpeak) {
    await speakBtn.click();
    /* wait until either playing state shows or a tts response lands */
    let speaking = false;
    for (let i = 0; i < 24; i++) {
      speaking =
        (await page.locator('button[aria-label="Stop voice briefing"]').count()) > 0;
      if (speaking && ttsCalls.length > 0) break;
      await page.waitForTimeout(500);
    }
    record("1b. /api/tts called + audio playing state", speaking && ttsCalls.some((s) => s === 200),
      `tts=${ttsCalls.join(",")}`);
    await shot(page, "02_speaking_state");

    await page.locator('button[aria-label="Stop voice briefing"]').first().click();
    await page.waitForTimeout(400);
    const stopped = (await page.locator('button[aria-label="Play voice briefing"]').count()) > 0;
    record("1c. Stop control returns to idle", stopped);
  }

  /* ---------- Scenario 2: auto-speak toggle ---------- */
  const toggle = page.locator('button:has-text("Voice briefings")').first();
  if ((await toggle.count()) === 0) {
    record("2a. Auto-speak toggle visible", false);
  } else {
    await toggle.click();
    await page.waitForTimeout(300);
    const on = (await toggle.getAttribute("aria-pressed")) === "true";
    record("2a. Auto-speak toggles on", on);

    const ttsBefore = ttsCalls.length;
    await page.locator("textarea").fill("Nearest PFZ");
    await page.locator("textarea").press("Enter");
    try {
      await page.waitForSelector('button[aria-label="Stop voice briefing"]', {
        timeout: 25000,
      });
    } catch {
      /* fall through — tts poll below decides the result */
    }
    /* wait for the tts response itself */
    let ok = false;
    for (let i = 0; i < 20; i++) {
      if (ttsCalls.length > ttsBefore) {
        ok = true;
        break;
      }
      await page.waitForTimeout(500);
    }
    record("2b. New answer spoken automatically", ok, `ttsCalls=${ttsCalls.join(",")}`);
    await shot(page, "03_auto_speak");

    await page.locator('button[aria-label="Stop voice briefing"]').first().click();
    await page.waitForTimeout(300);
    await toggle.click(); /* turn off for the remaining scenarios */
    await page.waitForTimeout(300);
  }

  /* ---------- Scenario 3: mic flow (fake device → beep tone) ---------- */
  const micBtn = page.locator('button[aria-label="Speak to ORCA"]').first();
  record("3a. Mic button visible", (await micBtn.count()) > 0);
  if ((await micBtn.count()) > 0) {
    await micBtn.click();
    await page.waitForTimeout(900);
    const recBar = (await page.locator("text=Listening").count()) > 0;
    record("3b. Recording bar appears (Listening)", recBar);
    await shot(page, "04_recording_bar");

    /* wait a bit then stop → /api/asr should be hit (fake tone → likely empty text → toast) */
    await page.waitForTimeout(2500);
    await page.locator('button[aria-label="Stop recording"]').click();
    await page.waitForTimeout(4000);
    const asrHit = asrCalls.length > 0;
    record("3c. /api/asr round trip happened", asrHit, `asr=${asrCalls.join(",")}`);
    await shot(page, "05_after_transcribe");
  }

  /* ---------- Scenario 4: Hindi answer + speaker (transliteration path) ---------- */
  const langTrigger = page.locator('[aria-label="Language"]').first();
  if ((await langTrigger.count()) > 0) {
    await langTrigger.click();
    await page.waitForTimeout(500);
    await page.locator('[role="menuitem"]:has-text("हिन्दी")').click();
    await page.waitForTimeout(800);
    await page.locator("textarea").fill("क्या मुंबई के पास जाना सुरक्षित है?");
    await page.locator("textarea").press("Enter");
    const hiSpeak = page.locator('button[aria-label="आवाज़ में सुनें"]').first();
    let hasHi = true;
    try {
      await hiSpeak.waitFor({ state: "visible", timeout: 25000 });
    } catch {
      hasHi = false;
    }
    record("4a. Hindi answer has speaker button", hasHi);
    if (hasHi) {
      const before = ttsCalls.length;
      await hiSpeak.click();
      let hiSpeaking = false;
      for (let i = 0; i < 24; i++) {
        hiSpeaking = (await page.locator('button[aria-label="आवाज़ रोकें"]').count()) > 0;
        if (hiSpeaking && ttsCalls.length > before) break;
        await page.waitForTimeout(500);
      }
      record("4b. Hindi briefing plays (transliterated TTS)", hiSpeaking, `tts=${ttsCalls.slice(before).join(",")}`);
      await shot(page, "06_hindi_speaking");
      const stopHi = page.locator('button[aria-label="आवाज़ रोकें"]').first();
      if ((await stopHi.count()) > 0) {
        await stopHi.click();
        await page.waitForTimeout(300);
      }
    }
  } else {
    record("4a. Hindi switch available", false);
  }

  /* ---------- Scenario 5: mobile layout ---------- */
  const mob = await ctx.newPage();
  mob.on("pageerror", (e) => errors.push("mobile: " + String(e)));
  await mob.setViewportSize({ width: 390, height: 780 });
  await mob.goto(BASE, { waitUntil: "networkidle" });
  await mob.waitForTimeout(1800);
  const mobMic = mob.locator('button[aria-label="Speak to ORCA"]');
  const mobToggle = mob.locator('button:has-text("Voice briefings")');
  record(
    "5a. Mobile 390px: mic + auto-speak visible",
    (await mobMic.count()) > 0 && (await mobToggle.count()) > 0
  );
  await mob.screenshot({ path: `${OUT}/07_mobile_voice.png` });
  console.log("shot: 07_mobile_voice");
  await mob.close();

  /* ---------- page errors ---------- */
  record("6. Zero page errors", errors.length === 0, errors.slice(0, 3).join(" || "));

  await browser.close();

  const failed = results.filter((r) => !r.pass);
  console.log(`\n==== SUMMARY: ${results.length - failed.length}/${results.length} PASS ====`);
  if (failed.length) {
    console.log("FAILED:");
    failed.forEach((f) => console.log(" -", f.name, f.note));
    process.exit(1);
  }
};

run().catch((e) => {
  console.error("SCRIPT ERROR:", e);
  process.exit(1);
});
