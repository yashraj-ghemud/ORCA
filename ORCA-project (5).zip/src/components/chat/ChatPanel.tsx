"use client";

import type { AgentStatus, ChatMessage, ProcessingState } from "@/types/orca";
import type { MarineLocation } from "@/types/marine";
import type { Dict, Lang } from "@/lib/i18n";
import type { LiveStrip } from "./SuggestedQueries";
import { MessageList } from "./MessageList";
import { Composer } from "./Composer";
import { SuggestedQueries } from "./SuggestedQueries";

export function ChatPanel({
  messages,
  processing,
  dict,
  lang,
  agents,
  location,
  draft,
  onDraftChange,
  onSend,
  onChip,
  onDemo,
  onTranscript,
  onNotify,
  autoSpeak,
  onAutoSpeakToggle,
  demoRunning,
  inputRef,
  mode = "demo",
  liveStrip,
}: {
  messages: ChatMessage[];
  processing: ProcessingState | null;
  dict: Dict;
  lang: Lang;
  agents: AgentStatus[];
  location: MarineLocation;
  draft: string;
  onDraftChange: (v: string) => void;
  onSend: () => void;
  onChip: (q: string) => void;
  onDemo: () => void;
  /** final recognised speech text from the mic */
  onTranscript: (text: string) => void;
  onNotify: (kind: "error" | "info", title: string, body?: string) => void;
  autoSpeak: boolean;
  onAutoSpeakToggle: () => void;
  demoRunning: boolean;
  inputRef: React.RefObject<HTMLTextAreaElement | null>;
  mode?: "demo" | "live";
  liveStrip?: LiveStrip | null;
}) {
  const isEmpty = messages.length === 0 && !processing;

  return (
    <section
      className="flex h-full min-h-0 flex-col bg-white lg:border-r lg:border-line"
      aria-label="Conversation with ORCA"
    >
      {isEmpty ? (
        <SuggestedQueries
          dict={dict}
          location={location}
          onChip={onChip}
          onDemo={onDemo}
          demoRunning={demoRunning}
          liveStrip={mode === "live" ? liveStrip : null}
        />
      ) : (
        <MessageList
          messages={messages}
          processing={processing}
          dict={dict}
          lang={lang}
          agents={agents}
          onFollowUp={onChip}
        />
      )}
      <Composer
        dict={dict}
        draft={draft}
        onDraftChange={onDraftChange}
        onSend={onSend}
        onTranscript={onTranscript}
        onNotify={onNotify}
        autoSpeak={autoSpeak}
        onAutoSpeakToggle={onAutoSpeakToggle}
        inputRef={inputRef}
        mode={mode}
      />
    </section>
  );
}
