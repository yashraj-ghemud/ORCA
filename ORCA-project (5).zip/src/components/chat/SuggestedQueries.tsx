"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Compass, Database, Play, Thermometer, Waves, Wind, ShieldAlert, ShieldCheck } from "lucide-react";
import { OceanRibbon } from "@/components/intro/OceanRibbon";
import type { MarineLocation } from "@/types/marine";
import type { Dict } from "@/lib/i18n";

/** Live conditions strip payload (nullable values — missing stays missing). */
export interface LiveStrip {
  waveM: number | null;
  windKmh: number | null;
  windDir: string | null;
  sstC: number | null;
  sourceLine: string;
  available: boolean;
}

/**
 * Smooth count-up for numeric strip values — animates whenever the target
 * changes (location switch, refreshed fetch). Respects missing values ("—").
 */
function useCountUp(target: number | null, duration = 650): number | null {
  const [value, setValue] = useState<number | null>(target);
  const fromRef = useRef<number | null>(null);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    if (target == null) return; /* missing stays missing — no state churn */
    const from = fromRef.current ?? target * 0.6;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      const v = from + (target - from) * eased;
      setValue(v);
      if (p < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        fromRef.current = target;
      }
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration]);

  return target == null ? null : value;
}

function StatValue({
  target,
  suffix,
  decimals = 1,
}: {
  target: number | null;
  suffix: string;
  decimals?: number;
}) {
  const v = useCountUp(target);
  if (target == null) return <span>—</span>;
  return (
    <span>
      {v != null ? v.toFixed(decimals) : target.toFixed(decimals)}
      <span className="text-[9.5px] font-medium text-ink-2"> {suffix}</span>
    </span>
  );
}

/**
 * Empty state (§10, §14) — understated chips + a compact conditions strip.
 * Demo mode: simulated values. Live mode: real model values (nullable) with
 * an explicit source/freshness line — no fabricated numbers.
 */
export function SuggestedQueries({
  dict,
  location,
  onChip,
  onDemo,
  demoRunning,
  liveStrip,
}: {
  dict: Dict;
  location: MarineLocation;
  onChip: (q: string) => void;
  onDemo: () => void;
  demoRunning: boolean;
  liveStrip?: LiveStrip | null;
}) {
  /* time-aware greeting — TZ-dependent, so server snapshot stays empty and the
     client snapshot fills it in after hydration (no SSR mismatch) */
  const subscribeNoop = () => () => {};
  const greeting = useSyncExternalStore(
    subscribeNoop,
    () => {
      const hour = new Date().getHours();
      const gEn = hour < 12 ? "Good morning." : hour < 17 ? "Good afternoon." : "Good evening.";
      const gHi = hour < 12 ? "सुप्रभात।" : hour < 17 ? "नमस्कार।" : "शुभ संध्या।";
      return (dict.langLabel as string) === "हिन्दी" ? gHi : gEn;
    },
    () => null
  );
  const hi = (dict.langLabel as string) === "हिन्दी";
  const c = location?.conditions;

  const stats = liveStrip
    ? [
        { icon: Waves, label: hi ? "लहर" : "Waves", node: <StatValue target={liveStrip.waveM} suffix="m" /> },
        {
          icon: Wind,
          label: `${hi ? "हवा" : "Wind"}${liveStrip.windDir ? ` · ${liveStrip.windDir}` : ""}`,
          node: <StatValue target={liveStrip.windKmh} suffix="km/h" decimals={0} />,
        },
        { icon: Thermometer, label: "SST", node: <StatValue target={liveStrip.sstC} suffix="°C" /> },
        {
          icon: liveStrip.available ? ShieldCheck : ShieldAlert,
          label: hi ? "डेटा" : "Data",
          node: (
            <span className={liveStrip.available ? "text-good" : "text-warn-ink"}>
              {liveStrip.available ? (hi ? "लाइव" : "Live") : dict.stripUnavailable}
            </span>
          ),
        },
      ]
    : [
        { icon: Waves, label: hi ? "लहर" : "Waves", node: <StatValue target={c.waveHeightM} suffix="m" /> },
        { icon: Wind, label: `${hi ? "हवा" : "Wind"} · ${c.windDir}`, node: <StatValue target={c.windKmh} suffix="km/h" decimals={0} /> },
        { icon: Thermometer, label: "SST", node: <StatValue target={c.sstC} suffix="°C" /> },
        {
          icon: c.advisory === "active" ? ShieldAlert : ShieldCheck,
          label: hi ? "चेतावनी" : "Advisory",
          node: (
            <span className={c.advisory === "active" ? "text-warn-ink" : "text-good"}>
              {c.advisory === "active"
                ? dict.advisoryActive
                : c.advisory === "watch"
                  ? dict.advisoryWatch
                  : dict.advisoryNone}
            </span>
          ),
        },
      ] as const;

  return (
    <div className="chat-scroll flex flex-1 flex-col items-center justify-center overflow-y-auto px-6 py-8 text-center">
      <div className="stagger flex flex-col items-center">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-pale text-marine">
          <Compass className="h-5 w-5" aria-hidden />
        </div>
        <p className="mt-4 min-h-[18px] text-[12px] font-medium text-ink-2">{greeting}</p>
        <h2 className="mt-1 text-[17px] font-semibold tracking-[-0.01em] text-ink">
          {dict.greetingTitle}
        </h2>
        <p className="mt-1.5 max-w-[300px] text-[12.5px] leading-relaxed text-ink-2">
          {dict.greetingSub}
        </p>
        {/* Living Three.js sea strip — the site's own piece of the ocean */}
        <div className="fade-up mt-4 w-full max-w-[340px] overflow-hidden rounded-md border border-line/70" style={{ animationDelay: "0.22s" }}>
          <OceanRibbon className="h-14 w-full" />
        </div>
      </div>

      {/* Conditions strip — demo data or live model values */}
      {(liveStrip || c) && (
        <div className="fade-up mt-5 w-full max-w-[340px]" style={{ animationDelay: "0.28s" }}>
          <div className="grid grid-cols-4 gap-px overflow-hidden rounded-lg border border-line bg-line">
            {stats.map((s) => (
              <div key={s.label} className="flex flex-col items-center gap-1 bg-white px-1 py-2.5">
                <s.icon className="h-3.5 w-3.5 text-marine-2" aria-hidden />
                <span className="text-[14px] font-semibold leading-none text-ink">{s.node}</span>
                <span className="max-w-full truncate text-[8.5px] font-semibold uppercase tracking-[0.08em] text-ink-2">
                  {s.label}
                </span>
              </div>
            ))}
          </div>
          {liveStrip && (
            <div className="mt-1.5 flex items-center justify-center gap-1 text-[9.5px] text-ink-2">
              <Database className="h-3 w-3" aria-hidden />
              {liveStrip.sourceLine || dict.stripSource}
            </div>
          )}
        </div>
      )}

      <div
        className="stagger mt-5 flex max-w-[340px] flex-wrap justify-center gap-1.5"
        style={{ animationDelay: "0.36s" }}
      >
        {dict.chips.map((c2) => (
          <button
            key={c2}
            type="button"
            onClick={() => onChip(c2)}
            className="rounded-full border border-line bg-white px-3.5 py-2 text-[12px] text-ink transition-all duration-150 hover:border-marine/40 hover:bg-pale hover:text-marine hover:shadow-[0_2px_8px_rgba(18,78,120,0.12)] active:scale-[0.98]"
          >
            {c2}
          </button>
        ))}
      </div>

      <button
        type="button"
        onClick={onDemo}
        disabled={demoRunning}
        className="fade-up mt-5 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11.5px] font-medium text-marine-2 transition-colors hover:bg-pale hover:text-marine disabled:opacity-50"
        style={{ animationDelay: "0.5s" }}
      >
        <Play className="h-3 w-3" aria-hidden />
        {dict.guidedDemo}
      </button>
    </div>
  );
}
