"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  AudioLines,
  Loader2,
  Mic,
  SendHorizontal,
  Square,
  Volume2,
  X,
} from "lucide-react";
import type { Dict } from "@/lib/i18n";
import {
  MIC_MAX_SECONDS,
  cancelMicRecording,
  startMicRecording,
  stopMicRecordingToBase64Wav,
  type MicSession,
} from "@/lib/audio-record";

type MicState = "idle" | "requesting" | "recording" | "transcribing";

export function Composer({
  dict,
  draft,
  onDraftChange,
  onSend,
  onTranscript,
  onNotify,
  autoSpeak,
  onAutoSpeakToggle,
  inputRef,
  mode = "demo",
}: {
  dict: Dict;
  draft: string;
  onDraftChange: (v: string) => void;
  onSend: () => void;
  /** final recognised text — page decides to send or stage as draft */
  onTranscript: (text: string) => void;
  onNotify: (kind: "error" | "info", title: string, body?: string) => void;
  autoSpeak: boolean;
  onAutoSpeakToggle: () => void;
  inputRef: React.RefObject<HTMLTextAreaElement | null>;
  mode?: "demo" | "live";
}) {
  const [focused, setFocused] = useState(false);
  const [micState, setMicState] = useState<MicState>("idle");
  const [elapsed, setElapsed] = useState(0);
  const sessionRef = useRef<MicSession | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoStopRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hasText = draft.trim().length > 0;
  const areaRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    const el = inputRef.current;
    if (el) el.style.height = "0px";
    const el2 = inputRef.current;
    if (el2) el2.style.height = Math.min(el2.scrollHeight, 96) + "px";
  }, [draft, inputRef]);

  const clearVoiceTimers = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (autoStopRef.current) {
      clearTimeout(autoStopRef.current);
      autoStopRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      clearVoiceTimers();
      if (sessionRef.current) {
        cancelMicRecording(sessionRef.current);
        sessionRef.current = null;
      }
    };
  }, [clearVoiceTimers]);

  const finishWithTranscript = useCallback(
    (text: string | null) => {
      clearVoiceTimers();
      sessionRef.current = null;
      setMicState("idle");
      setElapsed(0);
      if (text && text.trim().length > 0) {
        onTranscript(text.trim());
      } else {
        onNotify("error", dict.voiceErrors.asrEmpty, dict.voiceErrors.asrEmptyBody);
      }
    },
    [clearVoiceTimers, dict, onNotify, onTranscript]
  );

  const stopAndTranscribe = useCallback(async () => {
    const session = sessionRef.current;
    if (!session) return;
    clearVoiceTimers();
    sessionRef.current = null;
    setMicState("transcribing");
    try {
      const base64Wav = await stopMicRecordingToBase64Wav(session);
      const res = await fetch("/api/asr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ audio: base64Wav }),
      });
      if (!res.ok) throw new Error(`ASR ${res.status}`);
      const data = (await res.json()) as { text?: string };
      finishWithTranscript(data.text ?? "");
    } catch {
      finishWithTranscript(null);
      onNotify("error", dict.voiceErrors.asrFailed, dict.voiceErrors.asrFailedBody);
    }
  }, [clearVoiceTimers, dict, finishWithTranscript, onNotify]);

  const startRecording = useCallback(async () => {
    if (micState !== "idle") return;
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      onNotify("error", dict.voiceErrors.micUnsupported, dict.voiceErrors.micUnsupportedBody);
      return;
    }
    setMicState("requesting");
    try {
      const session = await startMicRecording();
      sessionRef.current = session;
      setMicState("recording");
      setElapsed(0);
      timerRef.current = setInterval(() => setElapsed((s) => s + 1), 1000);
      autoStopRef.current = setTimeout(() => void stopAndTranscribe(), MIC_MAX_SECONDS * 1000);
    } catch (err) {
      setMicState("idle");
      const denied =
        err instanceof Error &&
        (err.name === "NotAllowedError" || err.name === "SecurityError");
      onNotify(
        "error",
        denied ? dict.voiceErrors.micDenied : dict.voiceErrors.asrFailed,
        denied ? dict.voiceErrors.micDeniedBody : dict.voiceErrors.asrFailedBody
      );
    }
  }, [dict, micState, onNotify, stopAndTranscribe]);

  const cancelRecording = useCallback(() => {
    if (sessionRef.current) {
      cancelMicRecording(sessionRef.current);
      sessionRef.current = null;
    }
    clearVoiceTimers();
    setMicState("idle");
    setElapsed(0);
  }, [clearVoiceTimers]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (hasText) onSend();
    }
  };

  const recording = micState === "recording";
  const busy = micState !== "idle";

  return (
    <div className="border-t border-line bg-white px-3.5 py-3">
      {recording ? (
        /* ------- live recording bar ------- */
        <div
          className="flex items-center gap-2.5 rounded-lg border border-[#efcfc9] bg-danger-soft pl-3.5 pr-1.5 py-1.5"
          role="status"
          aria-live="polite"
        >
          <span className="relative flex h-3 w-3 shrink-0">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#b42318] opacity-60" />
            <span className="relative inline-flex h-3 w-3 rounded-full bg-[#b42318]" />
          </span>
          <AudioLines className="h-4 w-4 shrink-0 text-danger-ink voice-eq" aria-hidden />
          <div className="min-w-0 flex-1 leading-tight">
            <div className="truncate text-[12.5px] font-medium text-danger-ink">
              {dict.listening}
            </div>
            <div className="text-[10px] tabular-nums text-danger-ink/70">
              {elapsed}s / {MIC_MAX_SECONDS}s
            </div>
          </div>
          <button
            type="button"
            onClick={cancelRecording}
            aria-label={dict.voiceCancel}
            title={dict.voiceCancel}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-ink-2 transition-colors hover:bg-white/70 hover:text-ink"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
          <button
            type="button"
            onClick={() => void stopAndTranscribe()}
            aria-label={dict.voiceStop}
            title={dict.voiceStop}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-marine text-white transition-all hover:bg-[#0e405f] active:scale-95"
          >
            <Square className="h-3.5 w-3.5 fill-current" aria-hidden />
          </button>
        </div>
      ) : (
        /* ------- normal input row ------- */
        <div
          className={`flex items-end gap-1.5 rounded-lg border bg-white pl-3.5 pr-1.5 py-1.5 transition-shadow duration-200 ${
            focused
              ? "border-marine/50 shadow-[0_0_0_3px_rgba(18,78,120,0.08)]"
              : "border-line shadow-[0_1px_2px_rgba(23,35,45,0.04)]"
          }`}
        >
          <textarea
            ref={inputRef}
            rows={1}
            value={draft}
            onChange={(e) => onDraftChange(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            disabled={busy}
            placeholder={busy ? dict.transcribing : dict.placeholder}
            aria-label={dict.placeholder}
            className="chat-scroll max-h-24 min-h-[24px] flex-1 resize-none bg-transparent py-1 text-[13px] leading-relaxed text-ink outline-none placeholder:text-[#9aabb5] disabled:opacity-60"
          />
          {micState === "transcribing" ? (
            <span
              className="flex h-8 w-8 shrink-0 items-center justify-center text-marine"
              role="status"
              aria-label={dict.transcribing}
            >
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            </span>
          ) : (
            <button
              type="button"
              onClick={() => void startRecording()}
              disabled={micState === "requesting"}
              aria-label={dict.voice}
              title={dict.voice}
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors ${
                micState === "requesting"
                  ? "cursor-wait text-ink-2/60"
                  : "text-ink-2 hover:bg-pale hover:text-marine"
              }`}
            >
              <Mic
                className={`h-4 w-4 ${micState === "requesting" ? "animate-pulse" : ""}`}
                aria-hidden
              />
            </button>
          )}
          <button
            type="button"
            onClick={onSend}
            disabled={!hasText}
            aria-label={dict.send}
            title={dict.send}
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-all duration-200 ${
              hasText
                ? "bg-marine text-white hover:bg-[#0e405f] active:scale-95"
                : "cursor-not-allowed bg-[#dbe5ea] text-white"
            }`}
          >
            <SendHorizontal className="h-4 w-4" aria-hidden />
          </button>
        </div>
      )}
      <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1.5 px-1">
        <button
          type="button"
          onClick={onAutoSpeakToggle}
          aria-pressed={autoSpeak}
          title={autoSpeak ? dict.autoSpeakOn : dict.autoSpeakOff}
          className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-medium transition-all ${
            autoSpeak
              ? "border-marine/35 bg-pale text-marine"
              : "border-line bg-white text-ink-2 hover:border-marine/30 hover:text-marine"
          }`}
        >
          <Volume2 className="h-3 w-3" aria-hidden />
          {dict.autoSpeak}
          <span
            className={`ml-0.5 inline-block h-1.5 w-1.5 rounded-full ${
              autoSpeak ? "bg-good" : "bg-[#c3d2da]"
            }`}
            aria-hidden
          />
          <span className="sr-only">{autoSpeak ? dict.autoSpeakOn : dict.autoSpeakOff}</span>
        </button>
        <span className="text-[10px] text-[#9aabb5]">
          {recording ? "" : mode === "live" ? dict.footerLive : dict.footerDemo}
        </span>
      </div>
    </div>
  );
}
