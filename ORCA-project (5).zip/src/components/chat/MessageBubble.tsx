"use client";

import { useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Info,
  Loader2,
  ShieldAlert,
  Volume2,
} from "lucide-react";
import type { ChatMessage, Tone } from "@/types/orca";
import type { Dict, Lang } from "@/lib/i18n";
import { orcaSpeakText } from "@/lib/speakable";
import { speakMessage, stopSpeaking, useVoiceState } from "@/lib/voice-client";
import { AnalysisSummary } from "@/components/analysis/AnalysisSummary";
import type { AgentStatus } from "@/types/orca";

const TONE_STYLE: Record<Tone, { card: string; text: string; icon: React.ElementType }> = {
  danger: {
    card: "border-[#efcfc9] bg-danger-soft",
    text: "text-danger-ink",
    icon: ShieldAlert,
  },
  warning: {
    card: "border-[#edd9bc] bg-warn-soft",
    text: "text-warn-ink",
    icon: AlertTriangle,
  },
  good: {
    card: "border-[#c9e2d4] bg-teal-soft",
    text: "text-good",
    icon: CheckCircle2,
  },
  info: {
    card: "border-[#cfe2ec] bg-pale",
    text: "text-info-ink",
    icon: Info,
  },
};

function time(ts: number) {
  return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/** Speaker button — plays / stops the voice briefing for an ORCA message. */
function SpeakButton({ msg, lang, dict }: { msg: ChatMessage; lang: Lang; dict: Dict }) {
  const voice = useVoiceState();
  const active = voice.phase !== "idle" && voice.id === msg.id;
  const [busy, setBusy] = useState(false);

  const onClick = () => {
    if (active) {
      stopSpeaking();
      return;
    }
    setBusy(true);
    void speakMessage(msg.id, orcaSpeakText(msg, lang), lang).finally(() => setBusy(false));
  };

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={active ? dict.stopBriefing : dict.playBriefing}
      title={active ? dict.stopBriefing : dict.playBriefing}
      aria-live="polite"
      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md transition-colors ${
        active
          ? "text-marine bg-pale"
          : "text-[#9aabb5] hover:bg-pale hover:text-marine"
      }`}
    >
      {busy && !active ? (
        <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
      ) : (
        <Volume2
          className={`h-3 w-3 ${active && voice.phase === "speaking" ? "voice-eq" : ""}`}
          aria-hidden
        />
      )}
    </button>
  );
}

function OrcaMark() {
  return (
    <span
      className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-marine text-white"
      aria-hidden
    >
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
        <path d="M3 10c2.6 0 2.6 2 5.2 2s2.6-2 5.2-2 2.6 2 5.2 2" />
        <path d="M3 16c2.6 0 2.6 2 5.2 2s2.6-2 5.2-2 2.6 2 5.2 2" opacity="0.6" />
      </svg>
    </span>
  );
}

function ResultCard({
  msg,
  dict,
  lang,
  agents,
  onFollowUp,
}: {
  msg: ChatMessage;
  dict: Dict;
  lang: Lang;
  agents: AgentStatus[];
  onFollowUp: (q: string) => void;
}) {
  const r = msg.response!;
  const hi = lang === "hi";
  const tone = TONE_STYLE[r.tone];
  const ToneIcon = tone.icon;
  const [showWhy, setShowWhy] = useState(false);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [showSources, setShowSources] = useState(false);

  const headline = hi ? r.headlineHi : r.headline;
  const summary = hi ? r.summaryHi : r.summary;

  return (
    <div className="msg-in">
      {/* verdict card */}
      <div className={`rounded-lg border ${tone.card} px-4 py-3.5`}>
        <div className="flex items-start gap-2.5">
          <ToneIcon className={`mt-[1px] h-4 w-4 shrink-0 ${tone.text}`} aria-hidden />
          <div className="min-w-0 flex-1">
            <div className={`text-[13px] font-bold uppercase tracking-[0.06em] ${tone.text}`}>
              {headline}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-ink">{summary}</p>
          </div>
        </div>

        {/* key evidence — top 3 items */}
        <div className="mt-3 grid grid-cols-3 gap-2 border-t border-black/5 pt-3">
          {r.evidence.slice(0, 3).map((e) => (
            <div key={e.label} className="min-w-0">
              <div className="truncate text-[9.5px] font-semibold uppercase tracking-[0.1em] text-ink-2">
                {hi ? e.labelHi : e.label}
              </div>
              <div
                className={`mt-0.5 truncate text-[15px] font-semibold leading-tight ${
                  e.tone === "danger" ? "text-danger-ink" : e.tone === "warning" ? "text-warn-ink" : e.tone === "good" ? "text-good" : "text-ink"
                }`}
                title={e.value}
              >
                {e.short ?? e.value}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* advisories */}
      {(hi ? r.advisoriesHi : r.advisories).length > 0 && (
        <ul className="mt-2 flex flex-col gap-1">
          {(hi ? r.advisoriesHi : r.advisories).map((a) => (
            <li key={a} className="flex items-start gap-1.5 text-[11.5px] leading-snug text-ink-2">
              <span className="mt-[5px] h-1 w-1 shrink-0 rounded-full bg-[#b7c6cf]" aria-hidden />
              {a}
            </li>
          ))}
        </ul>
      )}

      {/* actions */}
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1">
        <button
          type="button"
          onClick={() => setShowWhy((v) => !v)}
          className="flex items-center gap-1 text-[12px] font-medium text-marine transition-colors hover:text-marine-2"
          aria-expanded={showWhy}
        >
          {dict.whyTitle}
          <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${showWhy ? "rotate-180" : ""}`} aria-hidden />
        </button>
        <button
          type="button"
          onClick={() => setShowAnalysis((v) => !v)}
          className="flex items-center gap-1 text-[12px] font-medium text-marine transition-colors hover:text-marine-2"
          aria-expanded={showAnalysis}
        >
          {showAnalysis ? dict.hideAnalysis : dict.viewAnalysis}
          <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${showAnalysis ? "rotate-180" : ""}`} aria-hidden />
        </button>
        {r.sources && r.sources.length > 0 && (
          <button
            type="button"
            onClick={() => setShowSources((v) => !v)}
            className="flex items-center gap-1 text-[12px] font-medium text-marine transition-colors hover:text-marine-2"
            aria-expanded={showSources}
          >
            {dict.dataSources}
            <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${showSources ? "rotate-180" : ""}`} aria-hidden />
          </button>
        )}
        <span className="ml-auto text-[10px] text-[#9aabb5]">{dict.evidenceBacked}</span>
      </div>

      {showSources && r.sources && (
        <div className="drawer-in mt-2 rounded-lg border border-line bg-white px-3.5 py-3">
          <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2">
            {dict.dataSources}
          </div>
          <ul className="mt-2 flex flex-col gap-1.5">
            {r.sources.map((s, i) => (
              <li key={`${s.source}-${s.kind}-${i}`} className="flex items-baseline justify-between gap-3">
                <span className="text-[11.5px] text-ink-2">
                  {s.source}
                  {"demo" in s && (s as { demo?: boolean }).demo ? (
                    <span className="ml-1.5 rounded border border-[#edd9bc] bg-warn-soft px-1 py-px text-[8.5px] font-bold uppercase tracking-[0.08em] text-warn-ink">
                      demo
                    </span>
                  ) : (
                    <span className="ml-1.5 text-[10px] text-[#9aabb5]">{s.kind}</span>
                  )}
                </span>
                <span
                  className={`text-[11px] font-medium ${
                    (s as { demo?: boolean }).demo
                      ? "text-warn-ink"
                      : s.status === "unavailable"
                        ? "text-warn-ink"
                        : s.status === "stale"
                          ? "text-warn-ink"
                          : "text-ink"
                  }`}
                >
                  {(s as { demo?: boolean }).demo
                    ? dict.srcDemo
                    : s.status === "unavailable"
                      ? dict.srcUnavailable
                      : s.status === "stale"
                        ? dict.srcStale
                        : s.source === "OPEN_METEO"
                          ? dict.srcModel
                          : s.status}
                </span>
              </li>
            ))}
          </ul>
          {r.dataQuality && (
            <div className="mt-2 border-t border-dotted border-[#e4ecf0] pt-1.5 text-[10.5px] text-ink-2">
              {dict.dataQualityLabel}: <span className="font-medium text-ink">{r.dataQuality}</span>
            </div>
          )}
        </div>
      )}

      {showWhy && (
        <div className="drawer-in mt-2 rounded-lg border border-line bg-white px-3.5 py-3">
          <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2">
            {dict.whyTitle}
          </div>
          <ul className="mt-2 flex flex-col gap-1.5">
            {r.evidence.slice(0, 3).map((e) => (
              <li key={e.label} className="flex items-baseline justify-between gap-3">
                <span className="text-[12px] text-ink-2">{hi ? e.labelHi : e.label}</span>
                <span className="text-[12px] font-medium text-ink">{e.value}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {showAnalysis && (
        <AnalysisSummary analysis={r.analysis} agents={agents} dict={dict} hi={hi} />
      )}

      {/* follow-up chips */}
      {r.followUps.length > 0 && (
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {r.followUps.map((f) => (
            <button
              key={f.en}
              type="button"
              onClick={() => onFollowUp(hi ? f.hi : f.en)}
              className="rounded-full border border-line bg-white px-3 py-1.5 text-[11.5px] text-ink transition-all hover:border-marine/40 hover:bg-pale hover:text-marine"
            >
              {hi ? f.hi : f.en}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function MessageBubble({
  msg,
  dict,
  lang,
  agents,
  onFollowUp,
}: {
  msg: ChatMessage;
  dict: Dict;
  lang: Lang;
  agents: AgentStatus[];
  onFollowUp: (q: string) => void;
}) {
  const hi = lang === "hi";

  /* divider */
  if (msg.divider) {
    return (
      <div className="msg-in flex items-center gap-3 py-1" role="separator">
        <span className="h-px flex-1 bg-line" aria-hidden />
        <span className="max-w-[70%] truncate text-center text-[10.5px] text-[#9aabb5]">
          {msg.divider}
        </span>
        <span className="h-px flex-1 bg-line" aria-hidden />
      </div>
    );
  }

  if (msg.role === "user") {
    return (
      <div className="msg-in flex justify-end">
        <div className="max-w-[85%] rounded-lg rounded-br-sm border border-[#d3e4ec] bg-pale px-3.5 py-2.5">
          <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-ink">{msg.text}</p>
        </div>
      </div>
    );
  }

  if (msg.role === "system") {
    return (
      <div className="msg-in rounded-lg border border-[#efcfc9] bg-danger-soft px-3.5 py-2.5">
        <div className="flex items-center gap-1.5">
          <AlertTriangle className="h-3.5 w-3.5 text-danger-ink" aria-hidden />
          <span className="text-[10px] font-bold uppercase tracking-[0.12em] text-danger-ink">
            Marine Alert
          </span>
          <span className="ml-auto text-[10px] text-[#c08b84]">{time(msg.ts)}</span>
        </div>
        <p className="mt-1 text-[12px] leading-relaxed text-ink">
          {hi && msg.textHi ? msg.textHi : msg.text}
        </p>
      </div>
    );
  }

  /* orca message */
  if (msg.response) {
    return (
      <div className="msg-in">
        <div className="mb-1.5 flex items-center gap-2">
          <OrcaMark />
          <span className="text-[11px] font-semibold tracking-[0.08em] text-ink">ORCA</span>
          <span className="text-[10px] text-[#9aabb5]">{time(msg.ts)}</span>
          <span className="ml-auto">
            <SpeakButton msg={msg} lang={lang} dict={dict} />
          </span>
        </div>
        <ResultCard msg={msg} dict={dict} lang={lang} agents={agents} onFollowUp={onFollowUp} />
      </div>
    );
  }

  return (
    <div className="msg-in">
      <div className="mb-1.5 flex items-center gap-2">
        <OrcaMark />
        <span className="text-[11px] font-semibold tracking-[0.08em] text-ink">ORCA</span>
        <span className="text-[10px] text-[#9aabb5]">{time(msg.ts)}</span>
        <span className="ml-auto">
          <SpeakButton msg={msg} lang={lang} dict={dict} />
        </span>
      </div>
      <div className="rounded-lg rounded-tl-sm border border-line bg-white px-3.5 py-2.5 shadow-[0_1px_2px_rgba(23,35,45,0.04)]">
        <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-ink">
          {hi && msg.textHi ? msg.textHi : msg.text}
        </p>
      </div>
    </div>
  );
}
