"use client";

import { useEffect, useRef } from "react";
import type { ChatMessage, ProcessingState, AgentStatus } from "@/types/orca";
import type { Dict, Lang } from "@/lib/i18n";
import { MessageBubble } from "./MessageBubble";
import { AgentActivity } from "@/components/analysis/AgentActivity";

export function MessageList({
  messages,
  processing,
  dict,
  lang,
  agents,
  onFollowUp,
}: {
  messages: ChatMessage[];
  processing: ProcessingState | null;
  dict: Dict;
  lang: Lang;
  agents: AgentStatus[];
  onFollowUp: (q: string) => void;
}) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, processing?.step]);

  return (
    <div
      className="chat-scroll flex-1 overflow-y-auto px-4 py-4"
      role="log"
      aria-live="polite"
      aria-label="Conversation"
    >
      <div className="flex flex-col gap-3">
        {messages.map((m) => (
          <MessageBubble
            key={m.id}
            msg={m}
            dict={dict}
            lang={lang}
            agents={agents}
            onFollowUp={onFollowUp}
          />
        ))}
        {processing && (
          <div className="pt-1">
            <AgentActivity processing={processing} dict={dict} />
          </div>
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
