"use client";

import { AlertTriangle, Bell, CheckCircle2, Info, MapPin, X } from "lucide-react";
import type { AppToast } from "@/types/orca";
import type { Dict } from "@/lib/i18n";

/**
 * Professional notification stack (§28, §49, §61).
 * Alert cards slide in from top-right with a single primary action.
 */
export function ToastStack({
  toasts,
  dict,
  onViewMap,
  onDismiss,
}: {
  toasts: AppToast[];
  dict: Dict;
  onViewMap: (alertId: string) => void;
  onDismiss: (id: string) => void;
}) {
  if (!toasts.length) return null;

  return (
    <div
      className="pointer-events-none fixed right-4 top-16 z-[1200] flex w-[320px] flex-col gap-2"
      role="region"
      aria-label="Notifications"
    >
      {toasts.map((t) => {
        if (t.alert) {
          return (
            <div
              key={t.id}
              className="toast-in pointer-events-auto overflow-hidden rounded-lg border border-[#efcfc9] bg-white shadow-[0_8px_24px_rgba(23,35,45,0.14)]"
              role="alert"
            >
              <div className="flex items-start gap-2.5 bg-danger-soft px-3.5 py-2.5">
                <AlertTriangle className="mt-[1px] h-4 w-4 shrink-0 text-danger-ink" aria-hidden />
                <div className="min-w-0 flex-1">
                  <div className="text-[10.5px] font-bold uppercase tracking-[0.1em] text-danger-ink">
                    {t.title}
                  </div>
                  <p className="mt-0.5 text-[12px] leading-snug text-ink">{t.body}</p>
                </div>
                <button
                  type="button"
                  onClick={() => onDismiss(t.id)}
                  aria-label={dict.alertDismiss}
                  className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#b98a83] transition-colors hover:bg-white/70 hover:text-danger-ink"
                >
                  <X className="h-3.5 w-3.5" aria-hidden />
                </button>
              </div>
              <div className="flex items-center gap-2 px-3.5 py-2.5">
                <button
                  type="button"
                  onClick={() => onViewMap(t.alert!.id)}
                  className="flex items-center gap-1.5 rounded-md bg-marine px-3 py-1.5 text-[11.5px] font-medium text-white transition-colors hover:bg-[#0e405f] active:scale-[0.98]"
                >
                  <MapPin className="h-3 w-3" aria-hidden />
                  {dict.alertView}
                </button>
                <button
                  type="button"
                  onClick={() => onDismiss(t.id)}
                  className="rounded-md px-2.5 py-1.5 text-[11.5px] font-medium text-ink-2 transition-colors hover:bg-muted hover:text-ink"
                >
                  {dict.alertDismiss}
                </button>
                <span className="ml-auto text-[9.5px] uppercase tracking-[0.1em] text-[#9aabb5]">
                  {t.alert.live ? (t.alert.sourceLabel ?? "Official source") : "Simulated"}
                </span>
              </div>
            </div>
          );
        }

        const Icon =
          t.kind === "ok" ? CheckCircle2 : t.kind === "alert" ? AlertTriangle : t.kind === "info" ? Bell : Info;
        const iconColor =
          t.kind === "ok" ? "text-good" : t.kind === "alert" ? "text-danger-ink" : "text-marine-2";

        return (
          <div
            key={t.id}
            className="toast-in pointer-events-auto flex items-start gap-2.5 rounded-lg border border-line bg-white px-3.5 py-2.5 shadow-[0_6px_20px_rgba(23,35,45,0.12)]"
          >
            <Icon className={`mt-[1px] h-4 w-4 shrink-0 ${iconColor}`} aria-hidden />
            <div className="min-w-0 flex-1">
              <div className="text-[12px] font-semibold leading-snug text-ink">{t.title}</div>
              {t.body && <p className="mt-0.5 text-[11px] leading-snug text-ink-2">{t.body}</p>}
            </div>
            <button
              type="button"
              onClick={() => onDismiss(t.id)}
              aria-label={dict.alertDismiss}
              className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#9aabb5] transition-colors hover:bg-muted hover:text-ink"
            >
              <X className="h-3.5 w-3.5" aria-hidden />
            </button>
          </div>
        );
      })}
    </div>
  );
}
