"use client";

import { Bell, ChevronDown, FlaskConical, MapPin } from "lucide-react";
import { SonarDome3D } from "@/components/intro/SonarDome3D";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Switch } from "@/components/ui/switch";
import type { MarineLocation } from "@/types/marine";
import type { MarineAlertData } from "@/types/orca";
import type { Dict, Lang } from "@/lib/i18n";

export function AppHeader({
  location,
  locations,
  onLocation,
  lang,
  onLang,
  alerts,
  onSimulateAlert,
  onViewAlert,
  demoMode,
  onDemoMode,
  dict,
}: {
  location: MarineLocation;
  locations: MarineLocation[];
  onLocation: (id: string) => void;
  lang: Lang;
  onLang: (l: Lang) => void;
  alerts: MarineAlertData[];
  onSimulateAlert: () => void;
  onViewAlert: (id: string) => void;
  demoMode: boolean;
  onDemoMode: (v: boolean) => void;
  dict: Dict;
}) {
  const unread = alerts.filter((a) => !a.read).length;

  return (
    <header className="header-in z-[1100] flex h-14 shrink-0 items-center gap-3 border-b border-line bg-white px-4">
      {/* Brand */}
      <div className="flex items-center gap-2.5">
        <span
          className="flex h-7 w-7 items-center justify-center rounded-md bg-marine text-white"
          aria-hidden
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
            <path d="M3 10c2.6 0 2.6 2 5.2 2s2.6-2 5.2-2 2.6 2 5.2 2" />
            <path d="M3 16c2.6 0 2.6 2 5.2 2s2.6-2 5.2-2 2.6 2 5.2 2" opacity="0.6" />
          </svg>
        </span>
        <div className="leading-none">
          <div className="text-[15px] font-bold tracking-[0.02em] text-ink">ORCA</div>
          <div className="mt-[3px] text-[9.5px] font-medium uppercase tracking-[0.16em] text-ink-2">
            {dict.appTag}
          </div>
        </div>
        {/* Live 3D sonar instrument — the station's depth dome */}
        <span className="ml-1 hidden sm:block" aria-hidden>
          <SonarDome3D size={34} />
        </span>
      </div>

      {/* Status */}
      <div className="ml-2 hidden items-center gap-2 md:flex">
        <span className="h-px w-6 bg-line" aria-hidden />
        <span className="flex items-center gap-1.5" title={dict.demoBadge}>
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-good opacity-50" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-good" />
          </span>
          <span className="text-[10.5px] text-ink-2">{dict.systemOk}</span>
        </span>
        <span className="rounded-sm border border-[#cfe0e9] bg-pale px-1.5 py-[3px] text-[9px] font-bold uppercase tracking-[0.12em] text-marine-2">
          {demoMode ? dict.demoBadge : dict.liveBadge}
        </span>
      </div>

      {/* Right controls */}
      <div className="ml-auto flex items-center gap-1.5">
        {/* Demo mode */}
        <div className="mr-1 hidden items-center gap-2 rounded-md border border-line bg-white px-2.5 py-1.5 sm:flex">
          <FlaskConical className="h-3 w-3 text-ink-2" aria-hidden />
          <span className="text-[11px] text-ink-2">{dict.demoMode}</span>
          <Switch
            checked={demoMode}
            onCheckedChange={onDemoMode}
            aria-label={dict.demoMode}
            className="scale-[0.78] data-[state=checked]:bg-marine"
          />
        </div>

        {/* Location */}
        <DropdownMenu>
          <DropdownMenuTrigger
            className="flex h-9 items-center gap-1.5 rounded-md border border-line bg-white px-2.5 text-[12px] text-ink transition-colors hover:bg-pale"
            aria-label={dict.locationLabel}
          >
            <MapPin className="h-3.5 w-3.5 text-marine-2" aria-hidden />
            <span className="hidden max-w-[110px] truncate sm:inline">
              {lang === "hi" ? location.nameHi : location.name}
            </span>
            <ChevronDown className="h-3 w-3 text-ink-2" aria-hidden />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuLabel className="text-[10px] uppercase tracking-[0.12em] text-ink-2">
              {dict.locationLabel}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {locations.map((l) => (
              <DropdownMenuItem
                key={l.id}
                onClick={() => onLocation(l.id)}
                className={`text-[12.5px] ${l.id === location.id ? "bg-pale font-medium text-marine" : ""}`}
              >
                {lang === "hi" ? l.nameHi : l.name}
                <span className="ml-auto text-[10.5px] text-ink-2">
                  {lang === "hi" ? l.stateHi : l.state}
                </span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Language */}
        <DropdownMenu>
          <DropdownMenuTrigger
            className="flex h-9 items-center gap-1 rounded-md border border-line bg-white px-2.5 text-[12px] font-medium text-ink transition-colors hover:bg-pale"
            aria-label="Language"
          >
            {dict.langLabel}
            <ChevronDown className="h-3 w-3 text-ink-2" aria-hidden />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-32">
            <DropdownMenuItem
              onClick={() => onLang("en")}
              className={`text-[12.5px] ${lang === "en" ? "bg-pale font-medium text-marine" : ""}`}
            >
              English
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onLang("hi")}
              className={`text-[12.5px] ${lang === "hi" ? "bg-pale font-medium text-marine" : ""}`}
            >
              हिन्दी
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Alerts */}
        <DropdownMenu>
          <DropdownMenuTrigger
            className="relative flex h-9 w-9 items-center justify-center rounded-md border border-line bg-white text-ink transition-colors hover:bg-pale"
            aria-label={dict.alertBell}
          >
            <Bell className="h-4 w-4" aria-hidden />
            {unread > 0 && (
              <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#b42318] px-1 text-[9px] font-bold text-white">
                {unread}
              </span>
            )}
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-64">
            <DropdownMenuLabel className="text-[10px] uppercase tracking-[0.12em] text-ink-2">
              {dict.alertBell}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {alerts.length === 0 ? (
              <p className="px-3 py-4 text-center text-[11.5px] text-ink-2">{dict.noAlerts}</p>
            ) : (
              alerts.map((a) => (
                <DropdownMenuItem
                  key={a.id}
                  onClick={() => onViewAlert(a.id)}
                  className="flex-col items-start gap-0.5"
                >
                  <span className="text-[11px] font-bold uppercase tracking-[0.08em] text-danger-ink">
                    {lang === "hi" ? a.titleHi : a.title}
                  </span>
                  <span className="text-[11.5px] leading-snug text-ink">
                    {lang === "hi" ? a.bodyHi : a.body}
                  </span>
                </DropdownMenuItem>
              ))
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={onSimulateAlert}
              className="text-[12px] font-medium text-marine"
            >
              <Bell className="h-3 w-3" aria-hidden />
              {dict.simulateAlert}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
