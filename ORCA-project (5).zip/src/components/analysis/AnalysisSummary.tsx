"use client";

import { Check, Database, FileText, MapPin, Waves } from "lucide-react";
import type { AgentStatus } from "@/types/orca";
import type { AnalysisSummaryData } from "@/types/orca";
import type { Dict } from "@/lib/i18n";

const AGENT_ICONS = {
  weatherOcean: Waves,
  geospatialRisk: MapPin,
  dataDiscovery: Database,
  synthesis: FileText,
} as const;

/**
 * Explainability summary (§16, §46) — high-level evidence flow ONLY.
 * No chain-of-thought, no private model reasoning.
 */
export function AnalysisSummary({
  analysis,
  agents,
  dict,
  hi,
}: {
  analysis: AnalysisSummaryData;
  agents: AgentStatus[];
  dict: Dict;
  hi: boolean;
}) {
  const rows: { label: string; value: string }[] = [
    { label: dict.intent, value: hi ? analysis.intentHi : analysis.intent },
    { label: dict.sources, value: hi ? analysis.sourcesHi : analysis.sources },
  ];
  const keyEv = hi ? analysis.keyEvidenceHi : analysis.keyEvidence;

  return (
    <div className="drawer-in mt-3 rounded-lg border border-line bg-[#FAFCFD] p-3.5">
      <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2">
        {dict.analysisTitle}
      </div>

      <dl className="mt-2.5 grid grid-cols-1 gap-x-6 gap-y-2 sm:grid-cols-2">
        {rows.map((r) => (
          <div key={r.label}>
            <dt className="text-[10px] uppercase tracking-[0.1em] text-ink-2">{r.label}</dt>
            <dd className="mt-0.5 text-[12.5px] leading-snug text-ink">{r.value}</dd>
          </div>
        ))}
        <div>
          <dt className="text-[10px] uppercase tracking-[0.1em] text-ink-2">{dict.keyEvidence}</dt>
          <dd className="mt-0.5">
            <ul className="flex flex-col gap-0.5">
              {keyEv.map((e) => (
                <li key={e} className="text-[12.5px] leading-snug text-ink">
                  {e}
                </li>
              ))}
            </ul>
          </dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-[0.1em] text-ink-2">{dict.conclusion}</dt>
          <dd className="mt-0.5 text-[12.5px] font-medium leading-snug text-ink">
            {hi ? analysis.conclusionHi : analysis.conclusion}
          </dd>
        </div>
      </dl>

      <div className="mt-3 border-t border-line pt-2.5">
        <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2">
          {dict.agentsTitle}
        </div>
        <ul className="mt-2 grid grid-cols-1 gap-x-6 gap-y-1.5 sm:grid-cols-2">
          {agents.map((a) => {
            const Icon = AGENT_ICONS[a.id];
            return (
              <li key={a.id} className="flex items-center gap-2">
                <Icon className="h-3.5 w-3.5 shrink-0 text-marine-2" aria-hidden />
                <span className="text-[12px] text-ink">{hi ? a.nameHi : a.name}</span>
                <span className="ml-auto flex items-center gap-1 text-[10.5px] text-good">
                  <Check className="h-3 w-3" strokeWidth={3} aria-hidden />
                  {dict.agentComplete}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
