"use client";

import type { EvidenceItem } from "@/types/orca";
import type { Dict } from "@/lib/i18n";

const CATEGORIES: EvidenceItem["category"][] = [
  "Weather & Ocean",
  "Geospatial & Risk",
  "Marine Data",
];

const CATEGORY_HI: Record<EvidenceItem["category"], string> = {
  "Weather & Ocean": "मौसम व सागर",
  "Geospatial & Risk": "भू-स्थानिक व जोखिम",
  "Marine Data": "समुद्री डेटा",
};

const TONE_CLASS: Record<NonNullable<EvidenceItem["tone"]>, string> = {
  danger: "text-danger-ink",
  warning: "text-warn-ink",
  good: "text-good",
  neutral: "text-ink",
};

function toneClass(tone?: EvidenceItem["tone"]) {
  return TONE_CLASS[tone ?? "neutral"];
}

/**
 * Compact evidence drawer under the map (§26).
 */
export function EvidencePanel({
  evidence,
  open,
  onToggle,
  dict,
  hi,
  headline,
}: {
  evidence: EvidenceItem[] | null;
  open: boolean;
  onToggle: () => void;
  dict: Dict;
  hi: boolean;
  headline?: string;
}) {
  return (
    <div className="border-t border-line bg-white">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="flex w-full items-center gap-3 px-4 py-2 transition-colors hover:bg-[#FAFCFD]"
      >
        <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2">
          {dict.evidenceTitle}
        </span>
        {headline && !open && (
          <span className="truncate text-[11.5px] text-ink-2">{headline}</span>
        )}
        <span className="ml-auto flex items-center gap-1.5">
          {evidence && !open && (
            <span className="rounded-full border border-line bg-pale px-2 py-0.5 text-[10px] font-medium text-marine">
              {evidence.length}
            </span>
          )}
          <svg
            viewBox="0 0 24 24"
            className={`h-3.5 w-3.5 text-ink-2 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden
          >
            <path d="m18 15-6-6-6 6" />
          </svg>
        </span>
      </button>

      {open && (
        <div className="drawer-in px-4 pb-3.5">
          {!evidence ? (
            <p className="py-3 text-[12px] text-ink-2">{dict.evidenceEmpty}</p>
          ) : (
            <div className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-3">
              {CATEGORIES.map((cat) => {
                const items = evidence.filter((e) => e.category === cat);
                if (!items.length) return null;
                return (
                  <div key={cat}>
                    <div className="text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-2">
                      {hi ? CATEGORY_HI[cat] : cat}
                    </div>
                    <dl className="mt-1.5 flex flex-col gap-[3px]">
                      {items.map((it) => (
                        <div
                          key={it.label + it.value}
                          className="flex items-baseline justify-between gap-3 border-b border-dotted border-[#e4ecf0] pb-[3px]"
                        >
                          <dt className="text-[11.5px] leading-snug text-ink-2">
                            {hi ? it.labelHi : it.label}
                          </dt>
                          <dd
                            className={`whitespace-nowrap text-right text-[12px] font-medium leading-snug ${toneClass(it.tone)}`}
                          >
                            {it.value}
                          </dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
