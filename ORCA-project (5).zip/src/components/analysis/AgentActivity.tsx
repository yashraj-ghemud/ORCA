"use client";

import { AlertTriangle, Check, CircleDashed, Loader2, X } from "lucide-react";
import type { ProcessingState } from "@/types/orca";
import type { Dict } from "@/lib/i18n";

/**
 * Live system activity indicator shown while ORCA processes a query (§15, §19).
 * Demo mode: staged timeline. Live mode: per-step REAL statuses — a step is
 * only marked complete after its operation actually succeeded; warn/fail
 * states surface degraded sources honestly.
 */
export function AgentActivity({
  processing,
  dict,
}: {
  processing: ProcessingState;
  dict: Dict;
}) {
  const steps = processing.mode === "live" ? dict.processingStepsLive : dict.processingSteps;
  const states = processing.mode === "live" && processing.steps ? processing.steps : null;

  return (
    <div className="msg-in rounded-lg border border-line bg-white px-3.5 py-3 shadow-[0_1px_2px_rgba(23,35,45,0.05)]">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2">
          {dict.processingTitle}
        </span>
        <span className="flex items-center gap-1.5 text-[10px] text-ink-2">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-marine-2 opacity-60" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-marine-2" />
          </span>
          {processing.mode === "live" ? "live sources" : "live"}
        </span>
      </div>
      <ul className="mt-2.5 flex flex-col gap-[7px]" role="status" aria-live="polite">
        {steps.map((step, i) => {
          const state = states
            ? (states[i] ?? "pending")
            : i < processing.step
              ? ("done" as const)
              : i === processing.step
                ? ("active" as const)
                : ("pending" as const);
          return (
            <li key={step} className="flex items-center gap-2.5">
              {state === "done" && (
                <Check className="h-3.5 w-3.5 shrink-0 text-good" strokeWidth={2.5} aria-hidden />
              )}
              {state === "active" && (
                <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-marine" aria-hidden />
              )}
              {state === "warn" && (
                <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-warn-ink" aria-hidden />
              )}
              {state === "fail" && (
                <X className="h-3.5 w-3.5 shrink-0 text-danger-ink" strokeWidth={2.5} aria-hidden />
              )}
              {state === "pending" && (
                <CircleDashed className="h-3.5 w-3.5 shrink-0 text-[#b7c6cf]" aria-hidden />
              )}
              <span
                className={`text-[12.5px] leading-none ${
                  state === "done"
                    ? "text-ink"
                    : state === "active"
                      ? "font-medium text-marine"
                      : state === "warn"
                        ? "font-medium text-warn-ink"
                        : state === "fail"
                          ? "font-medium text-danger-ink"
                          : "text-[#9aabb5]"
                }`}
              >
                {step}
                {state === "warn" && (
                  <span className="ml-1.5 text-[10px] font-semibold uppercase tracking-wide text-warn-ink">
                    {dict.stepLimited}
                  </span>
                )}
                {state === "fail" && (
                  <span className="ml-1.5 text-[10px] font-semibold uppercase tracking-wide text-danger-ink">
                    {dict.stepFailed}
                  </span>
                )}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
