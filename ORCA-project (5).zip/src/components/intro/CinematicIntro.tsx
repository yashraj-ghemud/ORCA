"use client";

/**
 * ORCA — Cinematic intro orchestrator (v2, mission-control cut).
 *
 * Story board (≈8.4s, skippable):
 *   ACT I  · THE DEEP        — dark navy void, starfield, sonar ping,
 *                              sea coordinates, boot caption typing
 *   ACT II · THE SURFACE     — Three.js ocean reveals as the camera
 *                              pulls back; god-ray shafts, crest glints
 *   ACT III· THE CALL        — ORCA letters surface over a rotating
 *                              radar sweep; crosshair brackets lock on
 *   ACT IV · SYSTEMS ONLINE  — boot checklist types itself out — the
 *                              station powers up for the handoff
 *   ACT V  · THE HANDOFF     — a white bloom floods the screen
 *
 * Routing: plays once per browser session (sessionStorage), supports
 * `?intro=force` / `?intro=off`, honours prefers-reduced-motion and carries
 * multiple failsafes so no user can ever get trapped behind the overlay.
 *
 * (Ported from the original ORCA build; the zustand phase machine was
 * collapsed into local state so the component is fully self-contained.)
 */

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { OceanScene } from "./OceanScene";

const SEEN_KEY = "orca.intro.seen";

/** Act timeline (ms from overlay start). */
const ACT = {
  ocean: 1350,
  title: 3350,
  systems: 5650,
  handoff: 7600,
  end: 8350,
};

type Act = "void" | "ocean" | "title" | "systems" | "handoff";

/* Deterministic starfield (no Math.random at render — stable frames) */
const STARS = [
  { l: 6, t: 12, s: 2, d: 3.1, delay: 0.2 },
  { l: 14, t: 26, s: 1.5, d: 4.2, delay: 1.1 },
  { l: 22, t: 8, s: 2.5, d: 2.7, delay: 0.6 },
  { l: 31, t: 19, s: 1.5, d: 3.8, delay: 1.7 },
  { l: 38, t: 5, s: 2, d: 3.3, delay: 0.9 },
  { l: 45, t: 15, s: 1.5, d: 4.6, delay: 2.2 },
  { l: 52, t: 9, s: 2.5, d: 2.9, delay: 1.4 },
  { l: 58, t: 22, s: 1.5, d: 3.6, delay: 0.3 },
  { l: 66, t: 6, s: 2, d: 4.1, delay: 1.9 },
  { l: 73, t: 17, s: 1.5, d: 3.0, delay: 2.6 },
  { l: 81, t: 11, s: 2.5, d: 3.9, delay: 0.7 },
  { l: 89, t: 24, s: 1.5, d: 2.8, delay: 1.6 },
  { l: 94, t: 9, s: 2, d: 3.4, delay: 2.1 },
  { l: 10, t: 38, s: 1.5, d: 4.4, delay: 1.2 },
  { l: 19, t: 47, s: 2, d: 3.2, delay: 2.4 },
  { l: 84, t: 41, s: 1.5, d: 3.7, delay: 0.5 },
  { l: 92, t: 52, s: 2, d: 2.6, delay: 1.8 },
  { l: 27, t: 33, s: 1.5, d: 4.0, delay: 2.8 },
  { l: 61, t: 36, s: 2, d: 3.5, delay: 0.8 },
  { l: 49, t: 30, s: 1.5, d: 4.3, delay: 2.0 },
] as const;

/* Boot checklist — the station powering up before the handoff */
const BOOT_LINES = [
  { label: "HYDROPHONE UPLINK", status: "ONLINE", type: 0.9, typeDelay: 0.15, tick: 0.95 },
  { label: "AGENT MESH · 5 ONLINE", status: "SYNCED", type: 0.8, typeDelay: 0.55, tick: 1.4 },
  { label: "CHART ENGINE · ESRI OCEAN", status: "READY", type: 0.8, typeDelay: 0.95, tick: 1.8 },
] as const;

/* ── The on-stage show — mounts fresh for every play ────────── */

function IntroStage({ onFinish }: { onFinish: () => void }) {
  const act = useActTimeline(onFinish);

  const oceanOn = act !== "void";
  const titleOn = act === "title" || act === "systems" || act === "handoff";
  const systemsOn = act === "systems" || act === "handoff";

  return (
    <>
      {/* Starfield — fades with the night as the ocean takes over */}
      <motion.div
        className="pointer-events-none absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: act === "void" ? 1 : act === "ocean" ? 0.55 : 0 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        aria-hidden
      >
        {STARS.map((st, i) => (
          <span
            key={i}
            className="intro-star"
            style={{
              left: `${st.l}%`,
              top: `${st.t}%`,
              width: st.s,
              height: st.s,
              "--star-d": `${st.d}s`,
              "--star-delay": `${st.delay}s`,
            } as React.CSSProperties}
          />
        ))}
      </motion.div>

      {/* Moon — crisp core inside a soft halo */}
      <motion.div
        className="pointer-events-none absolute right-[9%] top-[3%]"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: oceanOn ? 1 : 0, scale: oceanOn ? 1 : 0.9 }}
        transition={{ duration: 1.8, ease: "easeOut" }}
      >
        <div className="relative h-[190px] w-[190px]">
          <span
            className="absolute inset-0 rounded-full"
            style={{
              background:
                "radial-gradient(circle, rgba(190,225,250,0.42) 0%, rgba(150,200,240,0.14) 44%, transparent 68%)",
            }}
          />
          <span
            className="absolute left-1/2 top-1/2 h-[52px] w-[52px] -translate-x-1/2 -translate-y-1/2 rounded-full"
            style={{
              background:
                "radial-gradient(circle at 38% 35%, #F4FAFF 0%, #D8ECFB 55%, #B7D9F2 100%)",
              boxShadow: "0 0 36px 12px rgba(214,236,255,0.5)",
            }}
          />
        </div>
      </motion.div>

      {/* Three.js ocean */}
      {oceanOn && (
        <motion.div
          className="absolute inset-x-0 bottom-0 h-[70%]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.4, ease: "easeOut" }}
        >
          <OceanScene className="h-full w-full" />
        </motion.div>
      )}

      {/* God-ray light shafts — moon beams leaning onto the swell */}
      {oceanOn && (
        <motion.div
          className="pointer-events-none absolute inset-x-0 top-0 h-[46%]"
          initial={{ opacity: 0 }}
          animate={{ opacity: titleOn ? 0.85 : 1 }}
          transition={{ duration: 2.2, delay: 0.5, ease: "easeOut" }}
          aria-hidden
        >
          <span
            className="light-shaft left-[16%]"
            style={{ "--shaft-a": "-13deg", "--shaft-o": 0.55, "--shaft-d": "7.2s" } as React.CSSProperties}
          />
          <span
            className="light-shaft left-[38%]"
            style={{ "--shaft-a": "-9deg", "--shaft-o": 0.4, "--shaft-d": "8.4s", "--shaft-delay": "1.2s" } as React.CSSProperties}
          />
          <span
            className="light-shaft left-[64%]"
            style={{ "--shaft-a": "-16deg", "--shaft-o": 0.5, "--shaft-d": "6.4s", "--shaft-delay": "0.6s" } as React.CSSProperties}
          />
        </motion.div>
      )}

      {/* Horizon line glow */}
      <motion.div
        className="pointer-events-none absolute left-0 right-0 h-px"
        style={{
          top: "30.5%",
          background:
            "linear-gradient(90deg, transparent 4%, rgba(140,200,240,0.5) 50%, transparent 96%)",
        }}
        initial={{ opacity: 0, scaleX: 0.4 }}
        animate={{ opacity: oceanOn ? 0.9 : 0, scaleX: 1 }}
        transition={{ duration: 1.6, delay: 0.4 }}
      />

      {/* ACT I — sea coordinates card + sonar ping */}
      <motion.div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: act === "void" ? 1 : 0, y: act === "void" ? 0 : -6 }}
        transition={{ duration: 0.8, delay: act === "void" ? 0.4 : 0 }}
      >
        <div className="flex flex-col items-center gap-4">
          <span className="relative flex h-14 w-14 items-center justify-center">
            <span className="intro-ping absolute inset-0 rounded-full" />
            <span className="intro-ping absolute inset-0 rounded-full" style={{ animationDelay: "1.1s" }} />
            <span className="relative h-2 w-2 rounded-full bg-[#8FD0F5] shadow-[0_0_12px_rgba(143,208,245,0.9)]" />
          </span>
          <p className="font-mono text-[11px] tracking-[0.3em] text-[#7FA9C9]">
            18.92° N · 72.83° E
          </p>
          <p className="text-[10px] uppercase tracking-[0.42em] text-[#5E86A6]">
            Arabian Sea
          </p>
        </div>
      </motion.div>

      {/* ACT I — boot caption typing at the base of the void */}
      <motion.div
        className="absolute inset-x-0 bottom-[16%] flex justify-center px-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: act === "void" ? 1 : 0 }}
        transition={{ duration: 0.5, delay: act === "void" ? 0.55 : 0 }}
      >
        <p className="boot-type type-caret font-mono text-[10px] uppercase tracking-[0.34em] text-[#6E9CC0]"
           style={{ "--type-d": "1.1s", "--type-delay": "0.6s" } as React.CSSProperties}>
          Establishing uplink — Arabian Sea grid
        </p>
      </motion.div>

      {/* ACT III — title surfacing */}
      {titleOn && (
        <div className="absolute inset-x-0 top-[24%] flex flex-col items-center px-4">
          {/* Radar sweep + sonar rings behind the wordmark */}
          <div className="pointer-events-none absolute left-1/2 top-[38%] -translate-x-1/2 -translate-y-1/2" aria-hidden>
            <motion.span
              className="radar-sweep absolute left-1/2 top-1/2 block h-[250px] w-[250px] -translate-x-1/2 -translate-y-1/2"
              initial={{ opacity: 0 }}
              animate={{ opacity: act === "title" ? 0.65 : 0.35 }}
              transition={{ duration: 1.4, delay: 0.5 }}
            />
            <span className="intro-ring block h-40 w-40 rounded-full" />
            <span className="intro-ring absolute left-0 top-0 block h-40 w-40 rounded-full" style={{ animationDelay: "1.3s" }} />
          </div>

          {/* Crosshair brackets lock onto the wordmark */}
          <div className="pointer-events-none absolute left-1/2 top-[30%] h-[118px] w-[min(86vw,560px)] -translate-x-1/2" aria-hidden>
            <span className="bracket-snap absolute left-0 top-0 h-6 w-6 border-l-2 border-t-2 border-[#9FD4F0]/80" style={{ "--br-delay": "0.9s" } as React.CSSProperties} />
            <span className="bracket-snap absolute right-0 top-0 h-6 w-6 border-r-2 border-t-2 border-[#9FD4F0]/80" style={{ "--br-delay": "1.0s" } as React.CSSProperties} />
            <span className="bracket-snap absolute bottom-0 left-0 h-6 w-6 border-b-2 border-l-2 border-[#9FD4F0]/80" style={{ "--br-delay": "1.1s" } as React.CSSProperties} />
            <span className="bracket-snap absolute bottom-0 right-0 h-6 w-6 border-b-2 border-r-2 border-[#9FD4F0]/80" style={{ "--br-delay": "1.2s" } as React.CSSProperties} />
          </div>

          <div className="flex" aria-label="ORCA">
            {"ORCA".split("").map((ch, i) => (
              <motion.span
                key={i}
                className="font-extrabold leading-none text-[#EAF6FF]"
                style={{
                  fontSize: "clamp(58px, 17vw, 148px)",
                  letterSpacing: "0.10em",
                  textShadow:
                    "0 0 26px rgba(120,190,240,0.45), 0 0 70px rgba(60,140,200,0.30)",
                }}
                initial={{ y: 70, opacity: 0, filter: "blur(12px)" }}
                animate={{ y: 0, opacity: 1, filter: "blur(0px)" }}
                transition={{ delay: 0.12 + i * 0.115, type: "spring", stiffness: 200, damping: 21 }}
              >
                {ch}
              </motion.span>
            ))}
          </div>

          <motion.span
            className="mt-4 block h-px w-[min(340px,64vw)] origin-center"
            style={{ background: "linear-gradient(90deg, transparent, rgba(159,212,240,0.9), transparent)" }}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.8, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          />
          <motion.p
            className="mt-5 text-[11px] font-medium uppercase text-[#A9D2EE]"
            style={{ letterSpacing: "0.4em" }}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0, duration: 0.7, ease: "easeOut" }}
          >
            Intelligent Ocean Response
          </motion.p>
          <motion.p
            className="mt-2 text-[9.5px] uppercase text-[#5E86A6]"
            style={{ letterSpacing: "0.26em" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.25, duration: 0.8 }}
          >
            Marine Ecosystem Reasoning · Collaborative Agents
          </motion.p>
        </div>
      )}

      {/* ACT IV — systems boot checklist */}
      {systemsOn && (
        <motion.div
          className="absolute bottom-[9%] left-1/2 w-[min(88vw,340px)] -translate-x-1/2"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          aria-label="ORCA systems booting"
        >
          <div className="rounded-[10px] border border-[#2A4A66]/80 bg-[#04101E]/72 px-4 py-3 shadow-[0_8px_32px_rgba(1,6,12,0.45)] backdrop-blur-md">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-[#7FA9C9]">
                ORCA OS · boot sequence
              </span>
              <span className="intro-star relative block h-1.5 w-1.5 rounded-full bg-[#8FD0F5]" />
            </div>
            <div className="flex flex-col gap-1.5">
              {BOOT_LINES.map((ln) => (
                <div key={ln.label} className="flex items-center justify-between gap-3 font-mono text-[10px]">
                  <span
                    className="boot-type tracking-[0.14em] text-[#B9D8EC]"
                    style={{ "--type-d": `${ln.type}s`, "--type-delay": `${ln.typeDelay}s` } as React.CSSProperties}
                  >
                    {ln.label}
                  </span>
                  <span
                    className="tick-pop inline-flex shrink-0 items-center gap-1 rounded-full border border-[#2E7D5B]/60 bg-[#0B2A1F]/80 px-1.5 py-[1px] text-[8.5px] font-semibold tracking-[0.16em] text-[#7FD6A4]"
                    style={{ "--tick-delay": `${ln.tick}s` } as React.CSSProperties}
                  >
                    <span className="h-1 w-1 rounded-full bg-[#7FD6A4]" />
                    {ln.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* ACT V — the handoff bloom, then a clean white flood */}
      {act === "handoff" && (
        <>
          <motion.div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(circle at 50% 62%, #ffffff 0%, #f2f9ff 34%, rgba(210,235,252,0.9) 60%, rgba(210,235,252,0) 100%)",
            }}
            initial={{ opacity: 0, scale: 0.35 }}
            animate={{ opacity: 1, scale: 1.25 }}
            transition={{ duration: 0.8, ease: "easeIn" }}
          />
          <motion.div
            className="pointer-events-none absolute inset-0 bg-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.42, ease: "easeIn" }}
          />
        </>
      )}
    </>
  );
}

/** Act timeline hook — timers only, no synchronous setState in effects. */
function useActTimeline(onFinish: () => void): Act {
  const [act, setAct] = useState<Act>("void");

  useEffect(() => {
    const t: number[] = [
      window.setTimeout(() => setAct("ocean"), ACT.ocean),
      window.setTimeout(() => setAct("title"), ACT.title),
      window.setTimeout(() => setAct("systems"), ACT.systems),
      window.setTimeout(() => setAct("handoff"), ACT.handoff),
      window.setTimeout(() => onFinish(), ACT.end),
      /* Failsafe — hard ceiling: never hold the app hostage */
      window.setTimeout(() => onFinish(), 12000),
    ];
    return () => {
      t.forEach((id) => window.clearTimeout(id));
    };
  }, [onFinish]);

  return act;
}

/* ── Orchestrator (self-contained — no external store) ──────── */

export function CinematicIntro() {
  const [phase, setPhase] = useState<"boot" | "playing" | "gone">("boot");

  const finish = useCallback(() => {
    try {
      sessionStorage.setItem(SEEN_KEY, "1");
    } catch {
      /* private mode — intro simply replays next session */
    }
    setPhase("gone");
  }, []);

  /* ── Mount decision: play, fast-path, or force ─────────────── */
  useEffect(() => {
    const decide = () => {
      const params = new URLSearchParams(window.location.search);
      const force = params.get("intro") === "force";
      const off = params.get("intro") === "off";
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      let seen = false;
      try {
        seen = sessionStorage.getItem(SEEN_KEY) === "1";
      } catch {
        seen = false;
      }
      if (off || reduced || (seen && !force)) {
        setPhase("gone");
      } else {
        setPhase("playing");
      }
    };
    decide();

    /* Failsafe — if somehow still gating the app, recover */
    const recovery = window.setTimeout(() => {
      setPhase((p) => (p === "boot" ? "gone" : p));
    }, 3000);
    return () => window.clearTimeout(recovery);
  }, [finish]);

  if (phase === "boot") return null;

  return (
    <AnimatePresence>
      {phase === "playing" && (
        <motion.div
          key="orca-intro"
          aria-label="ORCA cinematic introduction"
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-[2000] overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.55, ease: "easeOut" } }}
          transition={{ duration: 0.45, ease: "easeOut" }}
        >
          {/* Night sky */}
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, #01050B 0%, #04101E 34%, #082038 58%, #0E3050 80%, #16466B 100%)",
            }}
          />

          {/* The show */}
          <IntroStage onFinish={finish} />

          {/* Vignette */}
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(ellipse at center, transparent 52%, rgba(1,6,12,0.5) 100%)",
            }}
          />

          {/* Skip */}
          <motion.button
            type="button"
            onClick={finish}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1, duration: 0.6 }}
            className="absolute bottom-[max(20px,env(safe-area-inset-bottom))] right-5 z-10 rounded-full border border-white/25 bg-white/10 px-4 py-2 text-[12px] font-medium text-white/85 backdrop-blur-md transition-colors hover:bg-white/20 active:scale-95"
          >
            Skip intro →
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
