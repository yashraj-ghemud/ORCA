"use client";

import { useLayoutEffect, useRef, useState } from "react";
import type L from "leaflet";
import {
  Ban,
  CircleCheck,
  CircleDashed,
  Eye,
  Fish,
  Ship,
  Thermometer,
  TriangleAlert,
  Waves,
  Wind,
  X,
} from "lucide-react";
import type { SpotFacts } from "@/lib/spot-analysis";
import type { Dict, Lang } from "@/lib/i18n";
import { fmtCoord } from "@/lib/map-utils";

const CARD_W = 292;

const VERDICT_STYLE = {
  safe: { chip: "bg-good-soft text-good", dot: "bg-good", Icon: CircleCheck },
  caution: { chip: "bg-warn-soft text-warn-ink", dot: "bg-warn-ink", Icon: TriangleAlert },
  unsafe: { chip: "bg-danger-soft text-danger-ink", dot: "bg-danger-ink", Icon: TriangleAlert },
  restricted: { chip: "bg-danger-soft text-danger-ink", dot: "bg-danger-ink", Icon: Ban },
  unknown: { chip: "bg-pale text-info-ink", dot: "bg-marine-2", Icon: CircleDashed },
} as const;

function toneClass(tone: "danger" | "warning" | "good" | "neutral") {
  switch (tone) {
    case "danger":
      return "text-danger-ink";
    case "warning":
      return "text-warn-ink";
    case "good":
      return "text-good";
    default:
      return "text-ink";
  }
}

export interface SpotCardProps {
  map: L.Map;
  facts: SpotFacts;
  lang: Lang;
  dict: Dict;
  onClose: () => void;
  onAsk: () => void;
}

/**
 * Floating intelligence card anchored to a tapped sea point.
 * Follows the point during pan/zoom and flips below when near the top edge.
 */
export function SpotCard({ map, facts, lang, dict, onClose, onAsk }: SpotCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [cardH, setCardH] = useState(340);
  const [, forceTick] = useState(0);

  /* re-measure + reposition while the map moves/zooms */
  useLayoutEffect(() => {
    if (ref.current) setCardH(ref.current.offsetHeight);
    const bump = () => forceTick((n) => n + 1);
    map.on("move zoom", bump);
    return () => {
      map.off("move zoom", bump);
    };
  }, [map, facts]);

  const s = dict.spot;
  const hi = lang === "hi";
  const verdict = VERDICT_STYLE[facts.verdict];
  const verdictText =
    facts.verdict === "safe"
      ? s.verdictSafe
      : facts.verdict === "caution"
        ? s.verdictCaution
        : facts.verdict === "unsafe"
          ? s.verdictUnsafe
          : facts.verdict === "restricted"
            ? s.verdictRestricted
            : s.verdictUnknown;
  const verdictSub =
    facts.verdict === "safe"
      ? s.verdictSafeSub
      : facts.verdict === "caution"
        ? s.verdictCautionSub
        : facts.verdict === "unsafe"
          ? s.verdictUnsafeSub
          : facts.verdict === "restricted"
            ? s.verdictRestrictedSub
            : s.verdictUnknownSub;

  /* scene lines, worst first */
  const scene: { text: string; tone: "danger" | "warning" | "good" | "neutral" }[] = [];
  if (facts.beyondBoundary) scene.push({ text: s.restricted, tone: "danger" });
  if (facts.insideHazard)
    scene.push({
      text: s.insideHazard(
        hi ? facts.insideHazard.labelHi : facts.insideHazard.label,
        hi ? facts.insideHazard.reasonHi : facts.insideHazard.reason
      ),
      tone: "danger",
    });
  if (facts.cyInside && facts.cyName)
    scene.push({
      text: s.cyInside(
        facts.cyName,
        facts.cyCategory ?? "",
        hi ? facts.cyMovementHi ?? "" : facts.cyMovement ?? ""
      ),
      tone: "danger",
    });
  if (facts.cyNear && facts.cyName && facts.cyDistKm != null)
    scene.push({ text: s.cyNear(facts.cyName, facts.cyDistKm), tone: "warning" });
  if (facts.insideSafe)
    scene.push({
      text: s.insideSafe(hi ? facts.insideSafe.noteHi : facts.insideSafe.note),
      tone: "good",
    });
  if (!facts.beyondBoundary && facts.boundaryDistKm <= 8)
    scene.push({ text: s.nearBoundary(facts.boundaryDistKm), tone: "warning" });
  if (scene.length === 0) scene.push({ text: s.openSea, tone: "neutral" });

  const waveTone =
    facts.waveM == null ? "neutral" : facts.waveM >= 3 ? "danger" : facts.waveM >= 2 ? "warning" : "neutral";
  const windTone =
    facts.windKmh == null ? "neutral" : facts.windKmh >= 30 ? "danger" : facts.windKmh >= 20 ? "warning" : "neutral";
  const fmt = (v: number | null, unit: string) => (v == null ? "—" : `${v} ${unit}`);

  /* anchor position */
  const pt = map.latLngToContainerPoint([facts.lat, facts.lng]);
  const size = map.getSize();
  let left = pt.x - CARD_W / 2;
  left = Math.max(10, Math.min(left, Math.max(10, size.x - CARD_W - 10)));
  let top = pt.y - cardH - 18;
  const flipped = top < 10;
  if (flipped) top = pt.y + 20;
  top = Math.max(10, Math.min(top, Math.max(10, size.y - cardH - 10)));
  const arrowLeft = Math.max(14, Math.min(pt.x - left, CARD_W - 20));

  return (
    <>
      {/* tap anchor dot */}
      <div
        className="pointer-events-none absolute z-[640]"
        style={{ left: pt.x - 5, top: pt.y - 5 }}
        aria-hidden
      >
        <span className="absolute inline-flex h-[10px] w-[10px] animate-ping rounded-full bg-marine opacity-60" />
        <span className="relative inline-flex h-[10px] w-[10px] rounded-full border-2 border-white bg-marine shadow-[0_1px_3px_rgba(23,35,45,0.4)]" />
      </div>

      <div
        ref={ref}
        role="dialog"
        aria-label={s.label}
        className="msg-in absolute z-[650] select-none"
        style={{ left, top, width: CARD_W, maxWidth: "calc(100vw - 24px)" }}
      >
        <div className="relative rounded-lg border border-line bg-white/97 shadow-[0_4px_16px_rgba(23,35,45,0.14)] backdrop-blur-sm">
          {/* pointer arrow */}
          <span
            aria-hidden
            className={`absolute h-2.5 w-2.5 rotate-45 border-line bg-white ${
              flipped ? "-top-[5px] border-l border-t" : "-bottom-[5px] border-r border-b"
            }`}
            style={{ left: arrowLeft }}
          />

          {/* header */}
          <div className="flex items-start justify-between gap-2 border-b border-line px-3 pt-2.5 pb-2">
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-ink-2">
                {s.label}
              </div>
              <div className="mt-0.5 font-mono text-[10px] tracking-wide text-ink-2">
                {fmtCoord(facts.lat, "N", "S")} · {fmtCoord(facts.lng, "E", "W")}
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="rounded-md p-1 text-ink-2 transition-colors hover:bg-pale hover:text-ink"
            >
              <X className="h-3.5 w-3.5" aria-hidden />
            </button>
          </div>

          {/* verdict */}
          <div className="px-3 pt-2.5">
            <div
              className={`flex items-center gap-1.5 self-start rounded-md px-2 py-1 text-[11px] font-bold tracking-wide ${verdict.chip}`}
            >
              <verdict.Icon className="h-3.5 w-3.5" aria-hidden />
              {verdictText}
            </div>
            <div className="mt-1 text-[11px] leading-snug text-ink-2">{verdictSub}</div>
          </div>

          {/* PFZ banner */}
          {facts.insidePFZ && (
            <div className="mx-3 mt-2.5 flex items-start gap-1.5 rounded-md bg-teal-soft px-2 py-1.5">
              <Fish className="mt-[1px] h-3.5 w-3.5 shrink-0 text-teal-700" aria-hidden />
              <div className="text-[10.5px] leading-snug text-[#0f5e57]">
                {s.insidePFZ(facts.insidePFZ.likelySpecies.join(", "))}
              </div>
            </div>
          )}

          {/* scene */}
          <div className="px-3 pt-2.5">
            <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-ink-2">
              {s.scene}
            </div>
            <ul className="mt-1 flex flex-col gap-1">
              {scene.map((line, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span
                    aria-hidden
                    className={`mt-[5px] h-1.5 w-1.5 shrink-0 rounded-full ${
                      line.tone === "danger"
                        ? "bg-danger-ink"
                        : line.tone === "warning"
                          ? "bg-warn-ink"
                          : line.tone === "good"
                            ? "bg-good"
                            : "bg-[#8296a3]"
                    }`}
                  />
                  <span className={`text-[10.5px] leading-snug ${toneClass(line.tone)}`}>
                    {line.text}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* conditions grid */}
          <div className="px-3 pt-2.5">
            <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-ink-2">
              {s.conditions}
            </div>
            <div className="mt-1 grid grid-cols-2 gap-1.5">
              <div className="flex items-center gap-1.5 rounded-md border border-line bg-pale/60 px-2 py-1.5">
                <Waves className="h-3.5 w-3.5 shrink-0 text-marine-2" aria-hidden />
                <div className="leading-tight">
                  <div className="text-[8.5px] uppercase tracking-wide text-ink-2">
                    {s.waveLabel}
                  </div>
                  <div className={`text-[11px] font-semibold ${toneClass(waveTone)}`}>
                    {fmt(facts.waveM, hi ? "मी" : "m")}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 rounded-md border border-line bg-pale/60 px-2 py-1.5">
                <Wind className="h-3.5 w-3.5 shrink-0 text-marine-2" aria-hidden />
                <div className="leading-tight">
                  <div className="text-[8.5px] uppercase tracking-wide text-ink-2">
                    {s.windLabel}
                  </div>
                  <div className={`text-[11px] font-semibold ${toneClass(windTone)}`}>
                    {fmt(facts.windKmh, hi ? "किमी/घं" : "km/h")} {facts.windDir}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 rounded-md border border-line bg-pale/60 px-2 py-1.5">
                <Thermometer className="h-3.5 w-3.5 shrink-0 text-marine-2" aria-hidden />
                <div className="leading-tight">
                  <div className="text-[8.5px] uppercase tracking-wide text-ink-2">
                    {s.sstLabel}
                  </div>
                  <div className="text-[11px] font-semibold text-ink">{fmt(facts.sstC, "°C")}</div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 rounded-md border border-line bg-pale/60 px-2 py-1.5">
                <Eye className="h-3.5 w-3.5 shrink-0 text-marine-2" aria-hidden />
                <div className="leading-tight">
                  <div className="text-[8.5px] uppercase tracking-wide text-ink-2">
                    {s.visLabel}
                  </div>
                  <div className="text-[11px] font-semibold text-ink">
                    {fmt(facts.visKm, hi ? "किमी" : "km")}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* footer */}
          <div className="flex items-center justify-between gap-2 px-3 py-2.5">
            <div className="flex items-center gap-1 text-[10px] text-ink-2">
              <Ship className="h-3 w-3" aria-hidden />
              {facts.mode === "live"
                ? s.fromMonitor(facts.distFromVesselKm, facts.bearingFromVessel)
                : s.fromVessel(facts.distFromVesselKm, facts.bearingFromVessel)}
            </div>
            <span className="text-[8.5px] uppercase tracking-[0.1em] text-ink-2/70">
              {facts.mode === "live"
                ? facts.verdict === "unknown"
                  ? s.liveNoData
                  : s.liveNote
                : s.demoNote}
            </span>
          </div>

          <div className="px-3 pb-3">
            <button
              type="button"
              onClick={onAsk}
              className="flex w-full items-center justify-center gap-1.5 rounded-md bg-marine px-3 py-2 text-[11.5px] font-semibold text-white transition-colors hover:bg-marine-2"
            >
              {s.askOrca}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
