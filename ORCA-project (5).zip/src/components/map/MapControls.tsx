"use client";

import type { LayerToggles, MapViewId } from "@/types/orca";
import type { Lang } from "@/lib/i18n";
import type { Dict } from "@/lib/i18n";
import { Check, ChevronDown, Layers, MousePointerClick, Navigation2 } from "lucide-react";
import { useState } from "react";

const LAYER_KEYS: (keyof LayerToggles)[] = [
  "vessel",
  "risk",
  "pfz",
  "weather",
  "boundaries",
  "seaState",
];

export function MapControls({
  layers,
  onToggleLayer,
  legendItems,
  lang,
  dict,
  hasQuery,
  locationName,
  regionName,
}: {
  layers: LayerToggles;
  onToggleLayer: (k: keyof LayerToggles) => void;
  legendItems: { key: string; color: string; shape: "circle" | "square" | "line" | "dot" }[];
  lang: Lang;
  dict: Dict;
  hasQuery: boolean;
  locationName: string;
  regionName: string;
}) {
  const [panelOpen, setPanelOpen] = useState(
    () => typeof window === "undefined" || window.innerWidth >= 1024
  );

  return (
    <>
      {/* Title chip — top left */}
      <div className="absolute left-3 top-3 z-[600] pointer-events-none">
        <div className="rounded-lg border border-line bg-white/95 px-3 py-2 shadow-[0_1px_3px_rgba(23,35,45,0.1)] backdrop-blur-sm">
          <div className="text-[9.5px] font-semibold uppercase tracking-[0.14em] text-ink-2">
            {dict.mapTitle}
          </div>
          <div className="mt-0.5 flex items-center gap-1.5">
            <Navigation2 className="h-3 w-3 text-marine" aria-hidden />
            <span className="text-[13px] font-semibold leading-tight text-ink">{locationName}</span>
          </div>
          <div className="text-[10.5px] leading-tight text-ink-2">{regionName}</div>
        </div>
      </div>

      {/* Hint chip — center top */}
      {!hasQuery && (
        <div className="pointer-events-none absolute left-1/2 top-3.5 z-[550] -translate-x-1/2">
          <div className="msg-in whitespace-nowrap rounded-full border border-line bg-white/95 px-3.5 py-1.5 text-[11.5px] text-ink-2 shadow-[0_1px_3px_rgba(23,35,45,0.1)] backdrop-blur-sm">
            {dict.mapHint}
            <div className="mt-0.5 flex items-center justify-center gap-1 text-[10.5px] font-medium text-marine">
              <MousePointerClick className="h-3 w-3" aria-hidden />
              {dict.tapHint}
            </div>
          </div>
        </div>
      )}

      {/* Layer panel — below title chip, left control column */}
      <div className="absolute left-3 top-[86px] z-[600]">
        <div className="overflow-hidden rounded-lg border border-line bg-white/97 shadow-[0_1px_3px_rgba(23,35,45,0.1)] backdrop-blur-sm">
          <button
            type="button"
            onClick={() => setPanelOpen((v) => !v)}
            className="flex w-full items-center justify-between gap-6 px-3 py-2 transition-colors hover:bg-pale"
            aria-expanded={panelOpen}
            aria-label={dict.layers}
          >
            <span className="flex items-center gap-1.5 text-[9.5px] font-semibold uppercase tracking-[0.14em] text-ink-2">
              <Layers className="h-3 w-3" aria-hidden />
              {dict.layers}
            </span>
            <ChevronDown
              className={`h-3.5 w-3.5 text-ink-2 transition-transform duration-200 ${panelOpen ? "" : "-rotate-90"}`}
              aria-hidden
            />
          </button>
          {panelOpen && (
            <div className="border-t border-line px-1.5 py-1.5">
              {LAYER_KEYS.map((k) => (
                <button
                  key={k}
                  type="button"
                  role="checkbox"
                  aria-checked={layers[k]}
                  onClick={() => onToggleLayer(k)}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-[5px] text-left transition-colors hover:bg-pale"
                >
                  <span
                    className={`flex h-[14px] w-[14px] shrink-0 items-center justify-center rounded-[4px] border transition-colors ${
                      layers[k] ? "border-marine bg-marine" : "border-[#b9c8d1] bg-white"
                    }`}
                    aria-hidden
                  >
                    {layers[k] && <Check className="h-[10px] w-[10px] text-white" strokeWidth={3} />}
                  </span>
                  <span className="text-[11.5px] text-ink">{dict.layerNames[k]}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Legend — bottom left */}
      {legendItems.length > 0 && (
        <div className="absolute bottom-14 left-3 z-[600]">
          <div className="rounded-lg border border-line bg-white/95 px-3 py-2 shadow-[0_1px_3px_rgba(23,35,45,0.1)] backdrop-blur-sm">
            <div className="text-[9.5px] font-semibold uppercase tracking-[0.14em] text-ink-2">
              {dict.legend}
            </div>
            <div className="mt-1.5 flex flex-col gap-1">
              {legendItems.map((it) => (
                <div key={it.key} className="flex items-center gap-2">
                  <span
                    aria-hidden
                    className={
                      it.shape === "circle"
                        ? "h-2.5 w-2.5 rounded-full border-[1.5px]"
                        : it.shape === "square"
                          ? "h-2.5 w-2.5 rounded-[2px]"
                          : it.shape === "line"
                            ? "h-[2px] w-3.5 rounded-full"
                            : "h-2.5 w-2.5 rounded-full"
                    }
                    style={{
                      background: it.shape === "circle" ? `${it.color}26` : it.color,
                      borderColor: it.shape === "circle" ? it.color : "transparent",
                    }}
                  />
                  <span className="text-[11px] leading-tight text-ink">
                    {dict.legendItems[it.key]}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
