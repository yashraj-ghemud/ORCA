"use client";

import { Circle, CircleMarker, Marker, Polygon, Polyline, Tooltip } from "react-leaflet";
import type { CycloneInfo, MarineLocation, PFZZone, RoutePath, SeaArrow, WindArrow } from "@/types/marine";
import type { RiskCell } from "@/services/marine/types";
import type { Lang } from "@/lib/i18n";
import {
  vesselIcon,
  cycloneIcon,
  flagIcon,
  seaArrowIcon,
  windArrowIcon,
} from "@/lib/map-icons";
import { ZONE, kmToMeters } from "@/lib/map-utils";

/* ---------------- Vessel ---------------- */
export function VesselMarker({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  return (
    <Marker
      position={[loc.vessel.position.lat, loc.vessel.position.lng]}
      icon={vesselIcon(loc.vessel.headingDeg)}
      zIndexOffset={800}
    >
      <Tooltip direction="top" offset={[0, -14]} className="zone-label" opacity={1} permanent>
        {lang === "hi" ? "पोत" : "Vessel"} · {loc.vessel.name}
      </Tooltip>
    </Marker>
  );
}

/* ---------------- Hazard zone ---------------- */
export function HazardLayer({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  return (
    <>
      {loc.hazardZones.map((h) => (
        <Circle
          key={h.id}
          center={[h.center.lat, h.center.lng]}
          radius={kmToMeters(h.radiusKm)}
          pathOptions={{
            fillColor: ZONE.hazardFill,
            fillOpacity: 0.16,
            color: ZONE.hazardStroke,
            opacity: 0.6,
            weight: 1.5,
            dashArray: "5 5",
            className: "zone-fade",
          }}
        >
          <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
            {lang === "hi" ? h.labelHi : h.label}
          </Tooltip>
        </Circle>
      ))}
    </>
  );
}

/* ---------------- Cyclone influence ---------------- */
export function CycloneLayer({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  const cy = loc.cyclone;
  if (!cy) return null;
  return (
    <>
      <Circle
        center={[cy.center.lat, cy.center.lng]}
        radius={kmToMeters(cy.influenceRadiusKm)}
        pathOptions={{
          fillColor: ZONE.cycloneFill,
          fillOpacity: 0.075,
          color: ZONE.cycloneStroke,
          opacity: 0.28,
          weight: 1,
          dashArray: "2 7",
          className: "zone-fade",
        }}
      >
        <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
          {lang === "hi" ? "चक्रवात प्रभाव" : "Cyclone influence"} · {cy.distanceKm} km {cy.bearing}
        </Tooltip>
      </Circle>
      <Marker position={[cy.center.lat, cy.center.lng]} icon={cycloneIcon()} zIndexOffset={400}>
        <Tooltip direction="top" offset={[0, -16]} className="zone-label" opacity={1}>
          {cy.name} — {cy.category}
        </Tooltip>
      </Marker>
    </>
  );
}

/* ---------------- Safe zone ---------------- */
export function SafeZoneLayer({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  return (
    <>
      {loc.safeZones.map((s) => (
        <Circle
          key={s.id}
          center={[s.center.lat, s.center.lng]}
          radius={kmToMeters(s.radiusKm)}
          pathOptions={{
            fillColor: ZONE.safeFill,
            fillOpacity: 0.1,
            color: ZONE.safeStroke,
            opacity: 0.45,
            weight: 1.5,
            dashArray: "7 5",
            className: "zone-fade",
          }}
        >
          <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
            {lang === "hi" ? s.labelHi : s.label}
          </Tooltip>
        </Circle>
      ))}
    </>
  );
}

/* ---------------- PFZ ---------------- */
export function PFZLayer({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  return (
    <>
      {loc.pfzZones.map((p) => (
        <Polygon
          key={p.id}
          positions={p.polygon}
          pathOptions={{
            fillColor: ZONE.pfzFill,
            fillOpacity: 0.16,
            color: ZONE.pfzStroke,
            opacity: 0.65,
            weight: 2,
            className: "zone-fade",
          }}
        >
          <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
            {lang === "hi" ? p.labelHi : p.label} · {p.distanceKm} km
          </Tooltip>
        </Polygon>
      ))}
    </>
  );
}

/* ---------------- Route ---------------- */
export function RouteLayer({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  const rt = loc.route;
  const dest = rt.points[rt.points.length - 1];
  return (
    <>
      <Polyline
        positions={rt.points}
        pathOptions={{
          color: ZONE.route,
          opacity: 0.85,
          weight: 3.5,
          lineCap: "round",
          className: "route-line",
        }}
      >
        <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
          {lang === "hi" ? "सुझाया गया सुरक्षित मार्ग" : "Suggested safer path"} · {rt.distanceKm} km
        </Tooltip>
      </Polyline>
      <Marker position={dest} icon={flagIcon()} zIndexOffset={600}>
        <Tooltip direction="right" offset={[10, 0]} className="zone-label" opacity={1} permanent>
          {lang === "hi" ? rt.destinationHi : rt.destination}
        </Tooltip>
      </Marker>
    </>
  );
}

/* ---------------- Boundary ---------------- */
export function BoundaryLayer({ loc, lang }: { loc: MarineLocation; lang: Lang }) {
  return (
    <Polyline
      positions={loc.boundary.points}
      pathOptions={{
        color: ZONE.boundary,
        opacity: 0.6,
        weight: 1.5,
        dashArray: "1 8",
        lineCap: "round",
      }}
    >
      <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1}>
        {lang === "hi" ? loc.boundary.labelHi : loc.boundary.label}
      </Tooltip>
    </Polyline>
  );
}

/* ---------------- Sea state + wind arrows ---------------- */
export function SeaStateLayer({ loc }: { loc: MarineLocation }) {
  return (
    <>
      {loc.seaArrows.map((a, i) => (
        <Marker
          key={`sea-${i}`}
          position={[a.position.lat, a.position.lng]}
          icon={seaArrowIcon(a.dirDeg, a.label)}
          interactive={false}
        />
      ))}
    </>
  );
}

export function WindLayer({ loc }: { loc: MarineLocation }) {
  return (
    <>
      {loc.windArrows.map((a, i) => (
        <Marker
          key={`wind-${i}`}
          position={[a.position.lat, a.position.lng]}
          icon={windArrowIcon(a.dirDeg)}
          interactive={false}
        />
      ))}
    </>
  );
}

/* ================================================================ */
/* LIVE-mode layers — dynamic data, official sources labeled          */
/* ================================================================ */

/** Live mode: monitored position marker (no real AIS positions exist). */
export function MonitoredMarker({ loc, label }: { loc: MarineLocation; label: string }) {
  return (
    <CircleMarker
      center={[loc.center.lat, loc.center.lng]}
      radius={7}
      pathOptions={{
        color: "#124e78",
        weight: 2.5,
        fillColor: "#124e78",
        fillOpacity: 0.9,
      }}
    >
      <Tooltip direction="top" offset={[0, -12]} className="zone-label" opacity={1} permanent>
        {label}
      </Tooltip>
    </CircleMarker>
  );
}

const RISK_CELL_STYLE: Record<string, { fill: string; stroke: string }> = {
  CRITICAL: { fill: "#b42318", stroke: "#b42318" },
  HIGH: { fill: "#c2410c", stroke: "#c2410c" },
  MODERATE: { fill: "#b45309", stroke: "#b45309" },
  LOW: { fill: "#15803d", stroke: "#15803d" },
  UNKNOWN: { fill: "#8296a3", stroke: "#8296a3" },
};

/** Dynamic "Marine risk (model)" cells from the server risk sampler. */
export function LiveRiskLayer({ cells, label }: { cells: RiskCell[]; label: string }) {
  return (
    <>
      {cells.map((c, i) => {
        const st = RISK_CELL_STYLE[c.level] ?? RISK_CELL_STYLE.UNKNOWN;
        return (
          <Circle
            key={`rc-${i}`}
            center={[c.lat, c.lng]}
            radius={kmToMeters(c.radiusKm)}
            pathOptions={{
              fillColor: st.fill,
              fillOpacity: c.level === "UNKNOWN" ? 0.05 : 0.1,
              color: st.stroke,
              opacity: 0.3,
              weight: 1,
              className: "zone-fade",
            }}
          >
            <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1}>
              {c.level === "UNKNOWN" ? label : `${label} · ${c.level}`}
            </Tooltip>
          </Circle>
        );
      })}
    </>
  );
}

/** Official IMD cyclone overlay (or a clearly-labeled demo substitute). */
export function CycloneInfoLayer({ cy, lang }: { cy: CycloneInfo; lang: Lang }) {
  const srcLabel = cy.demo
    ? lang === "hi"
      ? "चक्रवात (डेमो)"
      : "Cyclone (DEMO)"
    : lang === "hi"
      ? "चक्रवात (IMD)"
      : "Cyclone (IMD)";
  return (
    <>
      <Circle
        center={[cy.center.lat, cy.center.lng]}
        radius={kmToMeters(cy.influenceRadiusKm)}
        pathOptions={{
          fillColor: ZONE.cycloneFill,
          fillOpacity: 0.075,
          color: ZONE.cycloneStroke,
          opacity: 0.28,
          weight: 1,
          dashArray: "2 7",
          className: "zone-fade",
        }}
      >
        <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
          {srcLabel} · {cy.distanceKm} km {cy.bearing}
        </Tooltip>
      </Circle>
      <Marker position={[cy.center.lat, cy.center.lng]} icon={cycloneIcon()} zIndexOffset={400}>
        <Tooltip direction="top" offset={[0, -16]} className="zone-label" opacity={1}>
          {cy.name} — {cy.category} {cy.demo ? "· simulated" : "(IMD)"}
        </Tooltip>
      </Marker>
    </>
  );
}

/** Official INCOIS PFZ polygons. */
export function LivePFZLayer({ zones }: { zones: PFZZone[] }) {
  return (
    <>
      {zones.map((p) => (
        <Polygon
          key={p.id}
          positions={p.polygon}
          pathOptions={{
            fillColor: ZONE.pfzFill,
            fillOpacity: 0.16,
            color: ZONE.pfzStroke,
            opacity: 0.65,
            weight: 2,
            className: "zone-fade",
          }}
        >
          <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
            {p.label} · {p.distanceKm} km
          </Tooltip>
        </Polygon>
      ))}
    </>
  );
}

/** A* route result. */
export function RouteLayerLive({ route, lang }: { route: RoutePath; lang: Lang }) {
  const dest = route.points[route.points.length - 1];
  return (
    <>
      <Polyline
        positions={route.points}
        pathOptions={{
          color: ZONE.route,
          opacity: 0.85,
          weight: 3.5,
          lineCap: "round",
          className: "route-line",
        }}
      >
        <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1} permanent>
          {lang === "hi" ? "सुझाया गया कम-जोखिम मार्ग" : "Suggested lower-risk path"} · {route.distanceKm} km
        </Tooltip>
      </Polyline>
      <Marker position={dest} icon={flagIcon()} zIndexOffset={600}>
        <Tooltip direction="right" offset={[10, 0]} className="zone-label" opacity={1} permanent>
          {lang === "hi" ? route.destinationHi : route.destination}
        </Tooltip>
      </Marker>
    </>
  );
}

export function SeaStateLayerLive({ arrows }: { arrows: SeaArrow[] }) {
  return (
    <>
      {arrows.map((a, i) => (
        <Marker
          key={`lsea-${i}`}
          position={[a.position.lat, a.position.lng]}
          icon={seaArrowIcon(a.dirDeg, a.label)}
          interactive={false}
        />
      ))}
    </>
  );
}

export function WindLayerLive({ arrows }: { arrows: WindArrow[] }) {
  return (
    <>
      {arrows.map((a, i) => (
        <Marker
          key={`lwind-${i}`}
          position={[a.position.lat, a.position.lng]}
          icon={windArrowIcon(a.dirDeg)}
          interactive={false}
        />
      ))}
    </>
  );
}

export function BoundaryPointsLayer({
  points,
  label,
}: {
  points: [number, number][];
  label: string;
}) {
  return (
    <Polyline
      positions={points}
      pathOptions={{
        color: ZONE.boundary,
        opacity: 0.6,
        weight: 1.5,
        dashArray: "1 8",
        lineCap: "round",
      }}
    >
      <Tooltip direction="top" offset={[0, 0]} className="zone-label" opacity={1}>
        {label}
      </Tooltip>
    </Polyline>
  );
}
