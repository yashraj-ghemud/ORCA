"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import L from "leaflet";
import { MapContainer, ScaleControl, TileLayer, useMap, useMapEvents } from "react-leaflet";
import type { LatLng, MarineLocation } from "@/types/marine";
import type { LayerToggles, MapViewId } from "@/types/orca";
import type { Lang } from "@/lib/i18n";
import type { LiveMapData } from "@/services/orca/query-service";
import { fmtCoord } from "@/lib/map-utils";
import { analyzeSpot, analyzeSpotLive } from "@/lib/spot-analysis";
import { SpotCard } from "./SpotCard";
import {
  BoundaryLayer,
  BoundaryPointsLayer,
  CycloneInfoLayer,
  CycloneLayer,
  HazardLayer,
  LivePFZLayer,
  LiveRiskLayer,
  MonitoredMarker,
  PFZLayer,
  RouteLayer,
  RouteLayerLive,
  SafeZoneLayer,
  SeaStateLayer,
  SeaStateLayerLive,
  VesselMarker,
  WindLayer,
  WindLayerLive,
} from "./layers";
import { MapControls } from "./MapControls";

export interface MapCommand {
  ts: number;
  center: LatLng;
  zoom: number;
}

/* Fly-to controller — animates map when chat state changes (§24, §25) */
function MapController({ cmd }: { cmd: MapCommand | null }) {
  const map = useMap();
  useEffect(() => {
    if (!cmd) return;
    map.flyTo([cmd.center.lat, cmd.center.lng], cmd.zoom, { duration: 1.7, easeLinearity: 0.24 });
  }, [cmd, map]);
  return null;
}

function ResizeHandler() {
  const map = useMap();
  useEffect(() => {
    /* Settle the layout before and after fonts/images shift the flexbox */
    const delays = [60, 250, 700, 1400, 2400];
    const timers = delays.map((d) => setTimeout(() => map.invalidateSize(), d));
    const fix = () => map.invalidateSize();
    window.addEventListener("resize", fix);
    return () => {
      timers.forEach(clearTimeout);
      window.removeEventListener("resize", fix);
    };
  }, [map]);
  return null;
}

function CursorReadout({ onMove }: { onMove: (lat: number, lng: number) => void }) {
  useMapEvents({
    mousemove: (e) => onMove(e.latlng.lat, e.latlng.lng),
  });
  return null;
}

/* Map tap → spot check + reposition bus for the floating card */
function TapLayer({ onTap, onMove }: { onTap: (lat: number, lng: number) => void; onMove: () => void }) {
  useMapEvents({
    click: (e) => onTap(e.latlng.lat, e.latlng.lng),
    move: onMove,
    zoom: onMove,
  });
  return null;
}

function MapBinder({ onMap }: { onMap: (m: L.Map) => void }) {
  const map = useMap();
  useEffect(() => {
    onMap(map);
  }, [map, onMap]);
  return null;
}

function ZoomSetup() {
  const map = useMap();
  useEffect(() => {
    const zoom = L.control.zoom({ position: "bottomright" });
    map.addControl(zoom);
    return () => {
      map.removeControl(zoom);
    };
  }, [map]);
  return null;
}

/** One-time cinematic fly-in on first map load (website opening animation). */
function IntroFly({ loc }: {
  loc: { center: { lat: number; lng: number }; defaultZoom: number };
}) {
  const map = useMap();
  useEffect(() => {
    let cancelled = false;
    const t = setTimeout(() => {
      if (cancelled) return;
      map.setView([loc.center.lat + 1.4, loc.center.lng - 0.6], Math.max(5, loc.defaultZoom - 2.4), {
        animate: false,
      });
      map.flyTo([loc.center.lat, loc.center.lng], loc.defaultZoom, { duration: 2.1, easeLinearity: 0.18 });
    }, 420);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [map]);
  return null;
}

export interface MarineMapProps {
  location: MarineLocation;
  view: MapViewId;
  cmd: MapCommand | null;
  layers: LayerToggles;
  onToggleLayer: (k: keyof LayerToggles) => void;
  lang: Lang;
  dict: Parameters<typeof MapControls>[0]["dict"];
  hasQuery: boolean;
  onAskSpot: (lat: number, lng: number) => void;
  /** "demo" = simulated dataset, "live" = server-fetched marine context */
  mode: "demo" | "live";
  /** live map data from the last ORCA query (null until first query) */
  live: LiveMapData | null;
}

export default function MarineMap({
  location: loc,
  view,
  cmd,
  layers,
  onToggleLayer,
  lang,
  dict,
  hasQuery,
  onAskSpot,
  mode,
  live,
}: MarineMapProps) {
  const [cursor, setCursor] = useState<{ lat: number; lng: number } | null>(null);
  const [map, setMap] = useState<L.Map | null>(null);
  const [tap, setTap] = useState<{ lat: number; lng: number } | null>(null);
  /* point-accurate live data fetched for the tapped spot (works before any
     chat query — the whole point of "tap anywhere, get that spot's status") */
  const [tapLive, setTapLive] = useState<LiveMapData | null>(null);
  const [tapLoading, setTapLoading] = useState(false);
  const tapCacheRef = useRef<Map<string, LiveMapData>>(new Map());
  const routeVisible = view === "route";
  const safeVisible = (view === "safety" || view === "route") && layers.risk;

  const handleTap = useCallback(
    (lat: number, lng: number) => {
      setTap({ lat, lng });
      setTapLive(null);
      if (mode !== "live") return;
      /* 0.25° grid cache — nearby taps reuse the fetch */
      const key = `${lat.toFixed(2)}:${lng.toFixed(2)}`;
      const cached = tapCacheRef.current.get(key);
      if (cached) {
        setTapLive(cached);
        return;
      }
      setTapLoading(true);
      fetch(`/api/marine/map?lat=${lat.toFixed(3)}&lon=${lng.toFixed(3)}`)
        .then((r) => r.json())
        .then((d) => {
          if (d?.ok && d?.mapData) {
            /* keep the cache small — oldest entries drop first */
            if (tapCacheRef.current.size > 12) {
              const oldest = tapCacheRef.current.keys().next().value;
              if (oldest != null) tapCacheRef.current.delete(oldest);
            }
            tapCacheRef.current.set(key, d.mapData as LiveMapData);
            setTapLive(d.mapData as LiveMapData);
          }
        })
        .catch(() => {
          /* fallback below uses boot `live` data when the point fetch fails */
        })
        .finally(() => setTapLoading(false));
    },
    [mode]
  );

  const closeTap = useCallback(() => {
    setTap(null);
    setTapLive(null);
    setTapLoading(false);
  }, []);

  /* close the spot card when the monitored location or a chat fly-to changes
     (render-time state adjustment — React "you might not need an effect" pattern) */
  const flyKey = `${loc.id}:${cmd?.ts ?? 0}`;
  const [lastFlyKey, setLastFlyKey] = useState(flyKey);
  if (lastFlyKey !== flyKey) {
    setLastFlyKey(flyKey);
    setTap(null);
    setTapLive(null);
  }

  const spotFacts = useMemo(() => {
    if (!tap) return null;
    if (mode === "live") {
      /* point-fetched data first (accurate at the tap), boot bundle fallback */
      const src = tapLive ?? live;
      return src ? analyzeSpotLive(src, loc, tap.lat, tap.lng) : null;
    }
    return analyzeSpot(loc, tap.lat, tap.lng);
  }, [tap, loc, mode, live, tapLive]);

  /* Legend derives only from ACTIVE objects (§59) */
  const legendItems: { key: string; color: string; shape: "circle" | "square" | "line" | "dot" }[] = [];
  if (layers.vessel)
    legendItems.push({
      key: mode === "live" ? "monitored" : "vessel",
      color: "#124e78",
      shape: "dot",
    });
  if (layers.risk) {
    if (mode === "live") {
      legendItems.push({ key: "riskModel", color: "#c2410c", shape: "circle" });
    } else {
      legendItems.push({ key: "hazard", color: "#c2410c", shape: "circle" });
      if (safeVisible) legendItems.push({ key: "safe", color: "#15803d", shape: "circle" });
    }
  }
  if (layers.weather) {
    if (mode === "live" && live?.cyclone)
      legendItems.push({ key: "cyclone", color: "#b91c1c", shape: "circle" });
    if (mode === "demo" && loc.cyclone)
      legendItems.push({ key: "cyclone", color: "#b91c1c", shape: "circle" });
  }
  if (layers.pfz) {
    if (mode === "live" && live?.pfz?.length)
      legendItems.push({ key: "pfz", color: "#0f766e", shape: "square" });
    if (mode === "demo") legendItems.push({ key: "pfz", color: "#0f766e", shape: "square" });
  }
  if (routeVisible) {
    if (mode === "live" && live?.route) legendItems.push({ key: "route", color: "#0e7490", shape: "line" });
    if (mode === "demo") legendItems.push({ key: "route", color: "#0e7490", shape: "line" });
  }
  if (layers.boundaries) legendItems.push({ key: "boundary", color: "#8296a3", shape: "line" });
  if (layers.seaState) {
    if (mode === "demo") legendItems.push({ key: "sea", color: "#2f6f95", shape: "dot" });
    if (mode === "live" && live?.seaArrows.length)
      legendItems.push({ key: "sea", color: "#2f6f95", shape: "dot" });
  }

  /* live honest-state chips (PFZ / cyclone unavailable, §21) */
  const liveChips: string[] = [];
  if (mode === "live" && live) {
    if (layers.pfz && live.pfz === null) liveChips.push(dict.spot.pfzUnavailable);
    if (layers.weather && !live.cyclone) liveChips.push(dict.spot.cycloneUnavailable);
  }

  return (
    <div className="relative h-full w-full">
      <MapContainer
        center={[loc.center.lat, loc.center.lng]}
        zoom={loc.defaultZoom}
        minZoom={5}
        maxZoom={14}
        zoomControl={false}
        zoomSnap={0.25}
        zoomDelta={0.5}
        attributionControl
        className="map-fade-in h-full w-full"
        maxBounds={[
          [3, 64],
          [27, 94],
        ]}
        maxBoundsViscosity={0.7}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
          className="map-tiles"
          keepBuffer={3}
        />

        <MapController cmd={cmd} />
        <IntroFly loc={loc} />
        <ResizeHandler />
        <ZoomSetup />
        <MapBinder onMap={setMap} />
        <TapLayer onTap={handleTap} onMove={() => {}} />
        <CursorReadout onMove={(lat, lng) => setCursor({ lat, lng })} />
        <ScaleControl position="bottomright" imperial={false} />

        {/* Vessel / monitored position */}
        {layers.vessel &&
          (mode === "live" ? (
            <MonitoredMarker loc={loc} label={dict.spot.monitored} />
          ) : (
            <VesselMarker loc={loc} lang={lang} />
          ))}

        {layers.risk &&
          (mode === "live" ? (
            live && (
              <LiveRiskLayer
                cells={live.riskCells}
                label={lang === "hi" ? "जोखिम (मॉडल)" : "Risk (model)"}
              />
            )
          ) : (
            <HazardLayer loc={loc} lang={lang} />
          ))}
        {mode === "demo" && safeVisible && <SafeZoneLayer loc={loc} lang={lang} />}
        {layers.weather &&
          (mode === "live" ? (
            live?.cyclone && <CycloneInfoLayer cy={live.cyclone} lang={lang} />
          ) : (
            <CycloneLayer loc={loc} lang={lang} />
          ))}
        {layers.weather &&
          (mode === "live" ? (
            live && <WindLayerLive arrows={live.windArrows} />
          ) : (
            <WindLayer loc={loc} />
          ))}
        {layers.pfz && mode === "live" && live?.pfz && live.pfz.length > 0 && (
          <LivePFZLayer zones={live.pfz} />
        )}
        {layers.pfz && mode === "demo" && <PFZLayer loc={loc} lang={lang} />}
        {routeVisible &&
          (mode === "live" ? (
            live?.route && <RouteLayerLive route={live.route} lang={lang} />
          ) : (
            <RouteLayer loc={loc} lang={lang} />
          ))}
        {layers.boundaries &&
          (mode === "live" && live?.boundary ? (
            <BoundaryPointsLayer
              points={live.boundary.points}
              label={lang === "hi" ? "अपतट सीमा (लगभग)" : "Offshore boundary (approx.)"}
            />
          ) : (
            <BoundaryLayer loc={loc} lang={lang} />
          ))}
        {layers.seaState &&
          (mode === "live" ? (
            live && <SeaStateLayerLive arrows={live.seaArrows} />
          ) : (
            <SeaStateLayer loc={loc} />
          ))}
      </MapContainer>

      {/* live honest-state chips (PFZ / cyclone unavailable) */}
      {liveChips.length > 0 && (
        <div className="pointer-events-none absolute left-3 top-24 z-[560] flex max-w-[240px] flex-col gap-1.5">
          {liveChips.map((chip) => (
            <div
              key={chip}
              className="rounded-md border border-[#edd9bc] bg-warn-soft/95 px-2.5 py-1.5 text-[10.5px] font-medium leading-snug text-warn-ink shadow-[0_1px_3px_rgba(23,35,45,0.1)] backdrop-blur-sm"
            >
              {chip}
            </div>
          ))}
        </div>
      )}

      <MapControls
        layers={layers}
        onToggleLayer={onToggleLayer}
        legendItems={legendItems}
        lang={lang}
        dict={dict}
        hasQuery={hasQuery}
        locationName={lang === "hi" ? loc.nameHi : loc.name}
        regionName={`${lang === "hi" ? loc.stateHi : loc.state} · ${lang === "hi" ? loc.regionHi : loc.region}`}
      />

      {/* tap spot-check card */}
      {map && spotFacts && (
        <SpotCard
          map={map}
          facts={spotFacts}
          lang={lang}
          dict={dict}
          onClose={closeTap}
          onAsk={() => onAskSpot(spotFacts.lat, spotFacts.lng)}
        />
      )}

      {/* spot scan pill — per-tap live fetch in progress */}
      {tapLoading && (
        <div className="pointer-events-none absolute bottom-14 left-1/2 z-[600] -translate-x-1/2">
          <div className="flex items-center gap-2 rounded-full border border-line bg-white/92 px-3 py-1.5 text-[11px] font-medium text-ink-2 shadow-[0_2px_10px_rgba(23,35,45,0.14)] backdrop-blur-sm">
            <span className="h-3 w-3 animate-spin rounded-full border-2 border-marine border-t-transparent" />
            {lang === "hi" ? "स्पॉट स्कैन हो रहा है…" : "Scanning spot…"}
          </div>
        </div>
      )}

      {/* Cursor coordinate readout — bottom right */}
      <div className="pointer-events-none absolute bottom-3 right-12 z-[600] flex items-center gap-2">
        <div className="rounded-md border border-line bg-white/90 px-2 py-1 font-mono text-[10px] tracking-wide text-ink-2 backdrop-blur-sm">
          {cursor
            ? `${fmtCoord(cursor.lat, "N", "S")}  ${fmtCoord(cursor.lng, "E", "W")}`
            : `${fmtCoord(loc.center.lat, "N", "S")}  ${fmtCoord(loc.center.lng, "E", "W")}`}
        </div>
      </div>
    </div>
  );
}
