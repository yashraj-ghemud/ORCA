/**
 * POST /api/orca/query — aggregate live-mode query endpoint (§25).
 *
 * Request:  { query, location: {lat, lon, name?, id?}, targetTime?, vesselProfile?, lang? }
 * Response: { ok, requestId, flow, response, ops, mapData, sources, risk, dataQuality }
 *
 * All source access happens server-side; no credentials ever reach the client.
 */

import { NextResponse } from "next/server";
import { runOrcaQuery, type OrcaQueryResult } from "@/services/orca/query-service";
import { MARINE_LOCATIONS } from "@/lib/demo-data/mock-marine-data";

export async function POST(req: Request) {
  const started = Date.now();
  let body: {
    query?: string;
    location?: { lat?: number; lon?: number; name?: string; id?: string };
    targetTime?: string;
    vesselProfile?: string;
    lang?: string;
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: { code: "bad_request", message: "Invalid JSON body" } },
      { status: 400 }
    );
  }

  const query = (body.query ?? "").trim();
  if (!query) {
    return NextResponse.json(
      { ok: false, error: { code: "bad_request", message: "query is required" } },
      { status: 400 }
    );
  }

  /* resolve location: explicit lat/lon wins, else fall back to a monitored location */
  let lat = body.location?.lat;
  let lon = body.location?.lon;
  let name = body.location?.name;
  let id = body.location?.id;
  if (typeof lat !== "number" || typeof lon !== "number" || !Number.isFinite(lat) || !Number.isFinite(lon)) {
    const base = MARINE_LOCATIONS.find((l) => l.id === id) ?? MARINE_LOCATIONS[0];
    lat = base.center.lat;
    lon = base.center.lng;
    name = name ?? base.name;
    id = base.id;
  }
  if (typeof lat !== "number" || typeof lon !== "number" || !Number.isFinite(lat) || !Number.isFinite(lon)) {
    return NextResponse.json(
      { ok: false, error: { code: "bad_request", message: "location.lat/lon must be numbers" } },
      { status: 400 }
    );
  }

  const lang = body.lang === "hi" ? "hi" : "en";
  const boundarySpec = id
    ? (() => {
        const base = MARINE_LOCATIONS.find((l) => l.id === id);
        return base ? { points: base.boundary.points, label: base.boundary.label } : null;
      })()
    : null;

  try {
    const result: OrcaQueryResult = await runOrcaQuery({
      query,
      location: { lat, lon, name, id },
      targetTime: body.targetTime,
      vesselProfile: body.vesselProfile,
      lang,
      boundary: boundarySpec,
    });

    /* ---- observability (§31): no secrets, no PII ---- */
    console.log(
      JSON.stringify({
        requestId: result.requestId,
        type: "orca_query",
        queryType: result.flow,
        location: { lat, lon, name },
        sourceStatuses: result.sources.map((s) => ({
          source: s.source,
          kind: s.kind,
          status: s.status,
          latencyMs: s.latencyMs,
        })),
        riskLevel: result.risk.level,
        dataQuality: result.dataQuality,
        totalLatencyMs: Date.now() - started,
      })
    );

    return NextResponse.json(result);
  } catch (err) {
    console.error(
      JSON.stringify({
        type: "orca_query_error",
        message: err instanceof Error ? err.message : "unknown",
        totalLatencyMs: Date.now() - started,
      })
    );
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "query_failed",
          message: "Marine data services could not be reached. Please try again shortly.",
        },
      },
      { status: 502 }
    );
  }
}
