import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * POST /api/tts
 * body: { text: string, lang?: "en" | "hi", voice?: string, speed?: number }
 * res:  { segments: string[] }  — base64 WAV chunks played sequentially by the client
 *
 * Constraints (z-ai TTS): input <= 1024 chars per request, speed 0.5–2.0,
 * non-streaming only for wav. Long text is split at sentence boundaries here.
 */

const MAX_INPUT_TOTAL = 4200; // hard guard on request size (chars)
const CHUNK_LEN = 880; // stay safely under the 1024-char API limit
const MAX_SEGMENTS = 5; // spoken briefing cap (~4400 chars)

type ZaiClient = {
  audio: {
    tts: {
      create: (opts: Record<string, unknown>) => Promise<Response>;
    };
  };
};

let zaiPromise: Promise<ZaiClient> | null = null;
async function getZai(): Promise<ZaiClient> {
  if (!zaiPromise) {
    zaiPromise = import("z-ai-web-dev-sdk").then(
      (m) => m.default.create() as unknown as Promise<ZaiClient>
    );
  }
  return zaiPromise;
}

/* ---------------- Devanagari → Latin transliteration ----------------
 * The TTS voices speak English/Chinese; Devanagari input is unreadable to
 * them. Hindi UI text is transliterated to Latin so briefings remain spoken. */

const VOWELS: Record<string, string> = {
  अ: "a", आ: "aa", इ: "i", ई: "ee", उ: "u", ऊ: "oo", ऋ: "ri", ए: "e",
  ऐ: "ai", ओ: "o", औ: "au", ऑ: "o",
};
const MATRAS: Record<string, string> = {
  "ा": "aa", "ि": "i", "ी": "ee", "ु": "u", "ू": "oo", "ृ": "ri", "े": "e",
  "ै": "ai", "ो": "o", "ौ": "au", "ॉ": "o",
};
const CONSONANTS: Record<string, string> = {
  क: "k", ख: "kh", ग: "g", घ: "gh", ङ: "ng", च: "ch", छ: "chh", ज: "j",
  झ: "jh", ञ: "ny", ट: "t", ठ: "th", ड: "d", ढ: "dh", ण: "n", त: "t",
  थ: "th", द: "d", ध: "dh", न: "n", प: "p", फ: "ph", ब: "b", भ: "bh",
  म: "m", य: "y", र: "r", ल: "l", व: "v", श: "sh", ष: "sh", स: "s",
  ह: "h", ळ: "l", क़: "k", ख़: "kh", ग़: "g", ज़: "z", ड़: "r", ढ़: "rh",
  फ़: "f", य़: "y",
};
const SIGNS: Record<string, string> = { "ं": "n", "ँ": "n", "ः": "h", "़": "" };

function transliterateDevanagari(input: string): string {
  if (!/[\u0900-\u097F]/.test(input)) return input;
  return input
    .split(/(\s+)/)
    .map((word) => {
      if (/^\s+$/.test(word) || !/[\u0900-\u097F]/.test(word)) return word;
      let out = "";
      for (let i = 0; i < word.length; i++) {
        const ch = word[i];
        if (CONSONANTS[ch] !== undefined) {
          out += CONSONANTS[ch];
          const next = word[i + 1];
          if (next === "\u094D") {
            /* virama — consonant cluster, no inherent vowel */
            i++;
          } else if (MATRAS[next] === undefined && SIGNS[next] === undefined) {
            out += "a";
          }
        } else if (VOWELS[ch] !== undefined) {
          out += VOWELS[ch];
        } else if (MATRAS[ch] !== undefined) {
          out += MATRAS[ch];
        } else if (SIGNS[ch] !== undefined) {
          out += SIGNS[ch];
        } else if (ch === "।" || ch === "॥") {
          out += ".";
        } else {
          out += ch; /* digits, punctuation, Latin — pass through */
        }
      }
      return out;
    })
    .join("");
}

/* ---------------- speech text cleaning ---------------- */

function cleanForSpeech(raw: string): string {
  return raw
    .replace(
      /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{2B00}-\u{2BFF}\u{2190}-\u{21FF}]/gu,
      " "
    )
    .replace(/[*_#`>|~·•▪►]/g, " ")
    .replace(/°C/gi, " degrees Celsius ")
    .replace(/°/g, " degrees ")
    .replace(/%/g, " percent ")
    .replace(/&/g, " and ")
    .replace(/(\d(?:\.\d+)?)\s*km\/h\b/gi, "$1 kilometers per hour")
    .replace(/(\d(?:\.\d+)?)\s*km\b/gi, "$1 kilometers")
    .replace(/(\d(?:\.\d+)?)\s*m(?![a-zA-Z])/g, "$1 meters")
    .replace(/\s*[:;]\s*/g, ". ")
    .replace(/\s+/g, " ")
    .trim();
}

/* ---------------- sentence-aware chunking ---------------- */

function splitChunks(text: string, maxLen = CHUNK_LEN): string[] {
  const sentences = text.split(/(?<=[.!?।])\s+/);
  const chunks: string[] = [];
  let current = "";
  for (const sentence of sentences) {
    if (!sentence) continue;
    if ((current + " " + sentence).trim().length <= maxLen) {
      current = (current + " " + sentence).trim();
    } else {
      if (current) chunks.push(current);
      if (sentence.length <= maxLen) {
        current = sentence;
      } else {
        /* very long sentence — hard split on word boundaries */
        let rest = sentence;
        while (rest.length > maxLen) {
          let cut = rest.lastIndexOf(" ", maxLen);
          if (cut < maxLen * 0.5) cut = maxLen;
          chunks.push(rest.slice(0, cut).trim());
          rest = rest.slice(cut).trim();
        }
        current = rest;
      }
    }
  }
  if (current) chunks.push(current);
  return chunks.filter(Boolean);
}

/* ---------------- route handler ---------------- */

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      text?: string;
      lang?: string;
      voice?: string;
      speed?: number;
    };

    const raw = (body.text ?? "").trim();
    if (!raw) {
      return NextResponse.json({ error: "Text is required" }, { status: 400 });
    }
    if (raw.length > MAX_INPUT_TOTAL) {
      return NextResponse.json(
        { error: "Text too long for a voice briefing" },
        { status: 413 }
      );
    }

    const lang = body.lang === "hi" ? "hi" : "en";
    const voice = body.voice ?? (lang === "hi" ? "tongtong" : "xiaochen");
    const speed =
      typeof body.speed === "number" && body.speed >= 0.5 && body.speed <= 2
        ? body.speed
        : 1.0;

    const cleaned = cleanForSpeech(lang === "hi" ? transliterateDevanagari(raw) : raw);
    if (!cleaned) {
      return NextResponse.json({ error: "Nothing speakable in text" }, { status: 400 });
    }

    const chunks = splitChunks(cleaned).slice(0, MAX_SEGMENTS);
    if (chunks.length === 0) {
      return NextResponse.json({ error: "Nothing speakable in text" }, { status: 400 });
    }

    const zai = await getZai();
    const segments: string[] = [];

    for (const chunk of chunks) {
      try {
        const response = await zai.audio.tts.create({
          input: chunk,
          voice,
          speed,
          response_format: "wav",
          stream: false,
        });
        const arrayBuffer = await response.arrayBuffer();
        if (arrayBuffer.byteLength > 44) {
          segments.push(Buffer.from(new Uint8Array(arrayBuffer)).toString("base64"));
        }
      } catch (err) {
        console.error("[api/tts] segment failed:", err);
        /* keep going — partial briefing is better than none */
      }
    }

    if (segments.length === 0) {
      return NextResponse.json(
        { error: "Voice generation failed" },
        { status: 502 }
      );
    }

    return NextResponse.json(
      { segments, voice, chunks: chunks.length },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("[api/tts] error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Voice generation failed" },
      { status: 500 }
    );
  }
}
