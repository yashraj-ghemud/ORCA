import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * POST /api/asr
 * body: { audio: string } — base64-encoded audio (16 kHz mono WAV from the client)
 * res:  { text: string }
 *
 * The browser records via MediaRecorder, decodes + resamples to 16 kHz mono
 * WAV locally (src/lib/audio-record.ts) and posts the base64 payload here.
 */

const MAX_BASE64_LEN = 10 * 1024 * 1024; // ~10 MB guard

type ZaiClient = {
  audio: {
    asr: {
      create: (opts: { file_base64: string }) => Promise<{ text?: string }>;
    };
  };
};

let zaiPromise: Promise<ZaiClient> | null = null;
async function getZai(): Promise<ZaiClient> {
  if (!zaiPromise) {
    zaiPromise = import("z-ai-web-dev-sdk").then(
      (m) => m.default.create() as unknown as Promise<ZaiClient>
    );
  }
  return zaiPromise;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { audio?: string };
    const audio = body.audio;

    if (!audio || typeof audio !== "string") {
      return NextResponse.json({ error: "Audio payload is required" }, { status: 400 });
    }
    if (audio.length > MAX_BASE64_LEN) {
      return NextResponse.json({ error: "Recording too long" }, { status: 413 });
    }

    const zai = await getZai();
    const response = await zai.audio.asr.create({ file_base64: audio });
    const text = (response?.text ?? "").trim();

    return NextResponse.json(
      { text },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("[api/asr] error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Speech recognition failed" },
      { status: 500 }
    );
  }
}
