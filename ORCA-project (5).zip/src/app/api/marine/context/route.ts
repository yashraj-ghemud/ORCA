/**
 * GET /api/marine/context?lat=&lon=&targetTime=&id=
 * Debug/diagnostic endpoint returning the raw normalized MarineContext.
 * Useful for the integration test path (scripts/test-marine.ts) and clients
 * that want conditions without a full ORCA response.
 */

import { NextResponse } from "next/server";
import { getMarineContext } from "@/services/marine";
import { tomorrowMorningIst } from "@/services/orca/query-service";
import { MARINE_LOCATIONS } from "@/lib/demo-data/mock-marine-data";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  let lat = Number(url.searchParams.get("lat"));
  let lon = Number(url.searchParams.get("lon"));

  if (!Number.isFinite(lat) || !Number.isFinite(lon) || (lat === 0 && lon === 0)) {
    const base = MARINE_LOCATIONS.find((l) => l.id === id) ?? MARINE_LOCATIONS[0];
    lat = base.center.lat;
    lon = base.center.lng;
  }

  const targetTime = url.searchParams.get("targetTime") ?? tomorrowMorningIst();
  const base = MARINE_LOCATIONS.find((l) => l.id === id);

  try {
    const context = await getMarineContext(
      { lat, lon, name: url.searchParams.get("name") ?? base?.name },
      targetTime,
      base ? { points: base.boundary.points, label: base.boundary.label } : undefined
    );
    return NextResponse.json({ ok: true, context });
  } catch (err) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "context_failed",
          message: err instanceof Error ? err.message : "unknown error",
        },
      },
      { status: 502 }
    );
  }
}
