/**
 * GET /api/marine/map?id=mumbai  |  ?lat=&lon=
 *
 * Lightweight live map bundle — the chat query flow's map data WITHOUT a
 * chat/LLM response. Powers:
 *   - boot map layers (risk cells, wind/sea arrows, PFZ, cyclone) so the
 *     map is interactive before the first ORCA query
 *   - per-tap spot analysis: pass ?lat=&lon= for point-accurate conditions
 *
 * Every value follows the same honesty rules as /api/marine/context:
 * real Open-Meteo model data + clearly-labeled SIMULATED substitutes for
 * unconfigured official sources.
 */

import { NextResponse } from "next/server";
import { buildLiveMapBundle, tomorrowMorningIst } from "@/services/orca/query-service";
import { MARINE_LOCATIONS } from "@/lib/demo-data/mock-marine-data";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  let lat = Number(url.searchParams.get("lat"));
  let lon = Number(url.searchParams.get("lon"));

  /* no/invalid coordinates → resolve a monitored location by id (or default) */
  let base = MARINE_LOCATIONS.find((l) => l.id === id);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || (lat === 0 && lon === 0)) {
    base = base ?? MARINE_LOCATIONS[0];
    lat = base.center.lat;
    lon = base.center.lng;
  }

  const targetTime = url.searchParams.get("targetTime") ?? tomorrowMorningIst();

  try {
    const bundle = await buildLiveMapBundle(
      { lat, lon, name: base?.name ?? url.searchParams.get("name") ?? undefined },
      {
        targetTime,
        boundary: base ? { points: base.boundary.points, label: base.boundary.label } : null,
      }
    );
    return NextResponse.json({
      ok: true,
      mapData: bundle.mapData,
      riskLevel: bundle.risk.level,
      sources: bundle.context.sourceMeta,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "map_failed",
          message: err instanceof Error ? err.message : "unknown error",
        },
      },
      { status: 502 }
    );
  }
}
