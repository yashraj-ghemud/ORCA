/**
 * GET /api/marine/status — source availability report (§20, §30).
 * Reports which sources are configured and probes the free source live.
 * Never returns secrets — only configuration booleans and statuses.
 */

import { NextResponse } from "next/server";
import { imdConfigured } from "@/services/marine/imd";
import { incoisConfigured } from "@/services/marine/incois";
import { pfzConfigured } from "@/services/marine/pfz";
import { getOpenMeteoMarineForecast, getOpenMeteoWeather } from "@/services/marine/openMeteo";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const probe = url.searchParams.get("probe") === "1";
  const lat = Number(url.searchParams.get("lat")) || 18.92;
  const lon = Number(url.searchParams.get("lon")) || 72.83;

  const report: Record<string, unknown> = {
    IMD: {
      configured: imdConfigured(),
      note: imdConfigured()
        ? "Credentials configured — verify endpoint paths against current IMD API docs."
        : "Requires official IMD API subscription (imdapi.org). Set IMD_API_BASE_URL + IMD_API_KEY.",
    },
    INCOIS: {
      configured: incoisConfigured(),
      note: incoisConfigured()
        ? "Data interface configured."
        : "No verified public JSON API for Ocean State Forecast; set INCOIS_API_BASE_URL with an official interface.",
    },
    INCOIS_PFZ: {
      configured: pfzConfigured(),
      note: pfzConfigured()
        ? "PFZ interface configured."
        : "PFZ advisories are bulletin/GIS products; set INCOIS_API_BASE_URL with an official interface.",
    },
    OPEN_METEO: { configured: true, note: "Free key-less marine/weather model (fallback/supplement)." },
  };

  if (probe) {
    const [marine, weather] = await Promise.all([
      getOpenMeteoMarineForecast(lat, lon),
      getOpenMeteoWeather(lat, lon),
    ]);
    report.OPEN_METEO = {
      configured: true,
      note: "Free key-less marine/weather model (fallback/supplement).",
      probe: {
        marine: marine.ok ? { status: marine.meta.status, waveHeightM: marine.ocean.waveHeightM } : { status: "unavailable", note: marine.meta.note },
        weather: weather.ok ? { status: weather.meta.status, windSpeedMps: weather.weather.windSpeedMps } : { status: "unavailable", note: weather.meta.note },
      },
    };
  }

  return NextResponse.json({ ok: true, sources: report, checkedAt: new Date().toISOString() });
}
