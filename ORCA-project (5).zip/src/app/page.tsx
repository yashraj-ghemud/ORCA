"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { AppHeader } from "@/components/AppHeader";
import { ChatPanel } from "@/components/chat/ChatPanel";
import { EvidencePanel } from "@/components/analysis/EvidencePanel";
import { CinematicIntro } from "@/components/intro/CinematicIntro";
import { OceanRibbon } from "@/components/intro/OceanRibbon";
import { ToastStack } from "@/components/alerts/MarineAlert";
import { MARINE_LOCATIONS, getLocation } from "@/lib/demo-data/mock-marine-data";
import { buildResponse, deriveRisk, PROCESSING_TIMELINE, resolveFlow, DEMO_SEQUENCE } from "@/lib/mock-orca";
import { STR, t, type Lang } from "@/lib/i18n";
import { LAYER_DEFAULTS } from "@/lib/map-utils";
import { orcaSpeakText } from "@/lib/speakable";
import { setVoiceErrorHandler, speakMessage, stopSpeaking } from "@/lib/voice-client";
import type { LiveMapData } from "@/services/orca/query-service";
import type { LiveStrip } from "@/components/chat/SuggestedQueries";
import type {
  AgentStatus,
  ChatMessage,
  LayerToggles,
  MapViewId,
  MarineAlertData,
  OrcaResponse,
  ProcessingState,
  AppToast,
  StepState,
} from "@/types/orca";
import type { RiskLevel as RiskLevel5 } from "@/services/marine/types";
import type { MapCommand } from "@/components/map/MarineMap";

const MarineMap = dynamic(() => import("@/components/map/MarineMap"), {
  ssr: false,
  loading: () => (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-[#e8eff3]">
      {/* A living 3D sea while the chart boots */}
      <OceanRibbon className="pointer-events-none absolute inset-x-0 bottom-0 h-[46%] w-full opacity-70" />
      <div className="relative z-10 flex items-center gap-2 text-[12px] font-medium text-[#4A7A96]">
        <span className="h-3 w-3 animate-spin rounded-full border-2 border-marine border-t-transparent" />
        Loading marine chart…
      </div>
    </div>
  ),
});

const AGENTS: AgentStatus[] = [
  { id: "weatherOcean", name: "Weather & Ocean", nameHi: "मौसम व सागर", state: "complete" },
  { id: "geospatialRisk", name: "Geospatial & Risk", nameHi: "भू-स्थानिक व जोखिम", state: "complete" },
  { id: "dataDiscovery", name: "Data Discovery", nameHi: "डेटा खोज", state: "complete" },
  { id: "synthesis", name: "Response Synthesis", nameHi: "उत्तर संश्लेषण", state: "complete" },
];

let idCounter = 0;
const nextId = () => `m${++idCounter}-${Date.now()}`;

export default function OrcaWorkspace() {
  const [lang, setLang] = useState<Lang>("en");
  const [locationId, setLocationId] = useState("mumbai");
  const location = useMemo(() => getLocation(locationId), [locationId]);
  const dict = useMemo(() => t(lang), [lang]);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [processing, setProcessing] = useState<ProcessingState | null>(null);
  const [draft, setDraft] = useState("");

  const [view, setView] = useState<MapViewId>("default");
  const [layers, setLayers] = useState<LayerToggles>(LAYER_DEFAULTS.default);
  const [mapCmd, setMapCmd] = useState<MapCommand | null>(null);

  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const [lastResponse, setLastResponse] = useState<OrcaResponse | null>(null);

  const [alerts, setAlerts] = useState<MarineAlertData[]>([]);
  const [toasts, setToasts] = useState<AppToast[]>([]);
  const [demoMode, setDemoMode] = useState(false); /* default LIVE (§10) */
  const [demoRunning, setDemoRunning] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [liveMapData, setLiveMapData] = useState<LiveMapData | null>(null);
  const [liveStrip, setLiveStrip] = useState<LiveStrip | null>(null);
  const [liveRisk, setLiveRisk] = useState<RiskLevel5 | null>(null);

  const inputRef = useRef<HTMLTextAreaElement>(null);
  const stepTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const toastTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const demoTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const demoLock = useRef(false);
  const autoAlertFired = useRef(false);
  const autoAlertTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoSpeakRef = useRef(autoSpeak);

  /* ---------------- voice briefing (TTS) ---------------- */

  useEffect(() => {
    autoSpeakRef.current = autoSpeak;
  }, [autoSpeak]);

  /* ---------------- helpers ---------------- */

  const clearTimers = (ref: React.MutableRefObject<ReturnType<typeof setTimeout>[]>) => {
    ref.current.forEach(clearTimeout);
    ref.current = [];
  };

  const pushToast = useCallback(
    (toast: Omit<AppToast, "id" | "ts">) => {
      const id = nextId();
      setToasts((prev) => [{ ...toast, id, ts: Date.now() }, ...prev].slice(0, 4));
      const ttl = toast.alert ? 20000 : 3800;
      const timer = setTimeout(() => {
        setToasts((prev) => prev.filter((x) => x.id !== id));
      }, ttl);
      toastTimers.current.push(timer);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((x) => x.id !== id));
  }, []);

  /* route voice-briefing failures into the normal toast stack */
  useEffect(() => {
    setVoiceErrorHandler((message) => {
      pushToast({ kind: "info", title: STR[lang].voiceErrors.ttsFailed, body: message });
    });
  }, [lang, pushToast]);

  const applyMapResponse = useCallback((resp: OrcaResponse) => {
    setView(resp.map.view);
    setLayers(LAYER_DEFAULTS[resp.map.view]);
    setMapCmd({ ts: Date.now(), center: resp.map.center, zoom: resp.map.zoom });
  }, []);

  const lastAlertTs = useRef(0);

  const raiseAlert = useCallback(() => {
    /* avoid duplicate stacked alerts within a short window */
    if (Date.now() - lastAlertTs.current < 10000) return;
    lastAlertTs.current = Date.now();
    const cy = location.cyclone;
    const dist = cy?.distanceKm ?? location.hazardZones[0]?.radiusKm ?? 20;
    const bearing = cy?.bearing ?? "near";
    const alert: MarineAlertData = {
      id: nextId(),
      title: lang === "hi" ? "नई समुद्री चेतावनी" : "New marine alert",
      titleHi: "नई समुद्री चेतावनी",
      body: cy
        ? lang === "hi"
          ? `आपके निगरानी क्षेत्र से ${dist} किमी ${bearing} पर चक्रवाती गतिविधि पाई गई।`
          : `Cyclone activity detected ${dist} km ${bearing} from your monitored area.`
        : lang === "hi"
          ? `निगरानी क्षेत्र के पास उग्र लहर पाई गई।`
          : `Rough swell detected near your monitored area.`,
      bodyHi: cy
        ? `आपके निगरानी क्षेत्र से ${dist} किमी ${bearing} पर चक्रवाती गतिविधि पाई गई।`
        : `निगरानी क्षेत्र के पास उग्र लहर पाई गई।`,
      center: cy ? cy.center : location.hazardZones[0]?.center ?? location.center,
      ts: Date.now(),
      read: false,
    };
    setAlerts((prev) => [alert, ...prev]);
    pushToast({
      kind: "alert",
      title: lang === "hi" ? "नई समुद्री चेतावनी" : "NEW MARINE ALERT",
      body: lang === "hi" ? alert.bodyHi : alert.body,
      alert,
    });
  }, [location, lang, pushToast]);

  /* ---------------- live pipeline (real data, §12/§19/§21) ---------------- */

  const raiseLiveAlert = useCallback(
    (
      warning: { title: string; summary?: string; demo?: boolean },
      sourceLabel: string,
      demo = false
    ) => {
      if (Date.now() - lastAlertTs.current < 10000) return;
      lastAlertTs.current = Date.now();
      const alert: MarineAlertData = {
        id: nextId(),
        title: demo
          ? lang === "hi"
            ? "डेमो समुद्री सलाह"
            : "Demo marine advisory"
          : lang === "hi"
            ? "आधिकारिक चेतावनी"
            : "Official marine warning",
        titleHi: demo ? "डेमो समुद्री सलाह" : "आधिकारिक चेतावनी",
        body: warning.summary
          ? `${warning.title} — ${warning.summary}`
          : warning.title,
        bodyHi: warning.summary
          ? `${warning.title} — ${warning.summary}`
          : warning.title,
        center: location.center,
        ts: Date.now(),
        read: false,
        live: !demo,
        demo,
        sourceLabel: demo ? `${sourceLabel} · DEMO (simulated)` : sourceLabel,
      };
      setAlerts((prev) => [alert, ...prev]);
      pushToast({
        kind: "alert",
        title: demo
          ? lang === "hi"
            ? "डेमो सलाह (अनुकरणित)"
            : "DEMO ADVISORY (SIMULATED)"
          : lang === "hi"
            ? "आधिकारिक चेतावनी"
            : "OFFICIAL MARINE WARNING",
        body: lang === "hi" ? alert.bodyHi : alert.body,
        alert,
      });
    },
    [location, lang, pushToast]
  );

  const opsToSteps = useCallback((result: { ops: { id: string; status: string }[] }): StepState[] => {
    const steps: StepState[] = ["pending", "pending", "pending", "pending", "pending", "pending"];
    const order = ["understand", "locate", "marine", "warnings", "hazards", "risk"];
    for (const op of result.ops) {
      const idx = order.indexOf(op.id);
      if (idx >= 0) steps[idx] = op.status as StepState;
    }
    return steps;
  }, []);

  const runLiveQuery = useCallback(
    (q: string) => {
      setProcessing({
        step: 0,
        query: q,
        mode: "live",
        steps: ["done", "done", "active", "pending", "pending", "pending"],
      });

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 60000);
      stepTimers.current.push(timeout as unknown as ReturnType<typeof setTimeout>);

      fetch("/api/orca/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: q,
          location: {
            lat: location.center.lat,
            lon: location.center.lng,
            name: location.name,
            id: location.id,
          },
          lang,
        }),
        signal: controller.signal,
      })
        .then(async (res) => {
          const data = await res.json().catch(() => null);
          if (!res.ok || !data?.ok) {
            throw new Error(data?.error?.message || "query_failed");
          }
          return data as {
            response: OrcaResponse;
            ops: { id: string; status: "done" | "warn" | "fail" }[];
            mapData: LiveMapData;
            risk: { level: RiskLevel5 };
          };
        })
        .then((result) => {
          const steps = opsToSteps(result);
          setLiveRisk(result.risk.level);
          /* show the REAL final step states briefly, then resolve */
          setProcessing((p) => (p ? { ...p, steps } : p));
          stepTimers.current.push(
            setTimeout(() => {
              setProcessing(null);
              const orcaMsg: ChatMessage = {
                id: nextId(),
                role: "orca",
                response: result.response,
                ts: Date.now(),
              };
              setMessages((prev) => [...prev, orcaMsg]);
              setLastResponse(result.response);
              setLiveMapData(result.mapData);
              applyMapResponse(result.response);
              setEvidenceOpen(true);
              pushToast({
                kind: "ok",
                title: STR[lang].toasts.analysisDone,
                body: STR[lang].toasts.mapUpdated,
              });
              /* official warnings → REAL alert; demo substitutes → labeled demo alert */
              if (result.mapData.warnings.length > 0) {
                const w0 = result.mapData.warnings[0];
                raiseLiveAlert(w0, "IMD", Boolean(w0.demo));
              }
              if (autoSpeakRef.current) {
                void speakMessage(orcaMsg.id, orcaSpeakText(orcaMsg, lang), lang);
              }
            }, 700)
          );
        })
        .catch(() => {
          setProcessing((p) =>
            p
              ? {
                  ...p,
                  steps: ["done", "done", "fail", "fail", "pending", "pending"],
                }
              : p
          );
          stepTimers.current.push(
            setTimeout(() => {
              setProcessing(null);
              const orcaMsg: ChatMessage = {
                id: nextId(),
                role: "orca",
                text: `${STR[lang].toasts.errorTitle} ${STR[lang].toasts.errorBody}`,
                textHi: `${STR.hi.toasts.errorTitle} ${STR.hi.toasts.errorBody}`,
                ts: Date.now(),
              };
              setMessages((prev) => [...prev, orcaMsg]);
              pushToast({
                kind: "info",
                title: STR[lang].toasts.errorTitle,
                body: STR[lang].toasts.errorBody,
              });
              if (autoSpeakRef.current) {
                void speakMessage(orcaMsg.id, orcaSpeakText(orcaMsg, lang), lang);
              }
            }, 900)
          );
        })
        .finally(() => clearTimeout(timeout));
    },
    [location, lang, applyMapResponse, pushToast, opsToSteps, raiseLiveAlert]
  );

  /* live empty-state conditions strip (real model values, may be unavailable).
     When demo mode is on, the strip is hidden by the mode check in ChatPanel,
     so no state reset is needed here. */
  useEffect(() => {
    if (demoMode) return;
    let cancelled = false;
    fetch(`/api/marine/context?id=${encodeURIComponent(location.id)}`)
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        const ctx = data?.context;
        if (!ctx) {
          setLiveStrip({
            waveM: null,
            windKmh: null,
            windDir: null,
            sstC: null,
            sourceLine: "",
            available: false,
          });
          return;
        }
        const windMps = ctx.weather?.windSpeedMps ?? ctx.ocean?.windSpeedMps ?? null;
        setLiveStrip({
          waveM: ctx.ocean?.waveHeightM ?? null,
          windKmh: windMps != null ? Math.round(windMps * 3.6) : null,
          windDir: ctx.weather?.windDirectionDeg != null ? String(ctx.weather.windDirectionDeg) : null,
          sstC: ctx.ocean?.sstC ?? null,
          sourceLine:
            ctx.sourceMeta
              ?.filter((m: { status: string }) => m.status !== "unavailable")
              .map((m: { source: string }) => m.source)
              .join(" · ") || "",
          available: Boolean(ctx.ocean || ctx.weather),
        });
      })
      .catch(() => {
        if (!cancelled) {
          setLiveStrip({
            waveM: null,
            windKmh: null,
            windDir: null,
            sstC: null,
            sourceLine: "",
            available: false,
          });
        }
      });
    return () => {
      cancelled = true;
    };
  }, [demoMode, location.id]);

  /* boot live map data — risk/PFZ/cyclone/arrow layers work from the very
     first paint (no chat query needed). Real model data + labeled demo
     substitutes, same honesty rules as the query flow. */
  useEffect(() => {
    if (demoMode) return;
    let cancelled = false;
    fetch(`/api/marine/map?id=${encodeURIComponent(location.id)}`)
      .then((r) => r.json())
      .then((data) => {
        if (cancelled || !data?.ok || !data?.mapData) return;
        setLiveMapData(data.mapData as LiveMapData);
        if (data.riskLevel) setLiveRisk(data.riskLevel as RiskLevel5);
      })
      .catch(() => {
        /* boot fetch is best-effort — layers stay empty until a query */
      });
    return () => {
      cancelled = true;
    };
  }, [demoMode, location.id]);

  /* ---------------- core ask flow ---------------- */

  const askQuery = useCallback(
    (query: string, source: "user" | "demo" = "user") => {
      const q = query.trim();
      if (!q || processing) return;
      if (source === "user") {
        clearTimers(demoTimers);
        if (demoLock.current) {
          demoLock.current = false;
          setDemoRunning(false);
        }
      }
      if (q.includes("__error")) {
        setMessages((prev) => [
          ...prev,
          { id: nextId(), role: "user", text: q.replace("__error", ""), ts: Date.now() },
          {
            id: nextId(),
            role: "orca",
            text: `${STR[lang].toasts.errorTitle} ${STR[lang].toasts.errorBody}`,
            textHi: `${STR.hi.toasts.errorTitle} ${STR.hi.toasts.errorBody}`,
            ts: Date.now(),
          },
        ]);
        pushToast({ kind: "info", title: STR[lang].toasts.errorTitle, body: STR[lang].toasts.errorBody });
        return;
      }

      clearTimers(stepTimers);
      setDraft("");
      stopSpeaking(); /* hush any playing briefing when a new question starts */
      setMessages((prev) => [...prev, { id: nextId(), role: "user", text: q, ts: Date.now() }]);

      if (!demoMode) {
        runLiveQuery(q);
        return;
      }

      /* ---------------- demo pipeline (simulated data) ---------------- */
      setProcessing({ step: 0, query: q, mode: "demo" });

      PROCESSING_TIMELINE.forEach((ms, i) => {
        stepTimers.current.push(
          setTimeout(() => setProcessing((p) => (p ? { ...p, step: i + 1 } : p)), ms)
        );
      });

      stepTimers.current.push(
        setTimeout(() => {
          try {
            const flow = resolveFlow(q);
            const resp = buildResponse(flow, location, lang);
            setProcessing(null);
            setLastResponse(resp);
            const orcaMsg: ChatMessage = {
              id: nextId(),
              role: "orca",
              response: resp,
              ts: Date.now(),
            };
            setMessages((prev) => [...prev, orcaMsg]);
            applyMapResponse(resp);
            setEvidenceOpen(true);
            pushToast({
              kind: "ok",
              title: STR[lang].toasts.analysisDone,
              body: STR[lang].toasts.mapUpdated,
            });
            if (autoSpeakRef.current) {
              void speakMessage(orcaMsg.id, orcaSpeakText(orcaMsg, lang), lang);
            }
          } catch {
            setProcessing(null);
            const orcaMsg: ChatMessage = {
              id: nextId(),
              role: "orca",
              text: `${STR[lang].toasts.errorTitle} ${STR[lang].toasts.errorBody}`,
              textHi: `${STR.hi.toasts.errorTitle} ${STR.hi.toasts.errorBody}`,
              ts: Date.now(),
            };
            setMessages((prev) => [...prev, orcaMsg]);
            pushToast({ kind: "info", title: STR[lang].toasts.errorTitle, body: STR[lang].toasts.errorBody });
            if (autoSpeakRef.current) {
              void speakMessage(orcaMsg.id, orcaSpeakText(orcaMsg, lang), lang);
            }
          }
        }, PROCESSING_TIMELINE[PROCESSING_TIMELINE.length - 1] + 600)
      );
    },
    [processing, location, lang, applyMapResponse, pushToast, demoMode, runLiveQuery]
  );

  /* ---------------- voice input (STT) ---------------- */

  const handleTranscript = useCallback(
    (text: string) => {
      const q = text.trim();
      if (!q) return;
      if (processing) {
        /* mid-analysis — stage the question so the user can send it next */
        setDraft(q);
        pushToast({
          kind: "info",
          title: STR[lang].voiceQueued,
          body: STR[lang].voiceQueuedBody,
        });
      } else {
        askQuery(q);
      }
    },
    [processing, askQuery, lang, pushToast]
  );

  const handleVoiceNotify = useCallback(
    (kind: "error" | "info", title: string, body?: string) => {
      pushToast({ kind: kind === "error" ? "alert" : "info", title, body });
    },
    [pushToast]
  );

  /* ---------------- guided demo (§31) — demo data only ---------------- */

  const runGuidedDemo = useCallback(() => {
    if (demoLock.current || processing) return;
    if (!demoMode) {
      /* guided demo plays the simulated scenario — switch to demo mode first */
      setDemoMode(true);
      pushToast({
        kind: "info",
        title: lang === "hi" ? "डेमो मोड चालू" : "Demo mode enabled",
        body: lang === "hi" ? "निर्देशित डेमो फिर से चलाएँ।" : "Tap “Run guided demo” again to start.",
      });
      return;
    }
    demoLock.current = true;
    setDemoRunning(true);
    clearTimers(demoTimers);
    clearTimers(stepTimers);
    /* the demo raises its own alert — cancel the pending auto-alert */
    if (autoAlertTimer.current) {
      clearTimeout(autoAlertTimer.current);
      autoAlertTimer.current = null;
    }
    autoAlertFired.current = true;

    askQuery(DEMO_SEQUENCE[0][lang], "demo");

    demoTimers.current.push(
      setTimeout(() => askQuery(DEMO_SEQUENCE[1][lang], "demo"), 5400),
      setTimeout(() => raiseAlert(), 11000),
      setTimeout(() => {
        demoLock.current = false;
        setDemoRunning(false);
        pushToast({
          kind: "info",
          title: lang === "hi" ? "डेमो अनुक्रम पूर्ण" : "Demo sequence complete",
          body: lang === "hi" ? "सुरक्षा → सुरक्षित मार्ग → चेतावनी" : "Safety → safer route → live alert",
        });
      }, 12400)
    );
  }, [askQuery, processing, raiseAlert, lang, pushToast, demoMode]);

  /* ---------------- alert actions ---------------- */

  const viewAlertOnMap = useCallback(
    (alertId: string) => {
      const alert = alerts.find((a) => a.id === alertId);
      if (!alert) return;
      setAlerts((prev) => prev.map((a) => (a.id === alertId ? { ...a, read: true } : a)));
      setView("hazard");
      setLayers(LAYER_DEFAULTS.hazard);
      setMapCmd({ ts: Date.now(), center: alert.center, zoom: 9.6 });
      setEvidenceOpen(true);
      dismissToast(alertId);
      setMessages((prev) => [
        ...prev,
        {
          id: nextId(),
          role: "system",
          text: STR.en.systemAlertMsg,
          textHi: STR.hi.systemAlertMsg,
          ts: Date.now(),
        },
      ]);
      pushToast({ kind: "ok", title: STR[lang].toasts.mapUpdated });
    },
    [alerts, dismissToast, pushToast, lang]
  );

  /* ---------------- lifecycle ---------------- */

  /* Auto proactive alert ~22s after entering demo mode (§28) — once per session */
  useEffect(() => {
    if (!demoMode || autoAlertFired.current) return;
    autoAlertTimer.current = setTimeout(() => {
      autoAlertFired.current = true;
      raiseAlert();
    }, 22000);
    return () => {
      if (autoAlertTimer.current) clearTimeout(autoAlertTimer.current);
    };
  }, [demoMode, raiseAlert]);

  /* "/" focuses composer */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (document.activeElement as HTMLElement | null)?.tagName;
      if (e.key === "/" && tag !== "TEXTAREA" && tag !== "INPUT") {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    return () => {
      clearTimers(stepTimers);
      clearTimers(toastTimers);
      clearTimers(demoTimers);
    };
  }, []);

  /* ---------------- header actions ---------------- */

  const handleLocation = (id: string) => {
    if (id === locationId) return;
    stopSpeaking();
    const loc = getLocation(id);
    setLocationId(id);
    setView("default");
    setLayers(LAYER_DEFAULTS.default);
    setMapCmd({ ts: Date.now(), center: loc.center, zoom: loc.defaultZoom });
    setLastResponse(null);
    setEvidenceOpen(false);
    setMessages((prev) => [
      ...prev,
      {
        id: nextId(),
        role: "orca",
        divider: STR[lang].switchDivider(lang === "hi" ? loc.nameHi : loc.name),
        ts: Date.now(),
      },
    ]);
    pushToast({ kind: "info", title: STR[lang].toasts.mapUpdated, body: loc.name });
  };

  const handleLang = (l: Lang) => {
    if (l === lang) return;
    stopSpeaking();
    setLang(l);
    setMessages((prev) => [
      ...prev,
      {
        id: nextId(),
        role: "orca",
        divider: STR[l].langDivider(l === "hi" ? "हिन्दी" : "English"),
        ts: Date.now(),
      },
    ]);
  };

  const risk = deriveRisk(location);
  const mode = demoMode ? "demo" : "live";

  /* reset live overlays when the mode switches — render-time state
     adjustment (React "you might not need an effect" pattern) */
  const [prevDemoMode, setPrevDemoMode] = useState(demoMode);
  if (prevDemoMode !== demoMode) {
    setPrevDemoMode(demoMode);
    setLiveMapData(null);
    setLiveRisk(null);
    setLastResponse(null);
    setView("default");
    setLayers(LAYER_DEFAULTS.default);
    setEvidenceOpen(false);
  }

  return (
    <div className="flex min-h-dvh flex-col bg-background lg:h-dvh lg:min-h-0 lg:overflow-hidden">
      <CinematicIntro />
      <AppHeader
        location={location}
        locations={MARINE_LOCATIONS}
        onLocation={handleLocation}
        lang={lang}
        onLang={handleLang}
        alerts={alerts}
        onSimulateAlert={raiseAlert}
        onViewAlert={viewAlertOnMap}
        demoMode={demoMode}
        onDemoMode={setDemoMode}
        dict={dict}
      />

      <main className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* Conversation — 35% */}
        <div className="flex h-[calc(100dvh-3.5rem)] min-h-0 flex-col lg:h-auto lg:w-[36%] lg:max-w-[480px] lg:min-w-[380px]">
          <ChatPanel
            messages={messages}
            processing={processing}
            dict={dict}
            lang={lang}
            agents={AGENTS}
            location={location}
            draft={draft}
            onDraftChange={setDraft}
            onSend={() => askQuery(draft)}
            onChip={(q) => askQuery(q)}
            onDemo={runGuidedDemo}
            onTranscript={handleTranscript}
            onNotify={handleVoiceNotify}
            autoSpeak={autoSpeak}
            onAutoSpeakToggle={() => {
              stopSpeaking();
              setAutoSpeak((v) => !v);
            }}
            demoRunning={demoRunning}
            inputRef={inputRef}
            mode={mode}
            liveStrip={liveStrip}
          />
        </div>

        {/* Map + evidence — 65% */}
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="relative h-[68vh] min-h-0 flex-none lg:h-auto lg:flex-1">
            <MarineMap
              location={location}
              view={view}
              cmd={mapCmd}
              layers={layers}
              onToggleLayer={(k) => setLayers((prev) => ({ ...prev, [k]: !prev[k] }))}
              lang={lang}
              dict={dict}
              hasQuery={messages.length > 0}
              mode={mode}
              live={demoMode ? null : liveMapData}
              onAskSpot={(lat, lng) => {
                const la = `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? "N" : "S"}`;
                const lo = `${Math.abs(lng).toFixed(2)}°${lng >= 0 ? "E" : "W"}`;
                askQuery(
                  lang === "hi"
                    ? `क्या ${la} ${lo} पर जाना सुरक्षित है?`
                    : `Is it safe to go near ${la}, ${lo}?`
                );
              }}
            />
            {/* Risk ribbon — demo risk or live risk (UNKNOWN shown honestly) */}
            {view === "default" && (
              <div className="absolute bottom-3 left-3 z-[550] hidden lg:block">
                <div className="flex items-center gap-2 rounded-md border border-line bg-white/92 px-2.5 py-1.5 text-[10.5px] text-ink-2 shadow-[0_1px_2px_rgba(23,35,45,0.08)] backdrop-blur-sm">
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      mode === "live"
                        ? liveRisk == null
                          ? "bg-[#8296a3]"
                          : liveRisk === "CRITICAL"
                            ? "bg-[#b42318]"
                            : liveRisk === "HIGH"
                              ? "bg-[#b42318]"
                              : liveRisk === "MODERATE"
                                ? "bg-[#b45309]"
                                : liveRisk === "LOW"
                                  ? "bg-good"
                                  : "bg-[#8296a3]"
                        : risk === "high"
                          ? "bg-[#b42318]"
                          : risk === "moderate"
                            ? "bg-[#b45309]"
                            : "bg-good"
                    }`}
                    aria-hidden
                  />
                  {lang === "hi" ? "वर्तमान जोखिम: " : "Current risk: "}
                  <span className="font-medium text-ink">
                    {mode === "live"
                      ? liveRisk == null || liveRisk === "UNKNOWN"
                        ? dict.riskUnknownShort
                        : liveRisk === "HIGH" || liveRisk === "CRITICAL"
                          ? lang === "hi"
                            ? "उच्च"
                            : "High"
                          : liveRisk === "MODERATE"
                            ? lang === "hi"
                              ? "मध्यम"
                              : "Moderate"
                            : lang === "hi"
                              ? "कम"
                              : "Low"
                      : risk === "high"
                        ? lang === "hi"
                          ? "उच्च"
                          : "High"
                        : risk === "moderate"
                          ? lang === "hi"
                            ? "मध्यम"
                            : "Moderate"
                          : lang === "hi"
                            ? "कम"
                            : "Low"}
                  </span>
                </div>
              </div>
            )}
          </div>

          <EvidencePanel
            evidence={lastResponse?.evidence ?? null}
            open={evidenceOpen}
            onToggle={() => setEvidenceOpen((v) => !v)}
            dict={dict}
            hi={lang === "hi"}
            headline={
              lastResponse ? (lang === "hi" ? lastResponse.headlineHi : lastResponse.headline) : undefined
            }
          />
        </div>
      </main>

      <ToastStack
        toasts={toasts}
        dict={dict}
        onViewMap={viewAlertOnMap}
        onDismiss={dismissToast}
      />
    </div>
  );
}
