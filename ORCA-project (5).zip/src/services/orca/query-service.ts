/**
 * ORCA query service (STEP 11/12 brain) — server-side only.
 *
 * Flow: intent → getMarineContext() → evaluateMarineRisk() → PFZ lookup /
 * route engine → UI-compatible OrcaResponse + dynamic map data + source
 * provenance. The response shape matches the existing chat UI so no chat
 * component needs a rewrite (§18, §36).
 *
 * Honesty rules (§34) are enforced here: model data is labeled "(model)",
 * official warnings are attributed to IMD, missing sources produce explicit
 * unavailable states, and no claim is stronger than the data behind it.
 */

import type {
  CycloneData,
  MarineContext,
  MarineWarning,
  PFZAdvisory,
  RiskAssessment,
  RiskCell,
  RiskLevel,
  SourceMeta,
  VesselSafetyProfile,
} from "../marine/types";
import { getMarineContext } from "../marine";
import { evaluateMarineRisk } from "../risk/risk-engine";
import { getProfile } from "../risk/profiles";
import { nearestPFZ, distanceKm, compass16, bearingBetween, beyondBoundary } from "../risk/geospatial";
import { computeSaferRoute, sampleAnchors, interpolateAnchors } from "../risk/route-engine";
import { resolveFlow } from "@/lib/mock-orca";
import type { FlowId, OrcaResponse, Tone } from "@/types/orca";
import type { CycloneInfo, PFZZone, RoutePath, SeaArrow, WindArrow } from "@/types/marine";
import type { Lang } from "@/lib/i18n";
import { formatIst, humanizeAge } from "../marine/freshness";
import { round } from "../marine/normalizer";

/* ------------------------------------------------------------------ */
/* Public result shapes                                                */
/* ------------------------------------------------------------------ */

export interface LiveConditions {
  waveHeightM: number | null;
  waveHeightTomorrowM: number | null;
  windMps: number | null;
  gustMps: number | null;
  windDir: string | null;
  sstC: number | null;
  visibilityKm: number | null;
  wavePeriodS: number | null;
}

export interface LiveMapData {
  cyclone: CycloneInfo | null;
  cycloneAvailable: boolean;
  pfz: PFZZone[] | null; /* null = advisory unavailable (explicit UI state) */
  pfzNote?: string;
  riskCells: RiskCell[];
  route: RoutePath | null;
  routeStatus: "FOUND" | "NO_SAFE_PATH" | null;
  routeExplanation: string[];
  routeExplanationHi: string[];
  seaArrows: SeaArrow[];
  windArrows: WindArrow[];
  conditions: LiveConditions;
  warnings: MarineWarning[];
  boundary: { points: [number, number][]; label: string } | null;
}

export interface OpStatus {
  id: string;
  status: "done" | "warn" | "fail";
  detail?: string;
}

export interface OrcaQueryResult {
  ok: true;
  requestId: string;
  flow: FlowId;
  response: OrcaResponse;
  ops: OpStatus[];
  mapData: LiveMapData;
  sources: SourceMeta[];
  risk: RiskAssessment;
  dataQuality: RiskAssessment["dataQuality"];
}

export interface OrcaQueryRequest {
  query: string;
  location: { lat: number; lon: number; name?: string; id?: string };
  targetTime?: string;
  vesselProfile?: string;
  lang?: Lang;
  boundary?: { points: [number, number][]; label: string } | null;
}

/* ------------------------------------------------------------------ */
/* Time helpers (§27 — UTC internal, IST display)                      */
/* ------------------------------------------------------------------ */

export function tomorrowMorningIst(): string {
  const now = new Date();
  const ist = new Date(now.getTime() + 5.5 * 3600_000);
  ist.setUTCDate(ist.getUTCDate() + 1);
  ist.setUTCHours(3, 30, 0, 0); /* 09:00 IST = 03:30 UTC */
  return ist.toISOString();
}

/**
 * Derive the target time from the query (§9): explicit "tomorrow/kal/कल"
 * → next morning 09:00 IST; "today/now/ab/aaj" or default → now.
 */
export function deriveTargetTime(query: string): string {
  const q = query.toLowerCase();
  const wantsTomorrow = /\btomorrow\b|\bkal\b|कल/.test(q);
  if (wantsTomorrow) return tomorrowMorningIst();
  return new Date().toISOString();
}

/* ------------------------------------------------------------------ */
/* Headlines / summaries                                               */
/* ------------------------------------------------------------------ */

const HEADLINES: Record<RiskLevel, { en: string; hi: string; tone: Tone }> = {
  CRITICAL: { en: "CRITICAL MARINE RISK — OFFICIAL WARNING", hi: "गंभीर समुद्री जोखिम — आधिकारिक चेतावनी", tone: "danger" },
  HIGH: { en: "HIGH MARINE RISK", hi: "उच्च समुद्री जोखिम", tone: "danger" },
  MODERATE: { en: "MODERATE RISK — CAUTION", hi: "मध्यम जोखिम — सावधानी", tone: "warning" },
  LOW: { en: "LOW RISK — FAVOURABLE", hi: "कम जोखिम — अनुकूल", tone: "good" },
  UNKNOWN: { en: "INSUFFICIENT DATA", hi: "अपर्याप्त डेटा", tone: "info" },
};

function riskSummary(
  level: RiskLevel,
  reasons: RiskAssessment["reasons"],
  locName: string,
  locNameHi: string,
  hi: boolean
): string {
  const reasonText = reasons
    .slice(0, 2)
    .map((r) => (hi ? r.hi : r.en))
    .join(" ");
  if (level === "UNKNOWN") {
    return hi
      ? `डेटा अपर्याप्त है — विश्वसनीय सुरक्षा आकलन संभव नहीं। ${reasonText}`
      : `There isn't enough marine data for a reliable safety assessment near ${locName}. ${reasonText}`;
  }
  if (level === "CRITICAL") {
    return hi
      ? `${locNameHi} के पास आधिकारिक चेतावनी सक्रिय है। समुद्र में न जाएँ। ${reasonText}`
      : `Official warnings are active near ${locName}. Do not venture into open sea. ${reasonText}`;
  }
  if (level === "HIGH") {
    return hi
      ? `${locNameHi} के पास स्थितियाँ उच्च जोखिम दिखाती हैं। खुले समुद्र में जाने से बचें। ${reasonText}`
      : `Conditions near ${locName} indicate elevated marine risk. Avoid venturing into open sea. ${reasonText}`;
  }
  if (level === "MODERATE") {
    return hi
      ? `${locNameHi} के पास स्थितियाँ चल सकती हैं पर सावधानी ज़रूरी है। छोटे जहाज़ तट की दृष्टि में रहें। ${reasonText}`
      : `Conditions near ${locName} are workable but caution is required. Small vessels should stay within sight of the coast. ${reasonText}`;
  }
  return hi
    ? `${locNameHi} के पास स्थितियाँ अनुकूल हैं। सामान्य सावधानी बरतें — निर्णय उपलब्ध डेटा पर आधारित है।`
    : `Conditions near ${locName} look favourable based on available data. Standard precautions still apply.`;
}

function sourceLine(context: MarineContext): string {
  const parts: string[] = [];
  for (const m of context.sourceMeta) {
    if (m.status === "unavailable") {
      parts.push(`${m.source} · unavailable`);
      continue;
    }
    if (m.demo) {
      parts.push(`${m.source} · DEMO (simulated)`);
      continue;
    }
    const age = humanizeAge(m.freshnessSeconds);
    if (m.source === "OPEN_METEO") parts.push(`Open-Meteo · model${m.observedAt ? ` updated ${formatIst(m.observedAt) ?? ""}` : ""}`);
    else if (m.source === "IMD") parts.push(`IMD · ${m.status}${age ? `, ${age}` : ""}`);
    else if (m.source === "INCOIS") parts.push(`INCOIS · issued ${formatIst(m.observedAt) ?? m.status}`);
    else if (m.source === "INCOIS_PFZ") parts.push(`INCOIS PFZ · valid until ${formatIst(m.validUntil) ?? m.status}`);
  }
  return parts.join("  •  ");
}

/* ------------------------------------------------------------------ */
/* Map data assembly                                                   */
/* ------------------------------------------------------------------ */

function toPfzZones(point: { lat: number; lon: number }, advisories: PFZAdvisory[]): PFZZone[] {
  return advisories.map((a) => {
    const ring: [number, number][] = a.geometry?.coordinates?.[0]
      ? a.geometry.coordinates[0].map(([lng, lat]) => [lat, lng] as [number, number])
      : circleRing(a.latitude, a.longitude, 6);
    const d = distanceKm(point, { lat: a.latitude, lon: a.longitude });
    const b = bearingBetween(point, { lat: a.latitude, lon: a.longitude });
    const src = a.demo ? "DEMO (simulated)" : "INCOIS";
    const srcHi = a.demo ? "डेमो (अनुकरणित)" : "INCOIS";
    return {
      id: a.id,
      label: `PFZ — ${src} (valid ${formatIst(a.validUntil) ?? "—"} IST)`,
      labelHi: `PFZ — ${srcHi} (${formatIst(a.validUntil) ?? "—"} IST तक वैध)`,
      polygon: ring,
      center: { lat: a.latitude, lng: a.longitude },
      distanceKm: Math.round(d * 10) / 10,
      bearing: compass16(b),
      sstFront: a.demo ? "Simulated demo PFZ zone" : "Official INCOIS PFZ advisory",
      chlorophyll: a.sector ? `Sector: ${a.sector}` : a.demo ? "Demo zone" : "Official advisory",
      likelySpecies: [],
    };
  });
}

function circleRing(lat: number, lng: number, radiusKm: number): [number, number][] {
  const ring: [number, number][] = [];
  const dLat = radiusKm / 110.574;
  const dLon = radiusKm / (111.32 * Math.cos((lat * Math.PI) / 180));
  for (let k = 0; k < 24; k++) {
    const th = (k / 24) * 2 * Math.PI;
    ring.push([lat + dLat * Math.sin(th), lng + dLon * Math.cos(th)]);
  }
  ring.push(ring[0]);
  return ring;
}

function toCycloneInfo(cy: CycloneData, point: { lat: number; lon: number }): CycloneInfo {
  const d = distanceKm(point, cy.position);
  return {
    name: cy.name,
    category: cy.category ?? "Cyclonic system",
    center: { lat: cy.position.lat, lng: cy.position.lon },
    distanceKm: Math.round(d),
    bearing: compass16(bearingBetween(point, cy.position)),
    influenceRadiusKm: cy.influenceRadiusKm ?? 55,
    movement: cy.movement?.text ?? "Movement as per IMD advisory",
    movementHi: cy.movement?.text ?? "गति IMD सलाह के अनुसार",
    demo: cy.demo ?? false,
  };
}

async function buildRiskCells(
  context: MarineContext,
  profile: VesselSafetyProfile,
  risk: RiskAssessment
): Promise<RiskCell[]> {
  const cLat = context.location.lat;
  const cLon = context.location.lon;
  const spread = 0.4;
  const bounds = {
    latMin: cLat - spread,
    latMax: cLat + spread,
    lonMin: cLon - spread,
    lonMax: cLon + spread,
  };
  const anchors = await sampleAnchors(bounds);
  const cells: RiskCell[] = [];
  const n = 4;
  const cyList = context.warnings?.cyclone ?? [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const lat = bounds.latMin + (i + 0.5) * ((bounds.latMax - bounds.latMin) / n);
      const lng = bounds.lonMin + (j + 0.5) * ((bounds.lonMax - bounds.lonMin) / n);
      const v = interpolateAnchors(anchors, lat, lng);

      /* cells on the LAND side of the prototype boundary get no marine
         assessment (grey) — marine risk only applies at sea */
      const onLand = context.boundary
        ? !beyondBoundary({ lat, lon: lng }, context.boundary.points, {
            lat: cLat,
            lon: cLon,
          }).beyond
        : false;

      let level: RiskCell["level"] = "UNKNOWN";
      const wave = v.wave ?? context.ocean?.waveHeightM ?? null;
      const wind = v.wind ?? context.weather?.windSpeedMps ?? null;

      let insideCy = false;
      let cyNear = false;
      for (const cy of cyList) {
        const d = distanceKm({ lat, lon: lng }, cy.position);
        if (cy.warningGeometry?.coordinates?.length) {
          insideCy =
            insideCy ||
            cy.warningGeometry.coordinates.some((ring) => {
              const r = ring.map(([ln, la]) => [la, ln] as [number, number]);
              return pointInPolygonLite(lat, lng, r);
            });
        }
        if (d <= 120) cyNear = true;
      }

      if (!onLand) {
        if (insideCy) level = "CRITICAL";
        else if (wave != null && wave >= profile.maxWaveHeightM) level = "HIGH";
        else if (wind != null && wind >= profile.maxWindSpeedMps) level = "HIGH";
        else if (cyNear) level = "HIGH";
        else if (
          (wave != null && wave >= 0.7 * profile.maxWaveHeightM) ||
          (wind != null && wind >= 0.7 * profile.maxWindSpeedMps)
        )
          level = "MODERATE";
        else if (wave != null || wind != null) level = "LOW";
      }

      cells.push({
        lat: Math.round(lat * 1000) / 1000,
        lng: Math.round(lng * 1000) / 1000,
        radiusKm: Math.round(((bounds.latMax - bounds.latMin) / n) * 111 * 0.75),
        level,
      });
    }
  }
  return cells;
}

function pointInPolygonLite(lat: number, lng: number, ring: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i];
    const [xj, yj] = ring[j];
    if (yi > lng !== yj > lng && lat < ((xj - xi) * (lng - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

function buildArrows(context: MarineContext): { seaArrows: SeaArrow[]; windArrows: WindArrow[] } {
  const c = { lat: context.location.lat, lon: context.location.lon };
  const seaArrows: SeaArrow[] = [];
  const wave = context.ocean?.waveHeightM;
  const waveDir = context.ocean?.waveDirectionDeg;
  if (wave != null && waveDir != null) {
    seaArrows.push({
      position: { lat: round(c.lat + 0.16, 3)!, lng: round(c.lon - 0.1, 3)! },
      dirDeg: waveDir,
      label: `Hs ${wave} m (model)`,
    });
  }
  const windArrows: WindArrow[] = [];
  const windDir = context.weather?.windDirectionDeg ?? context.ocean?.currentDirectionDeg;
  if (windDir != null) {
    windArrows.push({ position: { lat: round(c.lat + 0.24, 3)!, lng: round(c.lon + 0.14, 3)! }, dirDeg: windDir });
  }
  return { seaArrows, windArrows };
}

function liveConditions(
  context: MarineContext,
  tomorrowWave: number | null
): LiveConditions {
  const dirDeg = context.weather?.windDirectionDeg;
  return {
    waveHeightM: context.ocean?.waveHeightM ?? null,
    waveHeightTomorrowM: tomorrowWave,
    windMps: context.weather?.windSpeedMps ?? context.ocean?.windSpeedMps ?? null,
    gustMps: context.weather?.gustSpeedMps ?? null,
    windDir: degToCompassLite(dirDeg),
    sstC: context.ocean?.sstC ?? null,
    visibilityKm: context.weather?.visibilityKm ?? null,
    wavePeriodS: context.ocean?.wavePeriodS ?? null,
  };
}

function degToCompassLite(deg: number | null | undefined): string | null {
  if (deg == null || !Number.isFinite(deg)) return null;
  const dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  return dirs[Math.round((((deg % 360) + 360) % 360) / 22.5) % 16];
}

/* ------------------------------------------------------------------ */
/* Live map bundle — shared by the chat query flow AND the lightweight  */
/* /api/marine/map endpoint that powers boot layers + per-tap spot      */
/* analysis (map interactions work before the first chat query).        */
/* ------------------------------------------------------------------ */

export interface LiveMapBundle {
  context: MarineContext;
  risk: RiskAssessment;
  mapData: LiveMapData;
  cycloneInfo: CycloneInfo | null;
  pfzZones: PFZZone[] | null;
  pfzNote: string | undefined;
  imdOk: boolean;
  tomorrowWave: number | null;
  riskCells: RiskCell[];
  /** ops-step statuses derived from real source metadata */
  marineOk: boolean;
  warningsOk: "done" | "warn";
}

export async function buildLiveMapBundle(
  location: { lat: number; lon: number; name?: string },
  opts: {
    targetTime?: string;
    boundary?: { points: [number, number][]; label: string } | null;
    vesselProfile?: string;
  } = {}
): Promise<LiveMapBundle> {
  const profile = getProfile(opts.vesselProfile);
  const boundary = opts.boundary ?? null;

  const context = await getMarineContext(
    { lat: location.lat, lon: location.lon, name: location.name },
    opts.targetTime ?? tomorrowMorningIst(),
    boundary ?? undefined
  );

  const risk = evaluateMarineRisk({
    context,
    vesselProfile: profile,
  });

  const oceanMeta = context.sourceMeta.find((m) => m.kind === "ocean_forecast");
  const weatherMeta = context.sourceMeta.find((m) => m.kind === "weather_forecast");
  const imdMetas = context.sourceMeta.filter((m) => m.source === "IMD");
  const imdOk = imdMetas.some((m) => m.status !== "unavailable");

  /* tomorrow's wave for conditions display */
  const tomorrowWave: number | null =
    context.ocean?.waveHeightM != null && context.forecastFor ? context.ocean.waveHeightM : null;

  const point = { lat: location.lat, lon: location.lon };

  const cyclones = context.warnings?.cyclone ?? [];
  const cycloneInfo = cyclones.length ? toCycloneInfo(cyclones[0], point) : null;

  let pfzZones: PFZZone[] | null = null;
  let pfzNote: string | undefined;
  if (context.pfz) {
    pfzZones = toPfzZones(point, context.pfz);
  } else {
    const pfzMeta = context.sourceMeta.find((m) => m.source === "INCOIS_PFZ");
    pfzNote =
      pfzMeta?.note ??
      "PFZ advisory unavailable — official INCOIS PFZ access is not configured.";
  }

  const riskCells = await buildRiskCells(context, profile, risk);
  const arrows = buildArrows(context);

  const mapData: LiveMapData = {
    cyclone: cycloneInfo,
    cycloneAvailable: imdOk,
    pfz: pfzZones,
    pfzNote,
    riskCells,
    route: null,
    routeStatus: null,
    routeExplanation: [],
    routeExplanationHi: [],
    seaArrows: arrows.seaArrows,
    windArrows: arrows.windArrows,
    conditions: liveConditions(context, tomorrowWave),
    warnings: [
      ...(context.warnings?.fishermen ?? []),
      ...(context.warnings?.coastal ?? []),
      ...(context.warnings?.seaArea ?? []),
    ],
    boundary,
  };

  return {
    context,
    risk,
    mapData,
    cycloneInfo,
    pfzZones,
    pfzNote,
    imdOk,
    tomorrowWave,
    riskCells,
    marineOk: oceanMeta?.status !== "unavailable" || weatherMeta?.status !== "unavailable",
    warningsOk: imdMetas.some((m) => m.status !== "unavailable" && !m.demo) ? "done" : "warn",
  };
}

/* ------------------------------------------------------------------ */
/* Main entry                                                          */
/* ------------------------------------------------------------------ */

export async function runOrcaQuery(req: OrcaQueryRequest): Promise<OrcaQueryResult> {
  const requestId = crypto.randomUUID();
  const started = Date.now();
  const lang: Lang = req.lang ?? "en";
  const hi = lang === "hi";
  const profile = getProfile(req.vesselProfile);
  const flow = resolveFlow(req.query);
  const locName = req.location.name ?? "your area";
  const locNameHi = req.location.name ?? "आपका क्षेत्र";

  const targetTime = req.targetTime ?? deriveTargetTime(req.query);
  const boundary = req.boundary ?? null;

  const bundle = await buildLiveMapBundle(req.location, {
    targetTime,
    boundary,
    vesselProfile: req.vesselProfile,
  });
  const {
    context,
    risk,
    mapData: baseMapData,
    cycloneInfo,
    pfzZones,
    pfzNote,
    riskCells,
    tomorrowWave,
  } = bundle;

  const cyclones = context.warnings?.cyclone ?? [];
  const point = { lat: req.location.lat, lon: req.location.lon };

  /* ---- ops trace (real operations, §19) ---- */
  const ops: OpStatus[] = [
    { id: "understand", status: "done" },
    { id: "locate", status: "done" },
    { id: "marine", status: bundle.marineOk ? "done" : "fail" },
    /* demo-substituted warnings still count as degraded ("limited"), honest */
    { id: "warnings", status: bundle.warningsOk },
    { id: "hazards", status: "done" },
    { id: "risk", status: risk.dataQuality === "INSUFFICIENT" ? "warn" : "done" },
  ];

  /* ---- flow responses ---- */
  let response: OrcaResponse;
  let route: RoutePath | null = null;
  let routeStatus: LiveMapData["routeStatus"] = null;

  if (flow === "pfz") {
    response = buildPfzResponse(context, risk, pfzZones, pfzNote, { locName, locNameHi, hi, profile });
  } else if (flow === "route") {
    /* goal: lowest-cost reachable cell ≥ 12 km from start (algorithmic target) */
    const goal = pickLowestCostGoal(riskCells, point);
    const routeResult = await computeSaferRoute({
      start: point,
      goal,
      profile,
      boundary,
      cyclones,
    });
    routeStatus = routeResult.status;
    if (routeResult.status === "FOUND") {
      route = {
        points: routeResult.points,
        distanceKm: routeResult.distanceKm,
        etaHours: routeResult.estimatedTravelTimeHours ?? 0,
        clearanceKm: routeResult.minimumHazardClearanceKm ?? 0,
        destination: "Lowest-risk area found by route engine",
        destinationHi: "रूट इंजन द्वारा खोजा गया न्यूनतम-जोखिम क्षेत्र",
      };
    }
    response = buildRouteResponse(routeResult, risk, context, { locName, locNameHi, hi, profile });
  } else if (flow === "hazard") {
    response = buildHazardResponse(context, risk, cycloneInfo, { locName, locNameHi, hi, profile });
  } else if (flow === "explain") {
    response = buildExplainResponse(context, risk, { locName, locNameHi, hi, profile });
  } else if (flow === "conditions") {
    response = buildConditionsResponse(context, risk, { locName, locNameHi, hi, profile, tomorrowWave });
  } else {
    response = buildSafetyResponse(context, risk, { locName, locNameHi, hi, profile });
  }

  response.sources = context.sourceMeta;
  response.dataQuality = risk.dataQuality;

  const mapCenter = flowResponseCenter(flow, point, cycloneInfo, pfzZones);

  response.map = {
    view: flow === "explain" ? "conditions" : (flow as Exclude<FlowId, "explain">),
    center: mapCenter,
    zoom: flow === "pfz" ? 10.5 : flow === "route" ? 10.2 : 9.4,
  };

  const sources = context.sourceMeta;

  return {
    ok: true,
    requestId,
    flow,
    response,
    ops,
    mapData: {
      ...baseMapData,
      route,
      routeStatus,
    },
    sources,
    risk,
    dataQuality: risk.dataQuality,
  };
}

/* ------------------------------------------------------------------ */
/* Response builders per flow                                          */
/* ------------------------------------------------------------------ */

interface Ctx {
  locName: string;
  locNameHi: string;
  hi: boolean;
  profile: VesselSafetyProfile;
}

function evList(risk: RiskAssessment, context: MarineContext): OrcaResponse["evidence"] {
  const out: OrcaResponse["evidence"] = risk.evidence.map((e) => ({
    category: e.label.startsWith("Cyclone") || e.label.startsWith("IMD") || e.label.startsWith("Offshore") ? "Geospatial & Risk" : "Weather & Ocean",
    label: e.label,
    labelHi: e.labelHi,
    value: e.value,
    tone: e.tone,
  }));
  const sst = context.ocean?.sstC;
  if (sst != null) {
    out.push({ category: "Marine Data", label: "Sea surface temp.", labelHi: "समुद्री सतह तापमान", value: `${sst} °C (model)`, tone: "neutral" });
  }
  out.push({
    category: "Marine Data",
    label: "Data quality",
    labelHi: "डेटा गुणवत्ता",
    value: risk.dataQuality,
    tone: risk.dataQuality === "GOOD" ? "good" : risk.dataQuality === "LIMITED" ? "neutral" : "warning",
  });
  return out;
}

function buildSafetyResponse(
  context: MarineContext,
  risk: RiskAssessment,
  c: Ctx
): OrcaResponse {
  const h = HEADLINES[risk.level];
  const advisories = risk.reasons.map((r) => (c.hi ? r.hi : r.en));
  if (risk.dataQuality === "LIMITED" || risk.dataQuality === "STALE") {
    advisories.push(
      c.hi
        ? "कुछ स्रोत अनुपलब्ध या पुराने हैं — सिफ़ारिश का विश्वास सीमित है।"
        : "Some sources are unavailable or stale — confidence in this assessment is limited."
    );
  }
  advisories.push(
    c.hi
      ? "यह प्रोटोटाइप सुरक्षा नीति पर आधारित है — जाने से पहले स्थानीय सूचना जाँचें।"
      : "Based on prototype safety policy — check local notices before departure."
  );
  return {
    flow: "safety",
    headline: h.en,
    headlineHi: h.hi,
    tone: h.tone,
    riskLevel: uiRisk(risk.level),
    summary: riskSummary(risk.level, risk.reasons, c.locName, c.locNameHi, c.hi),
    summaryHi: riskSummary(risk.level, risk.reasons, c.locName, c.locNameHi, true),
    evidence: evList(risk, context),
    advisories,
    advisoriesHi: advisories,
    analysis: {
      intent: c.hi ? "सुरक्षा जाँच" : "Safety check",
      intentHi: "सुरक्षा जाँच",
      sources: "IMD + INCOIS + Open-Meteo + geospatial",
      sourcesHi: "IMD + INCOIS + Open-Meteo + भू-स्थानिक",
      keyEvidence: risk.evidence.slice(0, 3).map((e) => e.value),
      keyEvidenceHi: risk.evidence.slice(0, 3).map((e) => e.value),
      conclusion: h.en.toLowerCase(),
      conclusionHi: h.hi,
    },
    map: { view: "safety", center: { lat: context.location.lat, lng: context.location.lon }, zoom: 9.4 },
    followUps: [
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
      { en: "Why this region?", hi: "यह क्षेत्र क्यों?" },
    ],
  };
}

function buildPfzResponse(
  context: MarineContext,
  risk: RiskAssessment,
  zones: PFZZone[] | null,
  note: string | undefined,
  c: Ctx
): OrcaResponse {
  if (!zones || zones.length === 0) {
    return {
      flow: "pfz",
      headline: c.hi ? "PFZ सलाह अनुपलब्ध" : "PFZ ADVISORY UNAVAILABLE",
      headlineHi: "PFZ सलाह अनुपलब्ध",
      tone: "info",
      riskLevel: uiRisk(risk.level),
      summary: c.hi
        ? `${note ?? "आधिकारिक INCOIS PFZ डेटा उपलब्ध नहीं है।"} ORCA बिना आधिकारिक डेटा के मत्स्य क्षेत्र नहीं बनाता।`
        : `${note ?? "Official INCOIS PFZ data is not available right now."} ORCA does not invent fishing zones without official advisories.`,
      summaryHi: `${note ?? "आधिकारिक INCOIS PFZ डेटा अनुपलब्ध है।"} आधिकारिक सलाह के बिना ORCA मत्स्य क्षेत्र नहीं बनाता।`,
      evidence: [
        {
          category: "Marine Data",
          label: "PFZ source",
          labelHi: "PFZ स्रोत",
          value: "INCOIS PFZ · unavailable",
          tone: "warning",
        },
        ...evList(risk, context),
      ],
      advisories: [
        c.hi
          ? "नवीनतम PFZ बुलेटिन incois.gov.in पर उपलब्ध है।"
          : "The latest official PFZ bulletins are published on incois.gov.in.",
      ],
      advisoriesHi: ["नवीनतम आधिकारिक PFZ बुलेटिन incois.gov.in पर उपलब्ध है।"],
      analysis: {
        intent: c.hi ? "मत्स्य क्षेत्र खोज" : "Fishing zone lookup",
        intentHi: "मत्स्य क्षेत्र खोज",
        sources: "INCOIS PFZ (unavailable)",
        sourcesHi: "INCOIS PFZ (अनुपलब्ध)",
        keyEvidence: ["PFZ advisory unavailable"],
        keyEvidenceHi: ["PFZ सलाह अनुपलब्ध"],
        conclusion: "No official PFZ data",
        conclusionHi: "कोई आधिकारिक PFZ डेटा नहीं",
      },
      map: { view: "pfz", center: { lat: context.location.lat, lng: context.location.lon }, zoom: 10 },
      followUps: [
        { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
        { en: "Tomorrow's conditions", hi: "कल का पूर्वानुमान" },
      ],
    };
  }

  const point = { lat: context.location.lat, lon: context.location.lon };
  const nearest = nearestPFZ(point, context.pfz ?? []);
  const z = zones.find((zz) => zz.id === nearest?.advisory.id) ?? zones[0];
  const dist = nearest?.distanceKm ?? z.distanceKm;
  const bear = nearest?.bearing ?? z.bearing;
  return {
    flow: "pfz",
    headline: c.hi ? "आधिकारिक मत्स्य क्षेत्र (INCOIS)" : "OFFICIAL PFZ — INCOIS",
    headlineHi: "आधिकारिक मत्स्य क्षेत्र (INCOIS)",
    tone: "good",
    riskLevel: uiRisk(risk.level),
    summary: c.hi
      ? `आपकी स्थिति से ${dist} किमी ${bear} पर एक आधिकारिक INCOIS PFZ सक्रिय है (यात्रा की सुरक्षा अलग से जाँचें)।`
      : `An official INCOIS PFZ is active ${dist} km ${bear} of your position (${z.label}). Verify sea safety separately before sailing.`,
    summaryHi: `आपकी स्थिति से ${dist} किमी ${bear} पर एक आधिकारिक INCOIS PFZ सक्रिय है।`,
    evidence: [
      { category: "Geospatial & Risk", label: "Distance", labelHi: "दूरी", value: `${dist} km ${bear}`, tone: "good" },
      { category: "Marine Data", label: "Validity", labelHi: "वैधता", value: z.label, tone: "neutral" },
      ...evList(risk, context),
    ],
    advisories: [
      c.hi
        ? "PFZ मछली की संभावना दर्शाता है — समुद्र की सुरक्षा की गारंटी नहीं।"
        : "A PFZ indicates likely fish aggregation — it is not a safety guarantee.",
    ],
    advisoriesHi: ["PFZ मछली की संभावना दर्शाता है — समुद्र की सुरक्षा की गारंटी नहीं।"],
    analysis: {
      intent: c.hi ? "मत्स्य क्षेत्र खोज" : "Fishing zone lookup",
      intentHi: "मत्स्य क्षेत्र खोज",
      sources: "INCOIS PFZ + geospatial",
      sourcesHi: "INCOIS PFZ + भू-स्थानिक",
      keyEvidence: [`${dist} km ${bear}`, "official advisory geometry"],
      keyEvidenceHi: [`${dist} किमी ${bear}`, "आधिकारिक सलाह ज्यामिति"],
      conclusion: "Official PFZ selected by distance",
      conclusionHi: "दूरी के अनुसार आधिकारिक PFZ चयनित",
    },
    map: { view: "pfz", center: z.center, zoom: 10.5 },
    followUps: [
      { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
      { en: "How can I avoid the hazard zone?", hi: "खतरा क्षेत्र से कैसे बचें?" },
    ],
  };
}

function buildHazardResponse(
  context: MarineContext,
  risk: RiskAssessment,
  cy: CycloneInfo | null,
  c: Ctx
): OrcaResponse {
  const imdMeta = context.sourceMeta.find((m) => m.source === "IMD");
  const imdUnavailable = !imdMeta || imdMeta.status === "unavailable";
  const headline = cy
    ? c.hi ? `चक्रवात — ${cy.name}` : `CYCLONE — ${cy.name.toUpperCase()}`
    : c.hi ? "खतरा अवलोकन" : "HAZARD ADVISORY";
  const summary = cy
    ? c.hi
      ? `${cy.name} आपके क्षेत्र से ${cy.distanceKm} किमी ${cy.bearing} पर है (IMD)। ${cy.movement}। आधिकारिक सलाह का पालन करें।`
      : `${cy.name} is ${cy.distanceKm} km ${cy.bearing} of your area (IMD track). ${cy.movement}. Follow official IMD advisories.`
    : c.hi
      ? imdUnavailable
        ? "आधिकारिक चक्रवात चेतावनी डेटा अस्थायी रूप से अनुपलब्ध है (IMD कॉन्फ़िगर नहीं)। मॉडल स्थितियाँ नीचे दी गई हैं।"
        : "IMD के अनुसार इस क्षेत्र में कोई सक्रिय चक्रवाती प्रणाली नहीं है।"
      : imdUnavailable
        ? "Official cyclone warning data is temporarily unavailable (IMD access not configured). Model conditions are shown below."
        : "No active cyclonic system is reported by IMD for this area.";

  const evidence: OrcaResponse["evidence"] = [];
  if (cy) {
    evidence.push({
      category: "Geospatial & Risk",
      label: "Cyclone proximity",
      labelHi: "चक्रवात दूरी",
      value: `${cy.distanceKm} km ${cy.bearing} — IMD`,
      tone: "danger",
    });
  } else {
    evidence.push({
      category: "Geospatial & Risk",
      label: "Cyclone data",
      labelHi: "चक्रवात डेटा",
      value: imdUnavailable ? "Unavailable (IMD not configured)" : "None reported (IMD)",
      tone: imdUnavailable ? "neutral" : "good",
    });
  }
  evidence.push(...evList(risk, context));

  const advisories: string[] = [];
  const officialLists: { kind: string; list: MarineWarning[] }[] = [
    { kind: "fishermen", list: context.warnings?.fishermen ?? [] },
    { kind: "coastal", list: context.warnings?.coastal ?? [] },
    { kind: "sea area", list: context.warnings?.seaArea ?? [] },
  ];
  for (const { kind, list } of officialLists) {
    for (const w of list.slice(0, 2)) {
      advisories.push(`IMD ${kind}: ${w.title}`);
    }
  }
  if (imdUnavailable) {
    advisories.push(
      c.hi
        ? "IMD एकीकरण के लिए आधिकारिक API क्रेडेंशियल आवश्यक हैं (imdapi.org)।"
        : "IMD integration requires official API credentials (imdapi.org)."
    );
  }

  return {
    flow: "hazard",
    headline,
    headlineHi: headline,
    tone: cy ? "danger" : risk.level === "HIGH" ? "warning" : "info",
    riskLevel: uiRisk(risk.level),
    summary,
    summaryHi: summary,
    evidence,
    advisories: advisories.length ? advisories : [c.hi ? "कोई सक्रिय आधिकारिक चेतावनी नहीं।" : "No active official warnings retrieved."],
    advisoriesHi: advisories.length ? advisories : ["कोई सक्रिय आधिकारिक चेतावनी नहीं।"],
    analysis: {
      intent: c.hi ? "खतरा निरीक्षण" : "Hazard inspection",
      intentHi: "खतरा निरीक्षण",
      sources: "IMD warnings + cyclone track + model conditions",
      sourcesHi: "IMD चेतावनियाँ + चक्रवात ट्रैक + मॉडल स्थितियाँ",
      keyEvidence: evidence.slice(0, 3).map((e) => e.value),
      keyEvidenceHi: evidence.slice(0, 3).map((e) => e.value),
      conclusion: cy ? "Official cyclone detected" : imdUnavailable ? "Cyclone source unavailable" : "No cyclone reported",
      conclusionHi: cy ? "आधिकारिक चक्रवात पाया गया" : imdUnavailable ? "चक्रवात स्रोत अनुपलब्ध" : "कोई चक्रवात नहीं",
    },
    map: {
      view: "hazard",
      center: cy ? cy.center : { lat: context.location.lat, lng: context.location.lon },
      zoom: 9.6,
    },
    followUps: [
      { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
      { en: "How can I avoid the hazard zone?", hi: "खतरा क्षेत्र से कैसे बचें?" },
    ],
  };
}

function buildRouteResponse(
  routeResult: Awaited<ReturnType<typeof computeSaferRoute>>,
  risk: RiskAssessment,
  context: MarineContext,
  c: Ctx
): OrcaResponse {
  if (routeResult.status === "NO_SAFE_PATH") {
    return {
      flow: "route",
      headline: c.hi ? "कोई कम-जोखिम मार्ग नहीं मिला" : "NO LOWER-RISK PATH FOUND",
      headlineHi: "कोई कम-जोखिम मार्ग नहीं मिला",
      tone: "warning",
      riskLevel: uiRisk(risk.level),
      summary: routeResult.explanation.join(" "),
      summaryHi: routeResult.explanationHi.join(" "),
      evidence: evList(risk, context),
      advisories: [
        c.hi
          ? "समुद्र में निकलने से पहले आधिकारिक चेतावनी जाँचें।"
          : "Check official warnings before venturing out.",
      ],
      advisoriesHi: ["समुद्र में निकलने से पहले आधिकारिक चेतावनी जाँचें।"],
      analysis: {
        intent: c.hi ? "सुरक्षित मार्ग सुझाव" : "Safer route suggestion",
        intentHi: "सुरक्षित मार्ग सुझाव",
        sources: "A* route engine + marine model",
        sourcesHi: "A* रूट इंजन + समुद्री मॉडल",
        keyEvidence: routeResult.explanation.slice(0, 2),
        keyEvidenceHi: routeResult.explanationHi.slice(0, 2),
        conclusion: "No safe path",
        conclusionHi: "कोई सुरक्षित मार्ग नहीं",
      },
      map: { view: "route", center: { lat: context.location.lat, lng: context.location.lon }, zoom: 10 },
      followUps: [
        { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
        { en: "Tomorrow's conditions", hi: "कल का पूर्वानुमान" },
      ],
    };
  }

  const headline = c.hi ? "सुझाया गया कम-जोखिम मार्ग" : "SUGGESTED LOWER-RISK PATH";
  return {
    flow: "route",
    headline,
    headlineHi: headline,
    tone: "info",
    riskLevel: uiRisk(risk.level),
    summary: routeResult.explanation.join(" "),
    summaryHi: routeResult.explanationHi.join(" "),
    evidence: [
      {
        category: "Geospatial & Risk",
        label: "Path length",
        labelHi: "मार्ग की लंबाई",
        value: `${routeResult.distanceKm} km`,
        tone: "good",
      },
      {
        category: "Geospatial & Risk",
        label: "Est. time",
        labelHi: "अनुमानित समय",
        value: `≈ ${routeResult.estimatedTravelTimeHours ?? "—"} h`,
        tone: "neutral",
      },
      ...(routeResult.minimumHazardClearanceKm != null
        ? [{
            category: "Geospatial & Risk" as const,
            label: "Hazard clearance",
            labelHi: "खतरे से दूरी",
            value: `${routeResult.minimumHazardClearanceKm}+ km`,
            tone: "good" as const,
          }]
        : []),
      ...evList(risk, context),
    ],
    advisories: routeResult.explanation.slice(-1),
    advisoriesHi: routeResult.explanationHi.slice(-1),
    analysis: {
      intent: c.hi ? "सुरक्षित मार्ग सुझाव" : "Safer route suggestion",
      intentHi: "सुरक्षित मार्ग सुझाव",
      sources: "A* over marine grid (Open-Meteo + IMD + boundary)",
      sourcesHi: "समुद्री ग्रिड पर A* (Open-Meteo + IMD + सीमा)",
      keyEvidence: routeResult.explanation.slice(0, 2),
      keyEvidenceHi: routeResult.explanationHi.slice(0, 2),
      conclusion: "Lower-risk path found",
      conclusionHi: "कम-जोखिम मार्ग मिला",
    },
    map: { view: "route", center: { lat: context.location.lat, lng: context.location.lon }, zoom: 10.2 },
    followUps: [
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
      { en: "Tomorrow's conditions", hi: "कल का पूर्वानुमान" },
    ],
  };
}

function buildExplainResponse(
  context: MarineContext,
  risk: RiskAssessment,
  c: Ctx
): OrcaResponse {
  const src = sourceLine(context);
  return {
    flow: "explain",
    headline: c.hi ? "क्षेत्र मूल्यांकन" : "REGION ASSESSMENT",
    headlineHi: "क्षेत्र मूल्यांकन",
    tone: "info",
    riskLevel: uiRisk(risk.level),
    summary: c.hi
      ? `आकलन उपलब्ध स्रोतों पर आधारित है: ${src}. जोखिम नियम निर्धारित (deterministic) हैं — प्रोटोटाइप सुरक्षा नीति के अनुसार।`
      : `The assessment is based on: ${src}. Risk rules are deterministic, applied per the prototype safety policy.`,
    summaryHi: `आकलन उपलब्ध स्रोतों पर आधारित है। जोखिम नियम निर्धारित हैं — प्रोटोटाइप सुरक्षा नीति के अनुसार।`,
    evidence: evList(risk, context),
    advisories: risk.reasons.map((r) => (c.hi ? r.hi : r.en)),
    advisoriesHi: risk.reasons.map((r) => r.hi),
    analysis: {
      intent: c.hi ? "व्याख्या" : "Explainability",
      intentHi: "व्याख्या",
      sources: src || "No sources available",
      sourcesHi: src || "कोई स्रोत उपलब्ध नहीं",
      keyEvidence: risk.evidence.slice(0, 3).map((e) => e.value),
      keyEvidenceHi: risk.evidence.slice(0, 3).map((e) => e.value),
      conclusion: `Risk ${risk.level} · data ${risk.dataQuality}`,
      conclusionHi: `जोखिम ${risk.level} · डेटा ${risk.dataQuality}`,
    },
    map: { view: "conditions", center: { lat: context.location.lat, lng: context.location.lon }, zoom: 9.4 },
    followUps: [
      { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
    ],
  };
}

function buildConditionsResponse(
  context: MarineContext,
  risk: RiskAssessment,
  c: Ctx & { tomorrowWave: number | null }
): OrcaResponse {
  const wave = context.ocean?.waveHeightM;
  const wind = context.weather?.windSpeedMps ?? context.ocean?.windSpeedMps;
  const sst = context.ocean?.sstC;
  const waveTomorrow = c.tomorrowWave ?? wave ?? null;

  const parts: string[] = [];
  if (wave != null) parts.push(`waves ${wave} m${waveTomorrow != null ? ` → ${waveTomorrow} m (forecast)` : ""} (model)`);
  if (wind != null) parts.push(`wind ${Math.round(wind * 3.6)} km/h (model)`);
  if (sst != null) parts.push(`SST ${sst} °C (model)`);
  const summary =
    parts.length > 0
      ? c.hi
        ? `${c.locNameHi} के पास: ${parts.join(", ")}। स्रोत: ${sourceLine(context)}।`
        : `Near ${c.locName}: ${parts.join(", ")}. Source: ${sourceLine(context)}.`
      : c.hi
        ? "मॉडल समुद्री डेटा अभी अनुपलब्ध है — कुछ भी नहीं बनाया गया है।"
        : "Model marine data is unavailable right now — no values have been invented.";

  const evidence: OrcaResponse["evidence"] = [];
  if (wave != null)
    evidence.push({
      category: "Weather & Ocean",
      label: "Wave height",
      labelHi: "लहर की ऊँचाई",
      value: `${wave} m${waveTomorrow != null ? ` → ${waveTomorrow} m` : ""} (model)`,
      tone: wave >= c.profile.maxWaveHeightM ? "danger" : wave >= 0.7 * c.profile.maxWaveHeightM ? "warning" : "good",
    });
  if (wind != null)
    evidence.push({
      category: "Weather & Ocean",
      label: "Wind",
      labelHi: "हवा",
      value: `${Math.round(wind * 3.6)} km/h (model)`,
      tone: wind >= c.profile.maxWindSpeedMps ? "danger" : wind >= 0.7 * c.profile.maxWindSpeedMps ? "warning" : "good",
    });
  if (sst != null)
    evidence.push({ category: "Marine Data", label: "Sea surface temp.", labelHi: "समुद्री सतह तापमान", value: `${sst} °C (model)`, tone: "neutral" });
  evidence.push({
    category: "Marine Data",
    label: "Sources",
    labelHi: "स्रोत",
    value: sourceLine(context) || "unavailable",
    tone: "neutral",
  });

  return {
    flow: "conditions",
    headline: c.hi ? "समुद्री पूर्वानुमान" : "MARINE OUTLOOK",
    headlineHi: "समुद्री पूर्वानुमान",
    tone: risk.level === "HIGH" || risk.level === "CRITICAL" ? "danger" : risk.level === "MODERATE" ? "warning" : risk.level === "LOW" ? "good" : "info",
    riskLevel: uiRisk(risk.level),
    summary,
    summaryHi: summary,
    evidence,
    advisories: risk.reasons.map((r) => (c.hi ? r.hi : r.en)),
    advisoriesHi: risk.reasons.map((r) => r.hi),
    analysis: {
      intent: c.hi ? "पूर्वानुमान सारांश" : "Forecast summary",
      intentHi: "पूर्वानुमान सारांश",
      sources: sourceLine(context) || "unavailable",
      sourcesHi: sourceLine(context) || "अनुपलब्ध",
      keyEvidence: evidence.slice(0, 3).map((e) => e.value),
      keyEvidenceHi: evidence.slice(0, 3).map((e) => e.value),
      conclusion: HEADLINES[risk.level].en.toLowerCase(),
      conclusionHi: HEADLINES[risk.level].hi,
    },
    map: { view: "conditions", center: { lat: context.location.lat, lng: context.location.lon }, zoom: 9.4 },
    followUps: [
      { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function uiRisk(level: RiskLevel): "low" | "moderate" | "high" {
  if (level === "LOW") return "low";
  if (level === "MODERATE") return "moderate";
  if (level === "UNKNOWN") return "low";
  return "high";
}

function flowResponseCenter(
  flow: FlowId,
  point: { lat: number; lon: number },
  cy: CycloneInfo | null,
  pfz: PFZZone[] | null
): { lat: number; lng: number } {
  if (flow === "safety" && cy) {
    return {
      lat: (point.lat + cy.center.lat) / 2,
      lng: (point.lon + cy.center.lng) / 2,
    };
  }
  if (flow === "hazard" && cy) return cy.center;
  if (flow === "pfz" && pfz && pfz.length) return pfz[0].center;
  return { lat: point.lat, lng: point.lon };
}

function pickLowestCostGoal(
  cells: RiskCell[],
  start: { lat: number; lon: number }
): { lat: number; lon: number } {
  const levelScore: Record<string, number> = { CRITICAL: 4, HIGH: 3, MODERATE: 2, LOW: 0, UNKNOWN: 2.5 };
  let best: { lat: number; lon: number; score: number } | null = null;
  for (const c of cells) {
    const d = distanceKm(start, { lat: c.lat, lon: c.lng });
    if (d < 12 || d > 45) continue;
    const score = levelScore[c.level] ?? 3;
    if (
      !best ||
      score < best.score ||
      (score === best.score && d < distanceKm(start, { lat: best.lat, lon: best.lon }))
    ) {
      best = { lat: c.lat, lon: c.lng, score };
    }
  }
  if (!best) {
    /* fall back to a point offshore toward the boundary interior */
    return { lat: start.lat + 0.15, lon: start.lon + 0.1 };
  }
  return { lat: best.lat, lon: best.lon };
}
