/**
 * Risk-aware route engine (STEP 10 + §15, §16) — real A* over a bounded
 * marine grid. No hardcoded route arrays.
 *
 * Cost model (prototype policy):
 *   traversalCost(n) =
 *     distanceCost
 *   + waveRiskCost   (relative to the vessel profile's max wave)
 *   + windRiskCost   (relative to the vessel profile's max wind)
 *   + currentCost    (opposing currents add cost)
 *   + cycloneRiskCost(distance from IMD cyclone track positions)
 *   + boundaryPenalty(beyond the prototype offshore boundary = blocked)
 *
 * Blocked cells: beyond prototype boundary, or inside an official hazard
 * geometry. Marine variables are sampled at grid anchor points via
 * Open-Meteo (cached) and bilinearly interpolated — always labeled "model".
 */

import type { CycloneData, RouteResult, VesselSafetyProfile } from "../marine/types";
import { getOpenMeteoMarineForecast, getOpenMeteoWeather } from "../marine/openMeteo";
import { beyondBoundary, distanceKm, pointInPolygon, geojsonRingToLatLng } from "./geospatial";
import { round } from "../marine/normalizer";

/* ---------------- tunables (prototype policy) ---------------- */

export const ROUTE_CONFIG = {
  /** approx grid step in degrees (~5.5 km) */
  resolutionDeg: 0.05,
  maxNodes: 900,
  marginDeg: 0.18,
  /** extra wave cost per meter above half of the profile limit */
  waveCostWeight: 14,
  windCostWeight: 10,
  currentCostWeight: 4,
  cycloneCostWeight: 22,
  boundaryPenalty: 260,
  /** official hazard / blocked cell */
  blockedCost: Infinity,
} as const;

interface Cell {
  lat: number;
  lng: number;
  i: number;
  j: number;
  wave: number | null;
  wind: number | null;
  gust: number | null;
  current: number | null;
  blocked: boolean;
}

export interface RouteInput {
  start: { lat: number; lon: number };
  goal: { lat: number; lon: number };
  profile: VesselSafetyProfile;
  boundary?: { points: [number, number][]; label: string } | null;
  cyclones?: CycloneData[];
  /** official exclusion polygons as [lat,lng] rings */
  hazardRings?: [number, number][][];
  /** injectable sampler for tests (defaults to Open-Meteo live sampling) */
  sampleMarineFn?: (lat: number, lon: number) => Promise<{
    wave: number | null;
    wind: number | null;
    gust: number | null;
    current: number | null;
  }>;
}

/* ------------------------------------------------------------------ */
/* Grid + marine sampling                                              */
/* ------------------------------------------------------------------ */

function buildGridBounds(input: RouteInput) {
  const lats = [input.start.lat, input.goal.lat];
  const lons = [input.start.lon, input.goal.lon];
  const m = ROUTE_CONFIG.marginDeg;
  return {
    latMin: Math.min(...lats) - m,
    latMax: Math.max(...lats) + m,
    lonMin: Math.min(...lons) - m,
    lonMax: Math.max(...lons) + m,
  };
}

async function sampleMarine(lat: number, lon: number): Promise<{ wave: number | null; wind: number | null; gust: number | null; current: number | null }> {
  const [marine, weather] = await Promise.all([
    getOpenMeteoMarineForecast(lat, lon),
    getOpenMeteoWeather(lat, lon),
  ]);
  return {
    wave: marine.ok ? (marine.ocean.waveHeightM ?? null) : null,
    wind: weather.ok ? (weather.weather.windSpeedMps ?? null) : null,
    gust: weather.ok ? (weather.weather.gustSpeedMps ?? null) : null,
    current: marine.ok ? (marine.ocean.currentSpeedMps ?? null) : null,
  };
}

/**
 * Sample the grid at up to 9 anchor points (3×3 over the bounds), cached by
 * the marine service; cells interpolate between anchors (documented as a
 * model estimate). Few upstream calls, honest coverage.
 */
export async function sampleAnchors(
  bounds: ReturnType<typeof buildGridBounds>,
  sampler: (lat: number, lon: number) => Promise<{
    wave: number | null;
    wind: number | null;
    gust: number | null;
    current: number | null;
  }> = sampleMarine
) {
  const anchors: { lat: number; lon: number; value: Awaited<ReturnType<typeof sampleMarine>> }[] = [];
  const lats = [bounds.latMin, (bounds.latMin + bounds.latMax) / 2, bounds.latMax];
  const lons = [bounds.lonMin, (bounds.lonMin + bounds.lonMax) / 2, bounds.lonMax];
  const jobs: Promise<void>[] = [];
  for (const lat of lats) {
    for (const lon of lons) {
      jobs.push(
        sampler(lat, lon).then((value) => {
          anchors.push({ lat, lon, value });
        })
      );
    }
  }
  await Promise.all(jobs);
  return anchors;
}

export function interpolateAnchors(
  anchors: Awaited<ReturnType<typeof sampleAnchors>>,
  lat: number,
  lon: number
): { wave: number | null; wind: number | null; gust: number | null; current: number | null } {
  /* inverse-distance weighting over anchors */
  let wSum = 0;
  const acc = { wave: 0, wind: 0, gust: 0, current: 0 };
  const present = { wave: false, wind: false, gust: false, current: false };
  for (const a of anchors) {
    const d2 = Math.max(1e-6, (a.lat - lat) ** 2 + (a.lon - lon) ** 2);
    const w = 1 / d2;
    wSum += w;
    if (a.value.wave != null) {
      acc.wave += w * a.value.wave;
      present.wave = true;
    }
    if (a.value.wind != null) {
      acc.wind += w * a.value.wind;
      present.wind = true;
    }
    if (a.value.gust != null) {
      acc.gust += w * a.value.gust;
      present.gust = true;
    }
    if (a.value.current != null) {
      acc.current += w * a.value.current;
      present.current = true;
    }
  }
  if (wSum === 0) return { wave: null, wind: null, gust: null, current: null };
  return {
    wave: present.wave ? Math.round((acc.wave / wSum) * 100) / 100 : null,
    wind: present.wind ? Math.round((acc.wind / wSum) * 100) / 100 : null,
    gust: present.gust ? Math.round((acc.gust / wSum) * 100) / 100 : null,
    current: present.current ? Math.round((acc.current / wSum) * 1000) / 1000 : null,
  };
}

/* ------------------------------------------------------------------ */
/* A*                                                                  */
/* ------------------------------------------------------------------ */

export async function computeSaferRoute(input: RouteInput): Promise<RouteResult> {
  const { profile: p } = input;
  const bounds = buildGridBounds(input);
  const anchors = await sampleAnchors(bounds, input.sampleMarineFn);

  const step = ROUTE_CONFIG.resolutionDeg;
  const nLat = Math.min(40, Math.ceil((bounds.latMax - bounds.latMin) / step) + 1);
  const nLon = Math.min(40, Math.ceil((bounds.lonMax - bounds.lonMin) / step) + 1);

  /* cyclone positions for cost (IMD track when available) */
  const cyPoints = (input.cyclones ?? []).flatMap((c) => [
    { lat: c.position.lat, lon: c.position.lon },
    ...(c.track ?? []).map((t) => ({ lat: t.lat, lon: t.lon })),
  ]);

  const cells = new Map<string, Cell>();
  const key = (i: number, j: number) => `${i}:${j}`;
  for (let i = 0; i < nLat; i++) {
    for (let j = 0; j < nLon; j++) {
      const lat = bounds.latMin + i * ((bounds.latMax - bounds.latMin) / (nLat - 1));
      const lng = bounds.lonMin + j * ((bounds.lonMax - bounds.lonMin) / (nLon - 1));
      const pt = { lat, lon: lng };
      const v = interpolateAnchors(anchors, lat, lng);

      let blocked = false;
      /* boundary: seaward of the prototype boundary is blocked (entry prohibited) */
      if (input.boundary) {
        const ref = { lat: input.start.lat, lon: input.start.lon };
        blocked = beyondBoundary(pt, input.boundary.points, ref).beyond;
      }
      /* official hazard rings */
      if (!blocked && input.hazardRings?.length) {
        blocked = input.hazardRings.some((ring) => pointInPolygon(lat, lng, ring));
      }
      cells.set(key(i, j), { lat, lng, i, j, ...v, blocked });
    }
  }

  const startKey = nearestCell(cells, input.start.lat, input.start.lon);
  const goalKey = nearestCell(cells, input.goal.lat, input.goal.lon);
  if (!startKey || !goalKey) return noPath(["Start or goal outside the sampled marine grid."], ["प्रारंभ या गंतव्य सैंपल किए गए ग्रिड के बाहर है।"]);

  /* A* */
  const openSet = new Map<string, number>();
  const gScore = new Map<string, number>();
  const cameFrom = new Map<string, string>();
  openSet.set(startKey, 0);
  gScore.set(startKey, 0);

  const goalCell = cells.get(goalKey)!;
  const h = (c: Cell) => octile(c, goalCell);

  const directions: [number, number, number][] = [
    [-1, 0, 1], [1, 0, 1], [0, -1, 1], [0, 1, 1],
    [-1, -1, Math.SQRT2], [-1, 1, Math.SQRT2], [1, -1, Math.SQRT2], [1, 1, Math.SQRT2],
  ];

  let expanded = 0;
  let found = false;
  while (openSet.size > 0 && expanded < ROUTE_CONFIG.maxNodes) {
    /* pop min f */
    let bestKey = "";
    let bestF = Infinity;
    for (const [k, g] of openSet) {
      const c = cells.get(k)!;
      const f = g + h(c);
      if (f < bestF) {
        bestF = f;
        bestKey = k;
      }
    }
    if (!bestKey) break;
    const currentKey = bestKey;
    if (currentKey === goalKey) {
      found = true;
      break;
    }
    openSet.delete(currentKey);
    expanded++;
    const cur = cells.get(currentKey)!;

    for (const [di, dj, move] of directions) {
      const ni = cur.i + di;
      const nj = cur.j + dj;
      const nk = key(ni, nj);
      const next = cells.get(nk);
      if (!next || next.blocked) continue;

      const stepCost =
        move *
        (1 +
          waveCost(next.wave, p) +
          windCost(next.wind, next.gust, p) +
          currentCost(next.current, cur, next) +
          cycloneCost(next, cyPoints));

      const tentative = (gScore.get(currentKey) ?? Infinity) + stepCost;
      if (tentative < (gScore.get(nk) ?? Infinity)) {
        cameFrom.set(nk, currentKey);
        gScore.set(nk, tentative);
        openSet.set(nk, tentative);
      }
    }
  }

  if (!found) {
    return noPath(
      [
        "No lower-risk path found within the sampled area — every route crosses blocked or very-high-cost cells.",
        "This may also mean marine data coverage was insufficient.",
      ],
      [
        "सैंपल किए गए क्षेत्र में कोई कम-जोखिम मार्ग नहीं मिला — हर मार्ग अवरोधित या अत्यधिक-लागत वाले क्षेत्रों से गुज़रता है।",
        "यह समुद्री डेटा कवरेज की कमी भी हो सकती है।",
      ]
    );
  }

  /* reconstruct */
  const path: Cell[] = [];
  let cursor: string | undefined = goalKey;
  while (cursor) {
    const c = cells.get(cursor);
    if (c) path.unshift(c);
    cursor = cameFrom.get(cursor);
  }
  path.unshift(cells.get(startKey)!);

  /* decimate for map rendering */
  const points: [number, number][] = path.map((c) => [round(c.lat, 4) as number, round(c.lng, 4) as number]);
  const decimated = decimate(points, 24);

  let distanceKmTotal = 0;
  for (let i = 1; i < path.length; i++) {
    distanceKmTotal += distanceKm(
      { lat: path[i - 1].lat, lon: path[i - 1].lng },
      { lat: path[i].lat, lon: path[i].lng }
    );
  }

  /* hazard clearance = min distance from path points to cyclone positions + boundary */
  let minClearance = Infinity;
  for (const c of path) {
    for (const cy of cyPoints) {
      minClearance = Math.min(minClearance, distanceKm({ lat: c.lat, lon: c.lng }, cy));
    }
  }
  const clearance = Number.isFinite(minClearance) ? round(minClearance, 1) : undefined;

  const eta = distanceKmTotal / p.cruiseSpeedKmh;
  const hasModel =
    path.some((c) => c.wave != null) || path.some((c) => c.wind != null);

  const explanation: string[] = [
    "A* search over a bounded marine grid; costs from Open-Meteo model waves/wind, currents, IMD cyclone positions and the prototype boundary.",
    `Path length ≈ ${Math.round(distanceKmTotal)} km at ${p.cruiseSpeedKmh} km/h cruise ≈ ${eta.toFixed(1)} h.`,
    "Based on available marine data — this is a suggested lower-risk route, not a navigation directive.",
  ];
  const explanationHi: string[] = [
    "सीमित समुद्री ग्रिड पर A* खोज; लागत Open-Meteo मॉडल लहर/हवा, धाराएँ, IMD चक्रवात स्थितियों और प्रोटोटाइप सीमा से है।",
    `मार्ग ≈ ${Math.round(distanceKmTotal)} किमी, ${p.cruiseSpeedKmh} किमी/घं क्रूज़िंग पर ≈ ${eta.toFixed(1)} घंटे।`,
    "उपलब्ध समुद्री डेटा पर आधारित — यह सुझाया गया कम-जोखिम मार्ग है, नेविगेशन निर्देश नहीं।",
  ];
  if (!hasModel) {
    explanation.push("Note: model marine values were unavailable along the path; route uses geometric costs only.");
    explanationHi.push("नोट: मार्ग पर मॉडल मान उपलब्ध नहीं थे; मार्ग केवल ज्यामितीय लागतों पर आधारित है।");
  }
  if (clearance != null) {
    explanation.push(`Minimum clearance from cyclone track points: ${clearance} km.`);
    explanationHi.push(`चक्रवात ट्रैक बिंदुओं से न्यूनतम दूरी: ${clearance} किमी।`);
  }

  return {
    points: decimated,
    distanceKm: Math.round(distanceKmTotal),
    estimatedTravelTimeHours: round(eta, 1),
    minimumHazardClearanceKm: clearance,
    status: "FOUND",
    explanation,
    explanationHi,
  };
}

function noPath(en: string[], hi: string[]): RouteResult {
  return { points: [], distanceKm: 0, status: "NO_SAFE_PATH", explanation: en, explanationHi: hi };
}

/* ---------------- cost pieces ---------------- */

function waveCost(wave: number | null, p: VesselSafetyProfile): number {
  if (wave == null) return 0.15; /* unknown cell — mild uncertainty penalty */
  const ratio = wave / p.maxWaveHeightM;
  if (ratio >= 1) return ROUTE_CONFIG.blockedCost === Infinity ? 99 : ROUTE_CONFIG.blockedCost;
  return Math.max(0, ROUTE_CONFIG.waveCostWeight * Math.max(0, ratio - 0.35) ** 2);
}

function windCost(wind: number | null, gust: number | null, p: VesselSafetyProfile): number {
  const w = wind ?? gust;
  if (w == null) return 0.1;
  const ratio = w / p.maxWindSpeedMps;
  if (ratio >= 1) return 99;
  return Math.max(0, ROUTE_CONFIG.windCostWeight * Math.max(0, ratio - 0.4) ** 2);
}

function currentCost(current: number | null, prev: Cell, next: Cell): number {
  if (current == null || prev.current == null) return 0;
  /* simple proxy: higher opposing current magnitude between cells adds cost */
  return ROUTE_CONFIG.currentCostWeight * Math.max(0, Math.min(current, prev.current)) ** 2;
}

function cycloneCost(cell: Cell, cyPoints: { lat: number; lon: number }[]): number {
  if (!cyPoints.length) return 0;
  let minD = Infinity;
  for (const cp of cyPoints) {
    minD = Math.min(minD, distanceKm({ lat: cell.lat, lon: cell.lng }, cp));
  }
  if (minD < 30) return 99; /* hard avoid near the center/track */
  return ROUTE_CONFIG.cycloneCostWeight * (1 / Math.max(1, minD - 30)) ** 2 * 100;
}

function octile(a: Cell, b: Cell): number {
  const dx = Math.abs(a.i - b.i);
  const dy = Math.abs(a.j - b.j);
  return (dx + dy) + (Math.SQRT2 - 2) * Math.min(dx, dy);
}

function nearestCell(cells: Map<string, Cell>, lat: number, lng: number): string | null {
  let bestKey: string | null = null;
  let bestD = Infinity;
  for (const [k, c] of cells) {
    const d = (c.lat - lat) ** 2 + (c.lng - lng) ** 2;
    if (d < bestD) {
      bestD = d;
      bestKey = k;
    }
  }
  return bestKey;
}

function decimate(points: [number, number][], maxPoints: number): [number, number][] {
  if (points.length <= maxPoints) return points;
  const stepN = Math.ceil(points.length / maxPoints);
  const out: [number, number][] = [];
  for (let i = 0; i < points.length; i += stepN) out.push(points[i]);
  const last = points[points.length - 1];
  if (out[out.length - 1] !== last) out.push(last);
  return out;
}

/* keep geojsonRingToLatLng referenced for future official-geometry inputs */
void geojsonRingToLatLng;
