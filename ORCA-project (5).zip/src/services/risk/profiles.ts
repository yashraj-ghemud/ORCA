/**
 * Vessel safety profiles — ⚠️ PROTOTYPE SAFETY POLICY.
 * These thresholds are engineering placeholders for the demo, NOT values
 * validated by marine-domain experts or any maritime authority. They are
 * surfaced in the UI as "prototype safety policy" (§11).
 */

import type { VesselSafetyProfile } from "../marine/types";

export const VESSEL_PROFILES: Record<string, VesselSafetyProfile> = {
  small_fibre: {
    id: "small_fibre",
    label: "Small fibre boat (6–9 m)",
    labelHi: "छोटी फाइबर नाव (6–9 मी)",
    maxWaveHeightM: 1.5,
    maxWindSpeedMps: 10.3,
    maxGustSpeedMps: 13.9,
    maxSwellHeightM: 2.0,
    cycloneAdvisoryDistanceKm: 300,
    cruiseSpeedKmh: 18,
  },
  mechanised: {
    id: "mechanised",
    label: "Mechanised fishing boat (9–15 m)",
    labelHi: "मशीनीकृत मत्स्य नौका (9–15 मी)",
    maxWaveHeightM: 2.5,
    maxWindSpeedMps: 13.9,
    maxGustSpeedMps: 17.2,
    maxSwellHeightM: 3.0,
    cycloneAdvisoryDistanceKm: 200,
    cruiseSpeedKmh: 22,
  },
  larger: {
    id: "larger",
    label: "Larger vessel (15 m+)",
    labelHi: "बड़ा जहाज़ (15 मी+)",
    maxWaveHeightM: 3.5,
    maxWindSpeedMps: 17.2,
    maxGustSpeedMps: 21.0,
    maxSwellHeightM: 4.0,
    cycloneAdvisoryDistanceKm: 150,
    cruiseSpeedKmh: 30,
  },
};

export const DEFAULT_PROFILE = VESSEL_PROFILES.small_fibre;

export function getProfile(id: string | undefined | null): VesselSafetyProfile {
  return (id && VESSEL_PROFILES[id]) || DEFAULT_PROFILE;
}
