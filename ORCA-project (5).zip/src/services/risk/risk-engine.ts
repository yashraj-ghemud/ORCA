/**
 * Deterministic risk engine (STEP 6 + §11, §22).
 * evaluateMarineRisk(context, vesselProfile) — rules over structured,
 * normalized data. The LLM never computes risk.
 *
 * Safety semantics (§22):
 *   - an official warning dominates anything else
 *   - insufficient data ⇒ UNKNOWN, never LOW
 *   - stale data limits confidence and caps conclusions at MODERATE-at-best
 */

import type {
  CycloneData,
  DataQuality,
  MarineContext,
  RiskAssessment,
  RiskLevel,
  RiskReason,
  VesselSafetyProfile,
} from "../marine/types";
import { evaluateCycloneProximity, worstCycloneStatus, type CycloneProximity } from "./cyclone";
import { beyondBoundary, distanceKm } from "./geospatial";
import { round } from "../marine/normalizer";
import { getFreshnessStatus } from "../marine/freshness";

function reason(code: string, en: string, hi: string): RiskReason {
  return { code, en, hi };
}

export interface RiskInput {
  context: MarineContext;
  vesselProfile: VesselSafetyProfile;
  /** monitored position for boundary checks (defaults to context location) */
  monitorPoint?: { lat: number; lon: number };
}

export function evaluateMarineRisk(input: RiskInput): RiskAssessment {
  const { context, vesselProfile: p } = input;
  const point = input.monitorPoint ?? { lat: context.location.lat, lon: context.location.lon };

  const wave = context.ocean?.waveHeightM;
  const wavePeriod = context.ocean?.wavePeriodS;
  const swell = context.ocean?.swellHeightM;
  const wind = context.weather?.windSpeedMps ?? context.ocean?.windSpeedMps ?? undefined;
  const gust = context.weather?.gustSpeedMps;

  const evidence: RiskAssessment["evidence"] = [];
  const reasons: RiskReason[] = [];

  /* ---------------- official warnings (authoritative, dominate) ---------------- */
  const officialWarnings: { kind: string; list: NonNullable<MarineContext["warnings"]>[keyof NonNullable<MarineContext["warnings"]>] }[] = [
    { kind: "fishermen", list: context.warnings?.fishermen ?? [] },
    { kind: "coastal", list: context.warnings?.coastal ?? [] },
    { kind: "seaArea", list: context.warnings?.seaArea ?? [] },
  ];
  const activeOfficial = officialWarnings.flatMap(({ kind, list }) =>
    (list ?? []).map((w) => ({ kind, w }))
  );
  const severeOfficial = activeOfficial.filter(
    ({ w }) =>
      !w.demo && (w.severity === "warning" || w.severity === "watch")
  );
  /* demo advisories are simulated — they may raise caution, never CRITICAL */
  const demoOfficial = activeOfficial.filter(({ w }) => w.demo);

  /* ---------------- cyclone proximity (geographic) ---------------- */
  const cyclones: CycloneData[] = context.warnings?.cyclone ?? [];
  const proximities: CycloneProximity[] = evaluateCycloneProximity(
    point,
    cyclones,
    context.targetTime,
    p.cycloneAdvisoryDistanceKm
  );
  const cyStatus = worstCycloneStatus(proximities);

  /* ---------------- data quality ---------------- */
  const statuses = context.sourceMeta.map((m) => m.status);
  const unavailableCount = statuses.filter((s) => s === "unavailable").length;
  const staleCount = statuses.filter((s) => s === "stale").length;
  const okCount = statuses.length - unavailableCount - staleCount;

  const hasOcean = wave != null || swell != null;
  const hasWind = wind != null || gust != null;
  const requiredMissing = !hasOcean && !hasWind;

  let dataQuality: DataQuality;
  if (requiredMissing && okCount === 0) dataQuality = "INSUFFICIENT";
  else if (staleCount > 0 && okCount <= 1) dataQuality = "STALE";
  else if (requiredMissing) dataQuality = "INSUFFICIENT";
  else if (staleCount > 0 || unavailableCount > 0) dataQuality = "LIMITED";
  else dataQuality = "GOOD";

  /* staleness of the marine variables we rely on */
  const oceanMeta = context.sourceMeta.find((m) => m.kind === "ocean_forecast");
  const oceanStale = oceanMeta?.status === "stale" || oceanMeta?.status === "unavailable";
  const weatherMeta = context.sourceMeta.find((m) => m.kind === "weather_forecast");
  const weatherStale = weatherMeta?.status === "stale" || weatherMeta?.status === "unavailable";

  /* ---------------- boundary (prototype geofence) ---------------- */
  let beyondBnd = false;
  let boundaryDistKm: number | null = null;
  if (context.boundary) {
    const ref = { lat: context.location.lat, lon: context.location.lon };
    const b = beyondBoundary(point, context.boundary.points, ref);
    beyondBnd = b.beyond;
    boundaryDistKm = b.distanceKm;
  }

  /* ---------------- evidence rows ---------------- */
  if (wave != null)
    evidence.push({
      label: "Wave height",
      labelHi: "लहर की ऊँचाई",
      value: `${wave} m${wavePeriod ? ` · ${wavePeriod} s` : ""} (model)`,
      tone: wave >= p.maxWaveHeightM ? "danger" : wave >= 0.7 * p.maxWaveHeightM ? "warning" : "good",
    });
  if (wind != null)
    evidence.push({
      label: "Wind",
      labelHi: "हवा",
      value: `${round(wind * 3.6, 0)} km/h${gust != null ? ` · gust ${round(gust * 3.6, 0)}` : ""} (model)`,
      tone:
        wind >= p.maxWindSpeedMps || (gust != null && gust >= p.maxGustSpeedMps)
          ? "danger"
          : wind >= 0.7 * p.maxWindSpeedMps
            ? "warning"
            : "good",
    });
  if (swell != null)
    evidence.push({
      label: "Swell",
      labelHi: "लहर (स्वेल)",
      value: `${swell} m (model)`,
      tone: swell >= p.maxSwellHeightM ? "danger" : swell >= 0.7 * p.maxSwellHeightM ? "warning" : "good",
    });
  for (const px of proximities.slice(0, 2)) {
    evidence.push({
      label: `Cyclone ${px.cyclone.name}`,
      labelHi: `चक्रवात ${px.cyclone.name}`,
      value: `${px.distanceKm} km ${px.bearing}${px.positionKind === "forecast" ? " (forecast pos.)" : ""} — ${px.cyclone.demo ? "demo scenario" : "IMD"}`,
      tone: px.cyclone.demo ? "warning" : px.insideOfficialPolygon ? "danger" : px.distanceKm <= 120 ? "warning" : "neutral",
    });
  }
  if (cyclones.length === 0) {
    const imdUnavailable = context.sourceMeta.some(
      (m) => m.source === "IMD" && m.status === "unavailable"
    );
    evidence.push({
      label: "Official cyclone data",
      labelHi: "आधिकारिक चक्रवात डेटा",
      value: imdUnavailable ? "Unavailable (IMD not configured)" : "None reported",
      tone: imdUnavailable ? "neutral" : "good",
    });
  }
  if (activeOfficial.length > 0) {
    for (const { w } of activeOfficial.slice(0, 3)) {
      evidence.push({
        label: w.demo ? "Demo advisory" : `IMD ${w.kind} warning`,
        labelHi: w.demo ? "डेमो सलाह" : `IMD ${w.kind} चेतावनी`,
        value: w.title,
        tone: w.demo ? "warning" : w.severity === "warning" ? "danger" : "warning",
      });
    }
  }
  if (boundaryDistKm != null)
    evidence.push({
      label: "Offshore boundary",
      labelHi: "अपतट सीमा",
      value: beyondBnd ? "Beyond boundary (approx.)" : `${boundaryDistKm} km inside (approx.)`,
      tone: beyondBnd ? "warning" : "neutral",
    });
  if (context.pfz && context.pfz.length > 0) {
    const pfzDemo = context.pfz.some((a) => a.demo);
    evidence.push({
      label: "PFZ advisories",
      labelHi: "PFZ सलाह",
      value: pfzDemo
        ? `${context.pfz.length} active (DEMO — simulated)`
        : `${context.pfz.length} active (INCOIS PFZ)`,
      tone: "neutral",
    });
  }

  /* ---------------- deterministic rules (worst-first) ---------------- */
  let level: RiskLevel;

  if (dataQuality === "INSUFFICIENT") {
    level = "UNKNOWN";
    reasons.push(
      reason(
        "insufficient_data",
        "Insufficient marine data for a reliable safety assessment.",
        "विश्वसनीय सुरक्षा आकलन के लिए पर्याप्त समुद्री डेटा नहीं है।"
      )
    );
  } else if (cyStatus === "polygon") {
    level = "CRITICAL";
    reasons.push(
      reason(
        "cyclone_polygon",
        "Location intersects an official cyclone warning zone (IMD).",
        "स्थान आधिकारिक चक्रवात चेतावनी क्षेत्र (IMD) में आता है।"
      )
    );
  } else if (severeOfficial.length > 0) {
    level = "CRITICAL";
    reasons.push(
      reason(
        "official_warning",
        `Official IMD warning active: ${severeOfficial[0].w.title}`,
        `आधिकारिक IMD चेतावनी सक्रिय: ${severeOfficial[0].w.title}`
      )
    );
  } else if (cyStatus === "critical") {
    level = "HIGH";
    reasons.push(
      reason(
        "cyclone_near",
        proximities[0].cyclone.demo
          ? `Demo scenario: cyclone ${proximities[0].cyclone.name} is ${proximities[0].distanceKm} km ${proximities[0].bearing} away (simulated, not an official IMD track).`
          : `Cyclone ${proximities[0].cyclone.name} is ${proximities[0].distanceKm} km ${proximities[0].bearing} away (IMD track).`,
        proximities[0].cyclone.demo
          ? `डेमो परिदृश्य: चक्रवात ${proximities[0].cyclone.name} ${proximities[0].distanceKm} किमी ${proximities[0].bearing} दूर है (अनुकरणित, आधिकारिक IMD ट्रैक नहीं)।`
          : `चक्रवात ${proximities[0].cyclone.name} ${proximities[0].distanceKm} किमी ${proximities[0].bearing} दूर है (IMD ट्रैक)।`
      )
    );
  } else if (
    (wave != null && wave >= p.maxWaveHeightM) ||
    (wind != null && wind >= p.maxWindSpeedMps) ||
    (gust != null && gust >= p.maxGustSpeedMps) ||
    (swell != null && swell >= p.maxSwellHeightM)
  ) {
    level = "HIGH";
    if (wave != null && wave >= p.maxWaveHeightM)
      reasons.push(
        reason(
          "wave_over_policy",
          `Wave height ${wave} m exceeds the vessel profile limit ${p.maxWaveHeightM} m (prototype policy).`,
          `लहर ${wave} मी प्रोफ़ाइल सीमा ${p.maxWaveHeightM} मी से अधिक है (प्रोटोटाइप नीति)।`
        )
      );
    if (wind != null && wind >= p.maxWindSpeedMps)
      reasons.push(
        reason(
          "wind_over_policy",
          `Wind ${round(wind * 3.6, 0)} km/h exceeds the vessel profile limit ${round(p.maxWindSpeedMps * 3.6, 0)} km/h (prototype policy).`,
          `हवा ${round(wind * 3.6, 0)} किमी/घं प्रोफ़ाइल सीमा ${round(p.maxWindSpeedMps * 3.6, 0)} किमी/घं से अधिक है (प्रोटोटाइप नीति)।`
        )
      );
    if (gust != null && gust >= p.maxGustSpeedMps)
      reasons.push(
        reason(
          "gust_over_policy",
          `Gusts ${round(gust * 3.6, 0)} km/h exceed the vessel profile limit (prototype policy).`,
          `झोंके ${round(gust * 3.6, 0)} किमी/घं प्रोफ़ाइल सीमा से अधिक हैं (प्रोटोटाइप नीति)।`
        )
      );
    if (swell != null && swell >= p.maxSwellHeightM)
      reasons.push(
        reason(
          "swell_over_policy",
          `Swell ${swell} m exceeds the vessel profile limit (prototype policy).`,
          `स्वेल ${swell} मी प्रोफ़ाइल सीमा से अधिक है (प्रोटोटाइप नीति)।`
        )
      );
  } else if (cyStatus === "advisory") {
    level = "MODERATE";
    reasons.push(
      reason(
        "cyclone_advisory",
        proximities[0].cyclone.demo
          ? `Demo scenario: cyclone ${proximities[0].cyclone.name} within the ${p.cycloneAdvisoryDistanceKm} km advisory range (simulated).`
          : `Cyclone ${proximities[0].cyclone.name} within ${p.cycloneAdvisoryDistanceKm} km advisory range (prototype policy).`,
        proximities[0].cyclone.demo
          ? `डेमो परिदृश्य: चक्रवात ${proximities[0].cyclone.name} ${p.cycloneAdvisoryDistanceKm} किमी सलाह सीमा में है (अनुकरणित)।`
          : `चक्रवात ${proximities[0].cyclone.name} ${p.cycloneAdvisoryDistanceKm} किमी सलाह सीमा में है (प्रोटोटाइप नीति)।`
      )
    );
  } else if (
    (wave != null && wave >= 0.7 * p.maxWaveHeightM) ||
    (wind != null && wind >= 0.7 * p.maxWindSpeedMps) ||
    beyondBnd ||
    dataQuality === "STALE"
  ) {
    level = "MODERATE";
    if (wave != null && wave >= 0.7 * p.maxWaveHeightM)
      reasons.push(
        reason(
          "wave_near_policy",
          `Wave height ${wave} m is close to the vessel profile limit (prototype policy).`,
          `लहर ${wave} मी प्रोफ़ाइल सीमा के निकट है (प्रोटोटाइप नीति)।`
        )
      );
    if (wind != null && wind >= 0.7 * p.maxWindSpeedMps)
      reasons.push(
        reason(
          "wind_near_policy",
          `Wind ${round(wind * 3.6, 0)} km/h is close to the vessel profile limit (prototype policy).`,
          `हवा ${round(wind * 3.6, 0)} किमी/घं प्रोफ़ाइल सीमा के निकट है (प्रोटोटाइप नीति)।`
        )
      );
    if (beyondBnd)
      reasons.push(
        reason(
          "beyond_boundary",
          "Point lies beyond the prototype approximate offshore boundary.",
          "बिंदु प्रोटोटाइप अपतट सीमा के पार है।"
        )
      );
    if (dataQuality === "STALE")
      reasons.push(
        reason(
          "stale_data",
          "Marine forecast is stale; recommendation confidence is limited.",
          "समुद्री पूर्वानुमान पुराना है; सिफ़ारिश का विश्वास सीमित है।"
        )
      );
  } else if (hasOcean && hasWind) {
    level = "LOW";
    reasons.push(
      reason(
        "within_policy",
        "All measured variables are within the vessel profile limits (prototype policy).",
        "सभी मापे गए मान प्रोफ़ाइल सीमाओं के भीतर हैं (प्रोटोटाइप नीति)।"
      )
    );
  } else {
    /* some data but not enough for a confident LOW */
    level = "UNKNOWN";
    reasons.push(
      reason(
        "partial_data",
        "Some variables are missing; a confident LOW assessment is not possible.",
        "कुछ मान अनुपस्थित हैं; विश्वसनीय कम-जोखिम आकलन संभव नहीं।"
      )
    );
  }

  /* stale ocean data caps a LOW conclusion (§22) */
  if (level === "LOW" && (oceanStale || weatherStale)) {
    level = "MODERATE";
    reasons.push(
      reason(
        "stale_cap",
        "Data is stale — risk level raised to MODERATE as a precaution.",
        "डेटा पुराना है — सावधानी के तौर पर जोखिम मध्यम किया गया।"
      )
    );
  }

  /* demo advisories also cap a LOW conclusion (never call a simulated
     scenario "low risk" when official feeds are disconnected) */
  if (level === "LOW" && demoOfficial.length > 0) {
    level = "MODERATE";
    reasons.push(
      reason(
        "demo_advisory_cap",
        "A simulated demo advisory is active (official IMD feed not connected) — risk shown as MODERATE.",
        "एक अनुकरणित डेमो सलाह सक्रिय है (आधिकारिक IMD फ़ीड कनेक्ट नहीं) — जोखिम मध्यम दिखाया गया है।"
      )
    );
  }

  /* monitor point distance for logging/UX */
  if (input.monitorPoint) {
    const d = distanceKm(context.location, input.monitorPoint);
    void round(d, 1);
  }

  return {
    level,
    reasons,
    evidence,
    blocked: level === "CRITICAL",
    dataQuality,
  };
}
