/**
 * Geospatial engine (STEP 7) — pure functions on lat/lon.
 * Shared by the risk engine, cyclone checks, PFZ lookup and the A* route.
 *
 * Geometry convention:
 *  - Point helpers take (lat, lng).
 *  - Polygon rings passed to pointInPolygon/intersectsHazard are [lat, lng] pairs.
 *  - GeoJSON polygons ([lng, lat] per spec) must be converted with geojsonRingToLatLng first.
 */

export const EARTH_RADIUS_KM = 6371;

const toRad = (deg: number) => (deg * Math.PI) / 180;
const toDeg = (rad: number) => (rad * 180) / Math.PI;

export interface LatLon {
  lat: number;
  lon: number;
}

/** Great-circle distance in km (Haversine). */
export function distanceKm(a: LatLon, b: LatLon): number {
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Initial bearing from a → b, degrees 0..360 (0 = north). */
export function bearingBetween(a: LatLon, b: LatLon): number {
  const φ1 = toRad(a.lat);
  const φ2 = toRad(b.lat);
  const Δλ = toRad(b.lon - a.lon);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

export const COMPASS_16 = [
  "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW",
] as const;

export function compass16(deg: number): string {
  return COMPASS_16[Math.round((((deg % 360) + 360) % 360) / 22.5) % 16];
}

/**
 * Ray-casting point-in-polygon. Ring is [lat, lng] pairs (convert GeoJSON
 * rings with geojsonRingToLatLng before calling).
 */
export function pointInPolygon(lat: number, lng: number, ring: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [latI, lngI] = ring[i];
    const [latJ, lngJ] = ring[j];
    const intersects =
      lngI > lng !== lngJ > lng &&
      lat < ((latJ - latI) * (lng - lngI)) / (lngJ - lngI) + latI;
    if (intersects) inside = !inside;
  }
  return inside;
}

/** Convert a GeoJSON [lng, lat] ring to the [lat, lng] ring used here. */
export function geojsonRingToLatLng(ring: [number, number][]): [number, number][] {
  return ring.map(([lng, lat]) => [lat, lng] as [number, number]);
}

export interface HazardGeometry {
  /** polygon rings in [lat, lng] form; checked with point-in-polygon */
  polygonRings?: [number, number][][];
  /** circle hazard (center + radius km) */
  center?: LatLon;
  radiusKm?: number;
}

/**
 * Does the point intersect a hazard? Polygon intersection takes priority;
 * circle distance check otherwise. Distance to the hazard edge is returned
 * when a circle is used (0 when inside).
 */
export function intersectsHazard(
  point: LatLon,
  hazard: HazardGeometry
): { hit: boolean; distanceKm: number } {
  if (hazard.polygonRings?.length) {
    const hit = hazard.polygonRings.some((ring) => pointInPolygon(point.lat, point.lon, ring));
    return { hit, distanceKm: hit ? 0 : distanceToPolygonKm(point, hazard.polygonRings[0]) };
  }
  if (hazard.center && hazard.radiusKm != null) {
    const d = distanceKm(point, hazard.center);
    return { hit: d <= hazard.radiusKm, distanceKm: d - hazard.radiusKm };
  }
  return { hit: false, distanceKm: Infinity };
}

/** Approximate distance (km) from a point to the nearest edge of a ring. */
export function distanceToPolygonKm(point: LatLon, ring: [number, number][]): number {
  // For regional extents, equirectangular projection error is acceptable.
  const lat0 = point.lat;
  const kx = 111.32 * Math.cos(toRad(lat0));
  const ky = 110.574;
  const px = point.lon * kx;
  const py = point.lat * ky;
  let min = Infinity;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const ax = ring[j][1] * kx;
    const ay = ring[j][0] * ky;
    const bx = ring[i][1] * kx;
    const by = ring[i][0] * ky;
    const dx = bx - ax;
    const dy = by - ay;
    const len2 = dx * dx + dy * dy || 1e-9;
    const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
    const cx = ax + t * dx;
    const cy = ay + t * dy;
    const d = Math.hypot(px - cx, py - cy);
    if (d < min) min = d;
  }
  return min;
}

/**
 * Nearest PFZ advisory by geodesic distance from the point.
 * Distance is measured to the polygon edge when geometry exists,
 * otherwise to the advisory coordinate.
 */
export function nearestPFZ<T extends { latitude: number; longitude: number; geometry?: unknown }>(
  point: LatLon,
  advisories: T[]
): { advisory: T; distanceKm: number; bearing: string } | null {
  let best: { advisory: T; distanceKm: number; bearing: string } | null = null;
  for (const adv of advisories) {
    const geom = adv.geometry as { coordinates?: [number, number][][] } | undefined;
    let d: number;
    let b: number;
    if (geom?.coordinates?.[0]) {
      const ring = geojsonRingToLatLng(geom.coordinates[0]);
      const c = ringCentroid(ring);
      d = distanceToPolygonKm(point, ring);
      b = bearingBetween(point, c);
    } else {
      const target = { lat: adv.latitude, lon: adv.longitude };
      d = distanceKm(point, target);
      b = bearingBetween(point, target);
    }
    if (!best || d < best.distanceKm) {
      best = { advisory: adv, distanceKm: Math.round(d * 10) / 10, bearing: compass16(b) };
    }
  }
  return best;
}

export function ringCentroid(ring: [number, number][]): LatLon {
  let lat = 0;
  let lon = 0;
  for (const [la, lo] of ring) {
    lat += la;
    lon += lo;
  }
  return { lat: lat / ring.length, lon: lon / ring.length };
}

/**
 * Seaward-side check against a prototype offshore boundary polyline:
 * is the point on the opposite side of the nearest segment from `reference`
 * (the shore-side monitoring center)?
 */
export function beyondBoundary(
  point: LatLon,
  boundary: [number, number][],
  reference: LatLon
): { beyond: boolean; distanceKm: number } {
  const lat0 = point.lat;
  const kx = 111.32 * Math.cos(toRad(lat0));
  const ky = 110.574;
  const px = point.lon * kx;
  const py = point.lat * ky;
  const rx = reference.lon * kx;
  const ry = reference.lat * ky;
  let minDist = Infinity;
  let sidePoint = 0;
  let sideRef = 0;
  for (let i = 0; i < boundary.length - 1; i++) {
    const ax = boundary[i][1] * kx;
    const ay = boundary[i][0] * ky;
    const bx = boundary[i + 1][1] * kx;
    const by = boundary[i + 1][0] * ky;
    const dx = bx - ax;
    const dy = by - ay;
    const len2 = dx * dx + dy * dy || 1e-9;
    const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
    const cx = ax + t * dx;
    const cy = ay + t * dy;
    const d = Math.hypot(px - cx, py - cy);
    if (d < minDist) {
      minDist = d;
      sidePoint = Math.sign(dx * (py - ay) - dy * (px - ax)) || 0;
      sideRef = Math.sign(dx * (ry - ay) - dy * (rx - ax)) || 0;
    }
  }
  const beyond =
    sidePoint !== 0 && sideRef !== 0 && sidePoint !== sideRef && minDist < 80;
  return { beyond, distanceKm: Math.round(minDist) };
}
