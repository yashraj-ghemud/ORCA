/**
 * Cyclone calculations (STEP 8 + §12).
 * Uses official IMD track data when available. Distinguishes:
 *   - current cyclone center proximity (geodesic)
 *   - forecast track proximity at the target time
 *   - official warning polygon intersection
 *   - advisory status
 * No hardcoded universal radius: when official geometry is absent the
 * vessel profile's advisory distance (prototype policy) is used and flagged.
 */

import type { CycloneData } from "../marine/types";
import { bearingBetween, compass16, distanceKm, geojsonRingToLatLng, pointInPolygon } from "./geospatial";

export interface CycloneProximity {
  cyclone: CycloneData;
  /** relevant position used (forecast point at target time, else current center) */
  position: { lat: number; lon: number };
  positionTime?: string;
  positionKind: "current" | "forecast" | "none";
  distanceKm: number;
  bearing: string;
  /** inside an official warning polygon? */
  insideOfficialPolygon: boolean;
  /** within the profile's advisory distance (prototype policy)? */
  withinAdvisoryDistance: boolean;
  /** effective influence radius used, if any */
  influenceRadiusKm: number | null;
  /** source of the radius: official geometry vs profile estimate */
  radiusSource: "official_polygon" | "profile_estimate" | "none";
}

export function evaluateCycloneProximity(
  point: { lat: number; lon: number },
  cyclones: CycloneData[],
  targetTime: string,
  advisoryDistanceKm: number
): CycloneProximity[] {
  const t = new Date(targetTime).getTime();
  return cyclones
    .map((cy) => {
      /* 1. nearest / most relevant position for the target time */
      let pos = cy.position;
      let posTime = cy.observedAt;
      let kind: CycloneProximity["positionKind"] = "current";
      if (cy.track?.length && Number.isFinite(t)) {
        let best: { lat: number; lon: number; time: string; kind?: string } | null = null;
        let bestDiff = Infinity;
        for (const p of cy.track) {
          const pt = new Date(p.time).getTime();
          if (!Number.isFinite(pt)) continue;
          const diff = Math.abs(pt - t);
          if (diff < bestDiff) {
            bestDiff = diff;
            best = p;
          }
        }
        if (best) {
          pos = { lat: best.lat, lon: best.lon };
          posTime = best.time;
          kind = new Date(best.time).getTime() > Date.now() ? "forecast" : "current";
        }
      }

      /* 2. geodesic distance + bearing */
      const d = distanceKm(point, pos);
      const bearing = compass16(bearingBetween(point, pos));

      /* 3. official warning polygon intersection (GeoJSON [lng,lat] → [lat,lng]) */
      let insideOfficialPolygon = false;
      if (cy.warningGeometry?.coordinates?.length) {
        insideOfficialPolygon = cy.warningGeometry.coordinates.some((ring) =>
          pointInPolygon(point.lat, point.lon, geojsonRingToLatLng(ring))
        );
      }

      const withinAdvisoryDistance = d <= advisoryDistanceKm;
      const hasOfficialRadius =
        !cy.warningGeometry && typeof cy.influenceRadiusKm === "number" && cy.influenceRadiusKm > 0;
      const radiusSource: CycloneProximity["radiusSource"] = cy.warningGeometry
        ? "official_polygon"
        : hasOfficialRadius
          ? "profile_estimate"
          : "none";

      return {
        cyclone: cy,
        position: pos,
        positionTime: posTime,
        positionKind: kind,
        distanceKm: Math.round(d),
        bearing,
        insideOfficialPolygon,
        withinAdvisoryDistance,
        influenceRadiusKm: hasOfficialRadius ? (cy.influenceRadiusKm as number) : null,
        radiusSource,
      };
    })
    .sort((a, b) => a.distanceKm - b.distanceKm);
}

/** Highest-priority proximity classification for the risk engine. */
export function worstCycloneStatus(list: CycloneProximity[]) {
  const first = list[0];
  if (!first) return null;
  if (first.insideOfficialPolygon) return "polygon" as const;
  if (first.distanceKm <= 120) return "critical" as const;
  if (first.withinAdvisoryDistance) return "advisory" as const;
  return "distant" as const;
}
