/**
 * ORCA canonical marine data model (STEP 1).
 *
 * Every source adapter (IMD / INCOIS / INCOIS PFZ / Open-Meteo) normalizes
 * into these types. All fields are optional unless structurally required —
 * missing values must stay missing; nothing in the pipeline invents data.
 *
 * Units are canonical (§28):
 *   wind/current = m/s · waves = meters · temperature = °C
 *   distance = km · time = ISO 8601 UTC (display converts to IST)
 */

export type MarineSourceId = "IMD" | "INCOIS" | "INCOIS_PFZ" | "OPEN_METEO";

/** UI-facing freshness status for a source result. */
export type SourceStatus = "fresh" | "recent" | "stale" | "unavailable";

export interface SourceMeta {
  source: MarineSourceId;
  /** what the result represents, e.g. "current_weather", "fishermen_warning", "ocean_forecast", "pfz" */
  kind: string;
  retrievedAt: string;
  observedAt?: string;
  validFrom?: string;
  validUntil?: string;
  freshnessSeconds?: number;
  status: SourceStatus;
  endpointOrDataset?: string;
  /** human-readable note, esp. for unavailable / stale states */
  note?: string;
  /** server-side latency of the upstream call, ms */
  latencyMs?: number;
  /** true when this result is locally SIMULATED (source not configured) — must be surfaced in the UI */
  demo?: boolean;
}

export type WarningSeverity = "advisory" | "watch" | "warning" | "unknown";

export type GeoJSONPolygon = {
  type: "Polygon";
  /** GeoJSON standard: rings of [lng, lat] pairs */
  coordinates: [number, number][][];
};

export interface MarineWarning {
  id: string;
  title: string;
  summary?: string;
  severity: WarningSeverity;
  issuedAt?: string;
  validFrom?: string;
  validUntil?: string;
  /** official warning geometry where the source provides one */
  geometry?: GeoJSONPolygon | null;
  source: MarineSourceId;
  /** simulated demo warning (source not configured) — never treated as official */
  demo?: boolean;
}

export interface CycloneTrackPoint {
  time: string;
  lat: number;
  lon: number;
  windSpeedMps?: number;
  category?: string;
  /** observed (past) vs forecast (future) position */
  kind?: "observed" | "forecast";
}

export interface CycloneData {
  id: string;
  name: string;
  category?: string;
  position: { lat: number; lon: number };
  observedAt?: string;
  movement?: { deg?: number; speedKmh?: number; text?: string };
  windSpeedMps?: number;
  pressureHpa?: number;
  track?: CycloneTrackPoint[];
  /** official cone / warning polygon from IMD, when issued */
  warningGeometry?: GeoJSONPolygon | null;
  /**
   * Advisory influence radius — used ONLY when the source gives no official
   * warning geometry, and always labeled as an estimate in the UI.
   */
  influenceRadiusKm?: number;
  source: MarineSourceId;
  advisoryText?: string;
  /** simulated demo cyclone scenario (IMD not configured) */
  demo?: boolean;
}

export interface PFZAdvisory {
  id: string;
  validFrom: string;
  validUntil: string;
  latitude: number;
  longitude: number;
  depth?: number;
  distanceKm?: number;
  bearing?: string;
  geometry?: GeoJSONPolygon;
  sector?: string;
  source: "INCOIS_PFZ";
  /** simulated demo PFZ zone (official advisory not configured) */
  demo?: boolean;
}

export interface MarineWeather {
  windSpeedMps?: number;
  windDirectionDeg?: number;
  gustSpeedMps?: number;
  temperatureC?: number;
  humidityPct?: number;
  visibilityKm?: number;
  pressureHpa?: number;
  precipitationMm?: number;
  /** WMO weather code or source text */
  conditionText?: string;
  conditionCode?: number;
}

export interface MarineOcean {
  waveHeightM?: number;
  waveDirectionDeg?: number;
  wavePeriodS?: number;
  swellHeightM?: number;
  swellDirectionDeg?: number;
  swellPeriodS?: number;
  windWaveHeightM?: number;
  /** INCOIS OSF can supply wind alongside ocean variables */
  windSpeedMps?: number;
  windDirectionDeg?: number;
  currentSpeedMps?: number;
  currentDirectionDeg?: number;
  sstC?: number;
  chlorophyllMgM3?: number;
  seaLevelM?: number;
}

export interface MarineSnapshot {
  location: { lat: number; lon: number; name?: string };
  observedAt?: string;
  forecastFor?: string;
  weather?: MarineWeather;
  ocean?: MarineOcean;
  warnings?: {
    fishermen?: MarineWarning[];
    coastal?: MarineWarning[];
    seaArea?: MarineWarning[];
    cyclone?: CycloneData[];
  };
  pfz?: PFZAdvisory[];
  sourceMeta: SourceMeta[];
}

/** Aggregated context handed to the risk engine and response builder. */
export interface MarineContext extends MarineSnapshot {
  targetTime: string;
  /** prototype approximate offshore boundary (static geospatial data) */
  boundary?: { points: [number, number][]; label: string };
}

/* ------------------------------------------------------------------ */
/* Risk                                                                */
/* ------------------------------------------------------------------ */

export type RiskLevel = "LOW" | "MODERATE" | "HIGH" | "CRITICAL" | "UNKNOWN";
export type DataQuality = "GOOD" | "LIMITED" | "STALE" | "INSUFFICIENT";

export interface RiskReason {
  code: string;
  en: string;
  hi: string;
}

export interface RiskEvidenceItem {
  label: string;
  labelHi: string;
  value: string;
  tone?: "danger" | "warning" | "good" | "neutral";
}

export interface RiskAssessment {
  level: RiskLevel;
  reasons: RiskReason[];
  evidence: RiskEvidenceItem[];
  blocked: boolean;
  dataQuality: DataQuality;
}

/**
 * Prototype safety policy thresholds — NOT yet validated by marine-domain
 * experts. Presets live in services/risk/profiles.ts.
 */
export interface VesselSafetyProfile {
  id: string;
  label: string;
  labelHi: string;
  maxWaveHeightM: number;
  maxWindSpeedMps: number;
  maxGustSpeedMps: number;
  maxSwellHeightM: number;
  /** cyclone center distance below which risk escalates (prototype policy) */
  cycloneAdvisoryDistanceKm: number;
  cruiseSpeedKmh: number;
}

/* ------------------------------------------------------------------ */
/* Route                                                               */
/* ------------------------------------------------------------------ */

export interface RouteResult {
  points: [number, number][];
  distanceKm: number;
  estimatedTravelTimeHours?: number;
  minimumHazardClearanceKm?: number;
  status: "FOUND" | "NO_SAFE_PATH";
  explanation: string[];
  explanationHi: string[];
}

/** Per-cell sampled risk used for the dynamic "Marine risk" map layer. */
export interface RiskCell {
  lat: number;
  lng: number;
  radiusKm: number;
  level: RiskLevel;
}

export interface RequestLog {
  requestId: string;
  queryType: string;
  location: { lat: number; lon: number; name?: string };
  sourceStatuses: { source: string; kind: string; status: SourceStatus; latencyMs?: number }[];
  riskLevel?: RiskLevel;
  dataQuality?: DataQuality;
  totalLatencyMs: number;
}
