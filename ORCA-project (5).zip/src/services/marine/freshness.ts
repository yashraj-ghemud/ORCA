/**
 * Freshness / data-quality layer (STEP 4 + §6).
 * Decides fresh / recent / stale from the source timestamps — the UI renders
 * exactly what this layer reports and nothing else.
 */

import type { SourceStatus } from "./types";

export interface FreshnessTtls {
  /** seconds within which data is considered fresh */
  freshS: number;
  /** seconds within which data is recent; beyond this it is stale */
  recentS: number;
}

/** TTL policy per source kind. Official warnings go stale fastest. */
export const FRESHNESS_TTL: Record<string, FreshnessTtls> = {
  imd_weather: { freshS: 60 * 60, recentS: 3 * 3600 },
  imd_warnings: { freshS: 60 * 60, recentS: 3 * 3600 },
  imd_cyclone: { freshS: 30 * 60, recentS: 90 * 60 },
  incois_ocean: { freshS: 3 * 3600, recentS: 12 * 3600 },
  incois_pfz: { freshS: 12 * 3600, recentS: 30 * 3600 },
  openmeteo_marine: { freshS: 2 * 3600, recentS: 8 * 3600 },
  openmeteo_weather: { freshS: 2 * 3600, recentS: 8 * 3600 },
};

export type FreshnessLevel = "FRESH" | "RECENT" | "STALE" | "UNAVAILABLE";

/**
 * getFreshnessStatus — compares the source's data timestamp (observed or
 * issued) against now. `validUntil` can override: past validity = stale.
 */
export function getFreshnessStatus(opts: {
  retrievedAt?: string | null;
  observedAt?: string | null;
  validUntil?: string | null;
  ttlKey?: string;
  now?: Date;
}): { status: SourceStatus; freshnessSeconds?: number; level: FreshnessLevel } {
  const now = opts.now ?? new Date();
  const ttl = FRESHNESS_TTL[opts.ttlKey ?? ""] ?? { freshS: 3 * 3600, recentS: 12 * 3600 };

  if (opts.validUntil) {
    const vu = new Date(opts.validUntil).getTime();
    if (Number.isFinite(vu) && vu < now.getTime()) {
      return { status: "stale", level: "STALE" };
    }
  }

  const base = opts.observedAt ?? opts.retrievedAt;
  if (!base) return { status: "unavailable", level: "UNAVAILABLE" };

  const t = new Date(base).getTime();
  if (!Number.isFinite(t)) return { status: "unavailable", level: "UNAVAILABLE" };

  const ageS = Math.max(0, Math.round((now.getTime() - t) / 1000));
  if (ageS <= ttl.freshS) return { status: "fresh", freshnessSeconds: ageS, level: "FRESH" };
  if (ageS <= ttl.recentS) return { status: "recent", freshnessSeconds: ageS, level: "RECENT" };
  return { status: "stale", freshnessSeconds: ageS, level: "STALE" };
}

/** "updated 4 min ago" style humanized age (client displays IST; this is a helper). */
export function humanizeAge(seconds: number | undefined): string | null {
  if (seconds == null) return null;
  if (seconds < 90) return "just now";
  const min = Math.round(seconds / 60);
  if (min < 60) return `${min} min ago`;
  const h = Math.floor(min / 60);
  const rem = min % 60;
  if (h < 24) return rem ? `${h} h ${rem} min ago` : `${h} h ago`;
  const d = Math.floor(h / 24);
  return `${d} d ago`;
}

/** Format an ISO timestamp in IST for display, e.g. "04 Sept, 11:30 IST". */
export function formatIst(iso: string | undefined | null): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return null;
  const formatted = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    day: "2-digit",
    month: "short",
    hour12: false,
  }).format(d);
  return `${formatted.replace(",", ",")} IST`;
}
