/**
 * In-memory TTL cache (§26). Server-side singleton; survives dev HMR via
 * globalThis. Redis can replace `store` later without changing call sites.
 *
 * Cache keys embed: source · kind · lat/lon bucket · time bucket — so
 * different locations/times never collide, and official warnings get short
 * TTLs to respect their update semantics.
 */

type Entry = { value: unknown; expiresAt: number };

const g = globalThis as unknown as { __orcaMarineCache?: Map<string, Entry> };
const store: Map<string, Entry> = (g.__orcaMarineCache ??= new Map());

function prune() {
  const now = Date.now();
  if (store.size < 256) return;
  for (const [k, v] of store) {
    if (v.expiresAt < now) store.delete(k);
  }
}

export function bucketCoord(lat: number, lon: number, deg: number): string {
  const b = (v: number) => Math.round(v / deg) * deg;
  return `${b(lat).toFixed(2)},${b(lon).toFixed(2)}`;
}

export async function cached<T>(opts: {
  key: string;
  ttlS: number;
  fetch: () => Promise<T>;
  /** optional predicate — when provided, only matching results are cached
   *  (used to avoid negative-caching transient source failures) */
  cacheIf?: (value: T) => boolean;
}): Promise<T> {
  const now = Date.now();
  const hit = store.get(opts.key);
  if (hit && hit.expiresAt > now) return hit.value as T;
  const value = await opts.fetch();
  if (!opts.cacheIf || opts.cacheIf(value)) {
    store.set(opts.key, { value, expiresAt: now + opts.ttlS * 1000 });
  }
  prune();
  return value;
}

export function cacheGet<T>(key: string): T | undefined {
  const hit = store.get(key);
  if (hit && hit.expiresAt > Date.now()) return hit.value as T;
  return undefined;
}

export function cacheSet(key: string, value: unknown, ttlS: number) {
  store.set(key, { value, expiresAt: Date.now() + ttlS * 1000 });
}

/** test helper */
export function cacheClear() {
  store.clear();
}

export function cacheStats() {
  return { size: store.size };
}

/* Standard TTLs per data kind (seconds) */
export const CACHE_TTL = {
  imd_weather: 15 * 60,
  imd_warnings: 10 * 60,
  imd_cyclone: 10 * 60,
  incois_ocean: 60 * 60,
  incois_pfz: 3 * 3600,
  openmeteo_marine: 20 * 60,
  openmeteo_weather: 15 * 60,
  route_cells: 20 * 60,
} as const;
