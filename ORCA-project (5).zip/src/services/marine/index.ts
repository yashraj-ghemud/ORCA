/**
 * Marine context aggregator (STEP 5 + §8) — getMarineContext(location, targetTime).
 *
 * Runs independent sources in parallel (Promise.all), merges results under
 * the source-priority model (§SOURCE PRIORITY):
 *   - official warnings: IMD only (never overwritten by Open-Meteo)
 *   - ocean state: INCOIS when available, else Open-Meteo (labeled model)
 *   - PFZ: INCOIS PFZ only (explicit unavailable state otherwise)
 *
 * Missing values stay missing. No source failure ever throws — it degrades
 * into an explicit "unavailable" SourceMeta the UI can display.
 */

import type {
  MarineContext,
  MarineOcean,
  MarineWarning,
  MarineWeather,
  PFZAdvisory,
  SourceMeta,
} from "./types";
import { getOpenMeteoBundle, isOmFailure, pickHourly } from "./openMeteo";
import { getIncoisOceanState, incoisConfigured } from "./incois";
import { getPFZAdvisories, pfzConfigured } from "./pfz";
import {
  getCycloneTrack,
  getFishermenWarning,
  getCoastalBulletin,
  getSeaAreaBulletin,
  imdConfigured,
} from "./imd";
import { round } from "./normalizer";
import {
  demoCoastalBulletin,
  demoCyclone,
  demoFishermenWarning,
  demoPFZAdvisories,
} from "./demo-fallback";

const _startedGuard = 0; void _startedGuard;

export interface BoundarySpec {
  points: [number, number][];
  label: string;
}

/**
 * When an official source is not configured, substitute a clearly-labeled
 * SIMULATED demo object (user request) so the UI stays rich. Demo objects are
 * flagged `demo: true` end-to-end — the risk engine caps them and every UI
 * surface labels them. Set DEMO_FALLBACK=off to disable.
 */
function demoFallbackEnabled(): boolean {
  return process.env.DEMO_FALLBACK !== "off";
}

export async function getMarineContext(
  location: { lat: number; lon: number; name?: string },
  targetTime: string,
  boundary?: BoundarySpec
): Promise<MarineContext> {
  const [om, incois, pfz, fishermen, coastal, seaArea, cycloneTrack] = await Promise.all([
    getOpenMeteoBundle(location.lat, location.lon),
    incoisConfigured()
      ? getIncoisOceanState(location.lat, location.lon, targetTime)
      : Promise.resolve(null),
    pfzConfigured()
      ? getPFZAdvisories({ lat: location.lat, lon: location.lon }, targetTime)
      : Promise.resolve(null),
    imdConfigured() ? getFishermenWarning() : Promise.resolve(null),
    imdConfigured() ? getCoastalBulletin() : Promise.resolve(null),
    imdConfigured() ? getSeaAreaBulletin() : Promise.resolve(null),
    imdConfigured() ? getCycloneTrack() : Promise.resolve(null),
  ]);

  const sourceMeta: SourceMeta[] = [];

  /* ---------- ocean: INCOIS (authoritative) > Open-Meteo (model) ---------- */
  let ocean: MarineOcean | undefined;
  let oceanObservedAt: string | undefined;

  if (incois && incois.ok && incois.ocean) {
    ocean = incois.ocean;
    oceanObservedAt = incois.meta.observedAt;
    sourceMeta.push(incois.meta);
  } else if (incois) {
    sourceMeta.push(incois.meta);
  }

  if (om.marine.ok) {
    /* Open-Meteo fills any gaps INCOIS leaves, but never hides its own meta */
    const m = om.marine;
    sourceMeta.push(m.meta);
    ocean = {
      ...m.ocean,
      ...(ocean ?? {}),
      /* keep INCOIS values where present, Open-Meteo otherwise */
      ...(ocean
        ? Object.fromEntries(
            Object.entries(ocean).filter(([, v]) => v != null)
          )
        : {}),
    } as MarineOcean;
    oceanObservedAt = oceanObservedAt ?? m.meta.observedAt;
  } else {
    sourceMeta.push(om.marine.meta);
  }

  /* ---------- weather: Open-Meteo model (+ IMD summary where configured) ---------- */
  let weather: MarineWeather | undefined;
  if (om.weather.ok) {
    weather = om.weather.weather;
    sourceMeta.push(om.weather.meta);
  } else {
    sourceMeta.push(om.weather.meta);
  }

  /* ---------- warnings: IMD only (demo-substituted when unconfigured) ---------- */
  const demo = demoFallbackEnabled();
  let fishermenW: MarineWarning[] = fishermen?.ok && fishermen.data ? fishermen.data : [];
  let coastalW: MarineWarning[] = coastal?.ok && coastal.data ? coastal.data : [];
  const seaAreaW: MarineWarning[] = seaArea?.ok && seaArea.data ? seaArea.data : [];
  for (const w of [fishermen, coastal, seaArea]) {
    if (w) sourceMeta.push(w.meta);
  }

  let cyclones = cycloneTrack?.ok && cycloneTrack.data ? cycloneTrack.data : [];
  if (cycloneTrack) sourceMeta.push(cycloneTrack.meta);

  if (demo) {
    if (!imdConfigured()) {
      const fw = demoFishermenWarning(location);
      const cb = demoCoastalBulletin(location);
      fishermenW = [...fishermenW, ...fw.warnings];
      coastalW = [...coastalW, ...cb.warnings];
      sourceMeta.push(fw.meta, cb.meta);
      if (!cycloneTrack) {
        const dc = demoCyclone(location);
        cyclones = [...cyclones, dc.cyclone];
        sourceMeta.push(dc.meta);
      }
    }
  }

  /* ---------- PFZ: INCOIS only (demo-substituted when unconfigured) ---------- */
  let pfzAdvisories: PFZAdvisory[] | undefined;
  if (pfz) {
    pfzAdvisories = pfz.ok ? (pfz.advisories ?? []) : undefined;
    sourceMeta.push(pfz.meta);
  } else if (demo) {
    const dp = demoPFZAdvisories(location);
    pfzAdvisories = dp.advisories;
    sourceMeta.push(dp.meta);
  } else {
    sourceMeta.push({
      source: "INCOIS_PFZ",
      kind: "pfz",
      retrievedAt: new Date().toISOString(),
      status: "unavailable",
      note: "PFZ source not configured",
    });
  }

  /* ---------- target-time overlay: forecast values at targetTime ---------- */
  let forecastFor: string | undefined;
  const target = new Date(targetTime);
  const now = new Date();
  if (Number.isFinite(target.getTime()) && target.getTime() - now.getTime() > 2 * 3600_000) {
    forecastFor = target.toISOString();
    if (om.marine.ok) {
      const wh = pickHourly(om.marine.oceanHourly.time, om.marine.oceanHourly.waveHeightM, targetTime);
      const wd = pickHourly(om.marine.oceanHourly.time, om.marine.oceanHourly.waveDirectionDeg, targetTime);
      const wp = pickHourly(om.marine.oceanHourly.time, om.marine.oceanHourly.wavePeriodS, targetTime);
      if (ocean) {
        if (wh != null) ocean.waveHeightM = round(wh, 2);
        if (wd != null) ocean.waveDirectionDeg = wd ?? undefined;
        if (wp != null) ocean.wavePeriodS = round(wp, 1);
      }
    }
    if (om.weather.ok) {
      const ws = pickHourly(om.weather.weatherHourly.time, om.weather.weatherHourly.windSpeedMps, targetTime);
      const wd = pickHourly(om.weather.weatherHourly.time, om.weather.weatherHourly.windDirectionDeg, targetTime);
      const wg = pickHourly(om.weather.weatherHourly.time, om.weather.weatherHourly.gustMps, targetTime);
      if (weather) {
        if (ws != null) weather.windSpeedMps = ws ?? undefined;
        if (wd != null) weather.windDirectionDeg = wd ?? undefined;
        if (wg != null) weather.gustSpeedMps = wg ?? undefined;
      }
    }
  }

  return {
    location,
    observedAt: oceanObservedAt ?? (om.weather.ok ? om.weather.meta.observedAt : undefined),
    forecastFor,
    weather,
    ocean,
    warnings: {
      fishermen: fishermenW.length ? fishermenW : undefined,
      coastal: coastalW.length ? coastalW : undefined,
      seaArea: seaAreaW.length ? seaAreaW : undefined,
      cyclone: cyclones.length ? cyclones : undefined,
    },
    pfz: pfzAdvisories,
    sourceMeta,
    targetTime,
    boundary,
  };
}

export { isOmFailure };
