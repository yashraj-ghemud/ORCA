/**
 * DEMO fallback generator (user request: "jo data nahi hai wo dummy dal de").
 *
 * When an official source (IMD / INCOIS PFZ) is NOT configured, this module
 * produces a plausible SIMULATED substitute so the map and briefing stay rich
 * — exactly like the original prototype scenario. Every produced object is
 * flagged `demo: true` and every SourceMeta note says SIMULATED, so the UI can
 * (and must) label it. Demo data is NEVER allowed to trigger an official-
 * warning CRITICAL in the risk engine.
 *
 * Deterministic per location + day: same location on the same day yields the
 * same scenario (stable screenshots/tests), varying across locations/days.
 */

import type {
  CycloneData,
  CycloneTrackPoint,
  GeoJSONPolygon,
  MarineWarning,
  PFZAdvisory,
  SourceMeta,
} from "./types";

/* deterministic pseudo-random from a string seed (mulberry32-ish) */
function seeded(seed: string): () => number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return () => {
    h += 0x6d2b79f5;
    let t = h;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const dayKey = () => new Date().toISOString().slice(0, 10);

const DEMO_NOTE = "SIMULATED demo data — official source not configured";
const DEMO_NOTE_HI = "अनुकरणित डेमो डेटा — आधिकारिक स्रोत कॉन्फ़िगर नहीं";

/* ------------------------------------------------------------------ */
/* IMD demo warnings                                                   */
/* ------------------------------------------------------------------ */

export function demoFishermenWarning(loc: { lat: number; lon: number; name?: string }): {
  warnings: MarineWarning[];
  meta: SourceMeta;
} {
  const rnd = seeded(`fish-${loc.lat}-${loc.lon}-${dayKey()}`);
  const strong = rnd() > 0.45;
  const now = new Date();
  const validUntil = new Date(now.getTime() + 24 * 3600_000).toISOString();
  const w: MarineWarning = {
    id: `demo-fw-${loc.lat}-${loc.lon}`,
    title: strong
      ? "Squally weather with wind speed reaching 45–55 km/h likely along the coast (DEMO)"
      : "Wind speed 35–45 km/h with moderate seas expected offshore (DEMO)",
    summary: strong
      ? "Sea condition rough — small vessels advised not to venture far (simulated demo advisory)."
      : "Sea condition moderate — fishing operations allowed near shore with caution (simulated).",
    severity: strong ? "warning" : "advisory",
    issuedAt: new Date(now.getTime() - 40 * 60_000).toISOString(),
    validFrom: now.toISOString(),
    validUntil,
    source: "IMD",
    demo: true,
  };
  return {
    warnings: [w],
    meta: {
      source: "IMD",
      kind: "fishermen_warning",
      retrievedAt: now.toISOString(),
      observedAt: w.issuedAt,
      validUntil,
      status: "fresh",
      note: `${DEMO_NOTE} / ${DEMO_NOTE_HI}`,
      demo: true,
    },
  };
}

export function demoCoastalBulletin(loc: { lat: number; lon: number; name?: string }): {
  warnings: MarineWarning[];
  meta: SourceMeta;
} {
  const now = new Date();
  const w: MarineWarning = {
    id: `demo-cb-${loc.lat}-${loc.lon}`,
    title: "Coastal bulletin: moderate monsoon swell along the shoreline (DEMO)",
    severity: "advisory",
    issuedAt: new Date(now.getTime() - 80 * 60_000).toISOString(),
    source: "IMD",
    demo: true,
  };
  return {
    warnings: [w],
    meta: {
      source: "IMD",
      kind: "coastal_bulletin",
      retrievedAt: now.toISOString(),
      observedAt: w.issuedAt,
      status: "fresh",
      note: DEMO_NOTE,
      demo: true,
    },
  };
}

/* ------------------------------------------------------------------ */
/* Demo cyclone scenario                                               */
/* ------------------------------------------------------------------ */

const CY_NAMES = ["Asna", "Biparjoy", "Tej", "Hamoon", "Michaung", "Remal", "Dana"];
const CY_CATS = [
  "Cyclonic Storm (DEMO)",
  "Severe Cyclonic Storm (DEMO)",
  "Deep Depression (DEMO)",
];

export function demoCyclone(loc: { lat: number; lon: number; name?: string }): {
  cyclone: CycloneData;
  meta: SourceMeta;
} {
  const rnd = seeded(`cy-${loc.lat}-${loc.lon}-${dayKey()}`);
  const name = CY_NAMES[Math.floor(rnd() * CY_NAMES.length)];
  const category = CY_CATS[Math.floor(rnd() * CY_CATS.length)];

  /* system parked 70–130 km offshore, ON THE SEA-SIDE of the location */
  const distKm = 70 + Math.round(rnd() * 60);
  /* India west coast (lon < 77°E) → Arabian Sea: bearing SSW–WNW (210–300°);
     east coast → Bay of Bengal: bearing ENE–SSE (70–150°). Offsets applied
     directly along the bearing so the center always lands over water. */
  const westCoast = loc.lon < 77;
  const brg = ((westCoast ? 210 + rnd() * 90 : 70 + rnd() * 80) * Math.PI) / 180;
  const dLat = (distKm * Math.cos(brg)) / 110.574;
  const dLon = (distKm * Math.sin(brg)) / (111.32 * Math.cos((loc.lat * Math.PI) / 180));
  const center = { lat: +(loc.lat + dLat).toFixed(2), lon: +(loc.lon + dLon).toFixed(2) };

  const now = Date.now();
  const track: CycloneTrackPoint[] = [-12, -6, 0, 6, 12, 18].map((h) => {
    const drift = h * 0.012;
    return {
      time: new Date(now + h * 3600_000).toISOString(),
      lat: +(center.lat + drift * 0.6).toFixed(2),
      lon: +(center.lon - drift).toFixed(2),
      windSpeedMps: 18 + Math.round(rnd() * 12),
      category,
      kind: h <= 0 ? ("observed" as const) : ("forecast" as const),
    };
  });

  const influenceRadiusKm = 45 + Math.round(rnd() * 25);
  const cy: CycloneData = {
    id: `demo-cy-${loc.lat}-${loc.lon}`,
    name: `${name} (DEMO)`,
    category,
    position: center,
    observedAt: new Date(now - 30 * 60_000).toISOString(),
    movement: { deg: 315, speedKmh: 11, text: "Moving NW at 11 km/h (demo scenario)" },
    windSpeedMps: track[2].windSpeedMps,
    track,
    /* no official warningGeometry — demo never claims an official polygon */
    warningGeometry: null,
    influenceRadiusKm,
    source: "IMD",
    advisoryText: "Simulated demo cyclone scenario — IMD feed not connected.",
    demo: true,
  };
  return {
    cyclone: cy,
    meta: {
      source: "IMD",
      kind: "cyclone_track",
      retrievedAt: new Date(now).toISOString(),
      observedAt: cy.observedAt,
      status: "fresh",
      note: DEMO_NOTE,
      demo: true,
    },
  };
}

/* ------------------------------------------------------------------ */
/* Demo PFZ advisories                                                 */
/* ------------------------------------------------------------------ */

function demoRing(lat: number, lon: number, radiusKm: number, rot: number): GeoJSONPolygon {
  const ring: [number, number][] = [];
  const dLat = radiusKm / 110.574;
  const dLon = radiusKm / (111.32 * Math.cos((lat * Math.PI) / 180));
  for (let k = 0; k < 6; k++) {
    const th = rot + (k / 6) * 2 * Math.PI;
    ring.push([
      +(lon + dLon * Math.cos(th) * 1.25).toFixed(3),
      +(lat + dLat * Math.sin(th)).toFixed(3),
    ]);
  }
  ring.push(ring[0]);
  return { type: "Polygon", coordinates: [ring] };
}

export function demoPFZAdvisories(loc: { lat: number; lon: number; name?: string }): {
  advisories: PFZAdvisory[];
  meta: SourceMeta;
} {
  const rnd = seeded(`pfz-${loc.lat}-${loc.lon}-${dayKey()}`);
  const now = Date.now();
  const validFrom = new Date(now - 3 * 3600_000).toISOString();
  const validUntil = new Date(now + 21 * 3600_000).toISOString();

  const zones: PFZAdvisory[] = [0, 1].map((i) => {
    const distKm = 12 + Math.round(rnd() * 22) + i * 9;
    const brgDeg = (100 + rnd() * 160 + i * 130) % 360;
    const brg = (brgDeg * Math.PI) / 180;
    const lat = +(loc.lat + (distKm * Math.sin(brg)) / 110.574).toFixed(2);
    const lon = +(loc.lon + (distKm * Math.cos(brg)) / (111.32 * Math.cos((loc.lat * Math.PI) / 180))).toFixed(2);
    return {
      id: `demo-pfz-${loc.lat}-${loc.lon}-${i}`,
      validFrom,
      validUntil,
      latitude: lat,
      longitude: lon,
      distanceKm: distKm,
      bearing: `${Math.round(brgDeg)}°`,
      geometry: demoRing(lat, lon, 6 + i * 2, rnd() * Math.PI),
      sector: i === 0 ? "Demo zone A" : "Demo zone B",
      source: "INCOIS_PFZ" as const,
      demo: true,
    };
  });

  return {
    advisories: zones,
    meta: {
      source: "INCOIS_PFZ",
      kind: "pfz",
      retrievedAt: new Date(now).toISOString(),
      validFrom,
      validUntil,
      status: "fresh",
      note: `${DEMO_NOTE} — official INCOIS PFZ advisory not configured`,
      demo: true,
    },
  };
}
