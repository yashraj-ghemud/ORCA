/**
 * IMD (India Meteorological Department) adapter — AUTHORITATIVE warnings (§1).
 *
 * ⚠️ ACCESS STATUS (honest disclosure, §38):
 * The official IMD API Management System (https://imdapi.org) requires a
 * registered account + subscription key. It is NOT callable anonymously.
 * No IMD endpoint is fabricated here. This adapter is fully isolated and
 * becomes active as soon as credentials are provided via env:
 *
 *   IMD_API_BASE_URL   e.g. the base URL given in your IMD API subscription
 *   IMD_API_KEY        subscription key
 *   IMD_API_KEY_HEADER header the IMD gateway expects (default: "X-API-KEY")
 *   IMD_PATH_*         optional per-product path overrides — verify against
 *                      the CURRENT official IMD API documentation for your
 *                      subscription plan; defaults below follow the
 *                      published catalogue naming and may need adjustment.
 *
 * Until configured, every function returns status "unavailable" with an
 * explicit note — the UI surfaces this instead of inventing warnings.
 */

import type { CycloneData, MarineWarning, SourceMeta } from "./types";
import { fetchJson, sanitizeUrlForLog } from "./http";
import { cached, CACHE_TTL, bucketCoord } from "./cache";
import { getFreshnessStatus } from "./freshness";
import { knotsToMps, num, round } from "./normalizer";

export const IMD_ENV = {
  baseUrl: process.env.IMD_API_BASE_URL ?? "",
  apiKey: process.env.IMD_API_KEY ?? "",
  keyHeader: process.env.IMD_API_KEY_HEADER ?? "X-API-KEY",
};

const PATHS = {
  currentWeather: process.env.IMD_PATH_CURRENT_WEATHER ?? "/current-weather-data",
  fishermen: process.env.IMD_PATH_FISHERMEN ?? "/fishermen-warning",
  coastal: process.env.IMD_PATH_COASTAL ?? "/coastal-bulletin",
  seaArea: process.env.IMD_PATH_SEA_AREA ?? "/sea-area-bulletin",
  cycloneTrack: process.env.IMD_PATH_CYCLONE_TRACK ?? "/cyclone-track",
  cycloneWind: process.env.IMD_PATH_CYCLONE_WIND ?? "/cyclone-wind-warning",
  cycloneCone: process.env.IMD_PATH_CYCLONE_CONE ?? "/cyclone-cone",
};

export function imdConfigured(): boolean {
  return Boolean(IMD_ENV.baseUrl && IMD_ENV.apiKey);
}

const NOT_CONFIGURED =
  "Official IMD API requires a subscription (imdapi.org). Configure IMD_API_BASE_URL and IMD_API_KEY to enable.";

function unavailableMeta(kind: string, note: string = NOT_CONFIGURED): SourceMeta {
  return {
    source: "IMD",
    kind,
    retrievedAt: new Date().toISOString(),
    status: "unavailable",
    note,
  };
}

interface ImdOutcome<T> {
  ok: boolean;
  data?: T;
  meta: SourceMeta;
}

/** Generic IMD call: timeout, retry, freshness, never throws. */
async function imdCall<T>(
  kind: string,
  path: string,
  ttlS: number,
  validate: (json: unknown) => T | null
): Promise<ImdOutcome<T>> {
  if (!imdConfigured()) return { ok: false, meta: unavailableMeta(kind) };

  const key = `imd:${kind}:${path}`;
  return cached({
    cacheIf: v => v.ok === true,
    key,
    ttlS,
    fetch: async () => {
      const url = `${IMD_ENV.baseUrl.replace(/\/$/, "")}${path}`;
      const res = await fetchJson(url, {
        timeoutMs: 9000,
        retries: 1,
        headers: { [IMD_ENV.keyHeader]: IMD_ENV.apiKey },
      });
      if (!res.ok || res.json == null) {
        return {
          ok: false,
          meta: {
            source: "IMD",
            kind,
            retrievedAt: new Date().toISOString(),
            status: "unavailable",
            note: `IMD request failed: ${res.error ?? res.status}`,
            latencyMs: res.latencyMs,
          },
        };
      }
      const data = validate(res.json);
      if (!data) {
        return {
          ok: false,
          meta: {
            source: "IMD",
            kind,
            retrievedAt: new Date().toISOString(),
            status: "unavailable",
            note: "IMD response did not match the expected schema (validate paths against current IMD docs)",
            latencyMs: res.latencyMs,
          },
        };
      }
      const fr = getFreshnessStatus({ ttlKey: "imd_warnings" });
      return {
        ok: true,
        data,
        meta: {
          source: "IMD",
          kind,
          retrievedAt: new Date().toISOString(),
          status: fr.status,
          freshnessSeconds: fr.freshnessSeconds,
          endpointOrDataset: sanitizeUrlForLog(path),
          latencyMs: res.latencyMs,
        },
      };
    },
  });
}

/* ------------------------------------------------------------------ */
/* Public adapter API                                                   */
/* ------------------------------------------------------------------ */

function asWarnings(json: unknown, source: MarineWarning["source"]): MarineWarning[] | null {
  /* Accept an array or { warnings: [...] } of objects with at least a title/message. */
  const fromObj =
    typeof json === "object" && json !== null
      ? (json as { warnings?: unknown }).warnings
      : undefined;
  const arr: unknown[] = Array.isArray(json) ? json : Array.isArray(fromObj) ? (fromObj as unknown[]) : [];
  const out: MarineWarning[] = [];
  for (const raw of arr) {
    if (typeof raw !== "object" || raw === null) continue;
    const r = raw as Record<string, unknown>;
    const title = (r.title ?? r.headline ?? r.message ?? r.warning) as string | undefined;
    if (!title) continue;
    out.push({
      id: String(r.id ?? `${title.slice(0, 24)}`),
      title: title,
      summary: (r.summary ?? r.description ?? r.outlook) as string | undefined,
      severity: parseSeverity(r.severity ?? r.level ?? r.color_code),
      issuedAt: iso(r.issue_time ?? r.issuedAt ?? r.date),
      validFrom: iso(r.valid_from ?? r.validFrom ?? r.start_time),
      validUntil: iso(r.valid_until ?? r.validUntil ?? r.end_time),
      geometry: null,
      source,
    });
  }
  return out;
}

function parseSeverity(v: unknown): MarineWarning["severity"] {
  const s = String(v ?? "").toLowerCase();
  if (s.includes("warn") || s.includes("red") || s.includes("orange")) return "warning";
  if (s.includes("watch") || s.includes("yellow")) return "watch";
  if (s.includes("advisory")) return "advisory";
  return "unknown";
}

function iso(v: unknown): string | undefined {
  if (typeof v !== "string" || !v) return undefined;
  const t = new Date(v).getTime();
  return Number.isFinite(t) ? new Date(t).toISOString() : undefined;
}

export async function getCurrentWeather(
  lat: number,
  lon: number
): Promise<ImdOutcome<{ summary: string; raw: unknown }>> {
  if (!imdConfigured()) return { ok: false, meta: unavailableMeta("current_weather") };
  return imdCall(
    "current_weather",
    `${PATHS.currentWeather}?lat=${lat}&lon=${lon}`,
    CACHE_TTL.imd_weather,
    (json) => {
      const r = json as {
        weather?: { description?: unknown };
        Observed?: { weather?: unknown };
      };
      const summary =
        (r.weather?.description as string | undefined) ??
        (r.Observed?.weather as string | undefined) ??
        null;
      if (!summary) return null;
      return { summary: String(summary), raw: json };
    }
  );
}

export async function getFishermenWarning(): Promise<ImdOutcome<MarineWarning[]>> {
  return imdCall("fishermen_warning", PATHS.fishermen, CACHE_TTL.imd_warnings, (json) =>
    asWarnings(json, "IMD")
  );
}

export async function getCoastalBulletin(): Promise<ImdOutcome<MarineWarning[]>> {
  return imdCall("coastal_bulletin", PATHS.coastal, CACHE_TTL.imd_warnings, (json) =>
    asWarnings(json, "IMD")
  );
}

export async function getSeaAreaBulletin(): Promise<ImdOutcome<MarineWarning[]>> {
  return imdCall("sea_area_bulletin", PATHS.seaArea, CACHE_TTL.imd_warnings, (json) =>
    asWarnings(json, "IMD")
  );
}

export async function getCycloneTrack(): Promise<ImdOutcome<CycloneData[]>> {
  return imdCall("cyclone_track", PATHS.cycloneTrack, CACHE_TTL.imd_cyclone, (json) => {
    const arr = Array.isArray(json)
      ? json
      : ((json as { cyclones?: unknown[]; data?: unknown[] })?.cyclones ??
        (json as { data?: unknown[] })?.data ??
        []);
    if (!Array.isArray(arr)) return null;
    const out: CycloneData[] = [];
    for (const raw of arr) {
      if (typeof raw !== "object" || raw === null) continue;
      const r = raw as Record<string, unknown>;
      const name = (r.name ?? r.system) as string | undefined;
      const lat = num(r.latitude as number, -90, 90) ?? num(r.lat as number, -90, 90);
      const lon = num(r.longitude as number, -180, 180) ?? num(r.lon as number, -180, 180);
      if (!name || lat == null || lon == null) continue;
      out.push({
        id: String(r.id ?? name),
        name: String(name),
        category: (r.category ?? r.type) as string | undefined,
        position: { lat, lon },
        observedAt: iso(r.observed_at ?? r.time ?? r.date),
        movement: {
          deg: num(r.movement_deg as number),
          speedKmh: round(num(r.movement_speed_kmh as number), 1),
          text: (r.movement ?? r.motion) as string | undefined,
        },
        windSpeedMps: knotsToMps(num(r.max_wind_knots as number)),
        pressureHpa: num(r.pressure_hpa as number),
        track: undefined,
        warningGeometry: null,
        source: "IMD",
        advisoryText: (r.advisory ?? r.advisory_text) as string | undefined,
      });
    }
    return out;
  });
}

export async function getCycloneWindWarning(): Promise<ImdOutcome<MarineWarning[]>> {
  return imdCall("cyclone_wind_warning", PATHS.cycloneWind, CACHE_TTL.imd_warnings, (json) =>
    asWarnings(json, "IMD")
  );
}

export async function getCycloneCone(): Promise<ImdOutcome<{ geometry: unknown } | null>> {
  return imdCall("cyclone_cone", PATHS.cycloneCone, CACHE_TTL.imd_cyclone, (json) => {
    /* expected: GeoJSON-like geometry for the forecast cone — kept opaque here */
    if (typeof json === "object" && json !== null) return { geometry: json };
    return null;
  });
}

/** Bucket helper for location-keyed caching of IMD results. */
export function imdBucket(lat: number, lon: number): string {
  return bucketCoord(lat, lon, 2);
}
