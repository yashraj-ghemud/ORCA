/**
 * Shared server-side HTTP helper for source adapters.
 * - hard timeout per attempt
 * - bounded retries on transient failures (network / 5xx / 429)
 * - native fetch first, then a node:https (IPv4) fallback — some hosts have
 *   broken undici auto-select-family connects where curl/https work fine
 * - NEVER throws into the UI: adapters catch and convert to unavailable states
 */

import { request as httpsRequest } from "node:https";

export interface HttpResult {
  ok: boolean;
  status: number;
  json?: unknown;
  text?: string;
  error?: string;
  latencyMs: number;
}

const DEFAULT_TIMEOUT_MS = 8000;
const DEFAULT_RETRIES = 1;

interface RawResponse {
  status: number;
  text: string;
}

async function nativeFetch(
  url: string,
  headers: Record<string, string>,
  timeoutMs: number
): Promise<RawResponse> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: "application/json", ...headers },
      cache: "no-store",
    });
    const text = await res.text();
    return { status: res.status, text };
  } finally {
    clearTimeout(timer);
  }
}

async function nodeHttpsFallback(
  url: string,
  headers: Record<string, string>,
  timeoutMs: number
): Promise<RawResponse> {
  return new Promise<RawResponse>((resolve, reject) => {
    const u = new URL(url);
    const req = httpsRequest(
      {
        host: u.hostname,
        family: 4,
        port: u.port || 443,
        path: `${u.pathname}${u.search}`,
        method: "GET",
        headers: { Accept: "application/json", ...headers },
        timeout: timeoutMs,
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () =>
          resolve({ status: res.statusCode ?? 0, text: Buffer.concat(chunks).toString("utf8") })
        );
      }
    );
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", reject);
    req.end();
  });
}

export async function fetchJson(
  url: string,
  opts: {
    timeoutMs?: number;
    retries?: number;
    headers?: Record<string, string>;
  } = {}
): Promise<HttpResult> {
  const started = Date.now();
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const retries = opts.retries ?? DEFAULT_RETRIES;
  const headers = {
    "User-Agent": "ORCA-Marine-Prototype/1.0",
    ...opts.headers,
  };

  let lastError = "unknown";
  for (let attempt = 0; attempt <= retries; attempt++) {
    /* try native fetch, then the IPv4 https fallback, per attempt */
    for (const transport of [nativeFetch, nodeHttpsFallback]) {
      try {
        const raw = await transport(url, headers, timeoutMs);
        const latencyMs = Date.now() - started;

        if (raw.status === 429 || raw.status >= 500) {
          lastError = `upstream ${raw.status}`;
          if (attempt < retries) break; /* retry outer loop */
          return { ok: false, status: raw.status, error: lastError, latencyMs };
        }

        let json: unknown;
        try {
          json = JSON.parse(raw.text);
        } catch {
          return {
            ok: raw.status >= 200 && raw.status < 300,
            status: raw.status,
            text: raw.text,
            error: raw.status >= 200 && raw.status < 300 ? "invalid_json" : `upstream ${raw.status}`,
            latencyMs,
          };
        }
        return {
          ok: raw.status >= 200 && raw.status < 300,
          status: raw.status,
          json,
          text: raw.text,
          latencyMs,
        };
      } catch (err) {
        lastError =
          err instanceof Error
            ? err.message === "timeout"
              ? "timeout"
              : err.message || "network_error"
            : "network_error";
        /* native fetch failed at transport level → next transport this attempt */
      }
    }
    if (attempt < retries) {
      await sleep(600 * (attempt + 1));
    }
  }
  return { ok: false, status: 0, error: lastError, latencyMs: Date.now() - started };
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

/** Remove anything that could look like a credential from a logged URL. */
export function sanitizeUrlForLog(url: string): string {
  return url.replace(/([?&](?:api_?key|key|token|subscription)[^&=]*=)[^&]+/gi, "$1***");
}
