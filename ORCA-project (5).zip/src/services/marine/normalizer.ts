/**
 * Unit normalization (STEP 3) — every adapter funnels raw values through
 * these helpers. Canonical internal units (§28):
 *   wind/current m/s · waves m · temperature °C · distance km · time ISO UTC.
 */

export function kmhToMps(kmh: number | null | undefined): number | undefined {
  return num(kmh) != null ? kmhToMpsRaw(kmh as number) : undefined;
}
function kmhToMpsRaw(kmh: number): number {
  return Math.round((kmh / 3.6) * 100) / 100;
}

export function mpsToKmh(mps: number | null | undefined): number | undefined {
  if (num(mps) == null) return undefined;
  return Math.round((mps as number) * 3.6 * 10) / 10;
}

export function knotsToMps(kn: number | null | undefined): number | undefined {
  if (num(kn) == null) return undefined;
  return Math.round((kn as number) * 0.514444 * 100) / 100;
}

export function fToC(f: number | null | undefined): number | undefined {
  if (num(f) == null) return undefined;
  return Math.round((((f as number) - 32) / 1.8) * 10) / 10;
}

/** Keep a value only if it is a finite number within [min, max] (sentinel guards). */
export function num(
  v: number | null | undefined,
  min = -1e9,
  max = 1e9
): number | undefined {
  if (v == null || typeof v !== "number" || !Number.isFinite(v)) return undefined;
  if (v < min || v > max) return undefined;
  return v;
}

/** Round to `dp` decimals, preserving undefined. */
export function round(v: number | null | undefined, dp = 1): number | undefined {
  const n = num(v);
  if (n == null) return undefined;
  const f = 10 ** dp;
  return Math.round(n * f) / f;
}

/* ---------------- direction ---------------- */

const COMPASS = [
  "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW",
] as const;

export function degToCompass(deg: number | null | undefined): string | undefined {
  const n = num(deg, -360, 720);
  if (n == null) return undefined;
  return COMPASS[Math.round((((n % 360) + 360) % 360) / 22.5) % 16];
}

/* ---------------- WMO weather codes (Open-Meteo) ---------------- */

const WMO: Record<number, { en: string; hi: string }> = {
  0: { en: "Clear sky", hi: "साफ़ आसमान" },
  1: { en: "Mainly clear", hi: "मुख्यतः साफ़" },
  2: { en: "Partly cloudy", hi: "आंशिक बादल" },
  3: { en: "Overcast", hi: "बादल छाए" },
  45: { en: "Fog", hi: "कोहरा" },
  48: { en: "Depositing rime fog", hi: "जमा देने वाला कोहरा" },
  51: { en: "Light drizzle", hi: "हल्की बूंदाबांदी" },
  53: { en: "Drizzle", hi: "बूंदाबांदी" },
  55: { en: "Dense drizzle", hi: "घनी बूंदाबांदी" },
  56: { en: "Freezing drizzle", hi: "ठंडी बूंदाबांदी" },
  57: { en: "Dense freezing drizzle", hi: "घनी ठंडी बूंदाबांदी" },
  61: { en: "Slight rain", hi: "हल्की बारिश" },
  63: { en: "Rain", hi: "बारिश" },
  65: { en: "Heavy rain", hi: "भारी बारिश" },
  66: { en: "Freezing rain", hi: "ठंडी बारिश" },
  67: { en: "Heavy freezing rain", hi: "भारी ठंडी बारिश" },
  71: { en: "Slight snow", hi: "हल्की बर्फ़" },
  73: { en: "Snow", hi: "बर्फ़" },
  75: { en: "Heavy snow", hi: "भारी बर्फ़" },
  77: { en: "Snow grains", hi: "बर्फ़ के कण" },
  80: { en: "Rain showers", hi: "बौछारें" },
  81: { en: "Rain showers", hi: "बौछारें" },
  82: { en: "Violent rain showers", hi: "तेज़ बौछारें" },
  85: { en: "Snow showers", hi: "बर्फ़ की बौछारें" },
  86: { en: "Heavy snow showers", hi: "भारी बर्फ़ बौछारें" },
  95: { en: "Thunderstorm", hi: "आंधी-तूफ़ान" },
  96: { en: "Thunderstorm with hail", hi: "ओले के साथ तूफ़ान" },
  99: { en: "Severe thunderstorm with hail", hi: "ओले के साथ तेज़ तूफ़ान" },
};

export function wmoCondition(
  code: number | null | undefined,
  lang: "en" | "hi" = "en"
): string | undefined {
  const c = num(code, 0, 99);
  if (c == null) return undefined;
  return WMO[c]?.[lang];
}

/* ---------------- time ---------------- */

/** Bucket an ISO time string to a granularity in hours (for cache keys). */
export function timeBucketIso(t: string | Date, hours: number): string {
  const d = typeof t === "string" ? new Date(t) : t;
  const ms = hours * 3600_000;
  return new Date(Math.floor(d.getTime() / ms) * ms).toISOString();
}
