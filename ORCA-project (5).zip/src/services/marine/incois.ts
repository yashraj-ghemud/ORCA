/**
 * INCOIS (Indian National Centre for Ocean Information Services) adapter —
 * AUTHORITATIVE ocean-state source (§2).
 *
 * ⚠️ ACCESS STATUS (honest disclosure, §38):
 * INCOIS Ocean State Forecast (OSF) products are published as map/GIS
 * products and region bulletins on incois.gov.in. There is NO verified,
 * documented, unauthenticated JSON API for OSF point queries that this
 * prototype could rely on. Rather than fabricating an endpoint or scraping
 * pages fragilely, this adapter is fully isolated and activates when an
 * officially supported data interface is configured:
 *
 *   INCOIS_API_BASE_URL  base URL of an official/authorized INCOIS data
 *                        interface (e.g. an OSF data service your account
 *                        or MoU provides)
 *   INCOIS_API_KEY       optional bearer token if the interface requires one
 *
 * Expected response shape (validated): { location:{lat,lon}, time,
 * wind_speed_mps?, wind_direction_deg?, current_speed_mps?,
 * current_direction_deg?, wave_height_m?, swell_height_m?, wave_period_s?,
 * swell_period_s?, sst_c?, chlorophyll_mgm3? }
 *
 * Until configured, every function returns status "unavailable" with an
 * explicit note — ORCA then says so honestly instead of inventing values.
 */

import type { MarineOcean, SourceMeta } from "./types";
import { fetchJson, sanitizeUrlForLog } from "./http";
import { cached, bucketCoord, CACHE_TTL } from "./cache";
import { getFreshnessStatus } from "./freshness";
import { num, round } from "./normalizer";

export const INCOIS_ENV = {
  baseUrl: process.env.INCOIS_API_BASE_URL ?? "",
  apiKey: process.env.INCOIS_API_KEY ?? "",
};

export function incoisConfigured(): boolean {
  return Boolean(INCOIS_ENV.baseUrl);
}

const NOT_CONFIGURED =
  "INCOIS Ocean State Forecast has no verified public JSON API; products are GIS/bulletin-based. Configure INCOIS_API_BASE_URL with an official data interface to enable.";

function unavailableMeta(kind: string, note: string = NOT_CONFIGURED): SourceMeta {
  return {
    source: "INCOIS",
    kind,
    retrievedAt: new Date().toISOString(),
    status: "unavailable",
    note,
  };
}

export interface IncoisOutcome {
  ok: boolean;
  ocean?: MarineOcean;
  meta: SourceMeta;
}

export async function getIncoisOceanState(
  lat: number,
  lon: number,
  targetTime?: string
): Promise<IncoisOutcome> {
  if (!incoisConfigured()) return { ok: false, meta: unavailableMeta("ocean_forecast") };

  const key = `incois_osf:${bucketCoord(lat, lon, 0.25)}:${targetTime?.slice(0, 13) ?? "cur"}`;
  return cached({
    cacheIf: v => v.ok === true,
    key,
    ttlS: CACHE_TTL.incois_ocean,
    fetch: async () => {
      const params = new URLSearchParams({
        latitude: lat.toFixed(3),
        longitude: lon.toFixed(3),
      });
      if (targetTime) params.set("time", targetTime);
      const url = `${INCOIS_ENV.baseUrl.replace(/\/$/, "")}/osf?${params}`;
      const res = await fetchJson(url, {
        timeoutMs: 9000,
        retries: 1,
        headers: INCOIS_ENV.apiKey ? { Authorization: `Bearer ${INCOIS_ENV.apiKey}` } : {},
      });

      if (!res.ok || res.json == null) {
        return {
          ok: false,
          meta: {
            source: "INCOIS",
            kind: "ocean_forecast",
            retrievedAt: new Date().toISOString(),
            status: "unavailable",
            note: `INCOIS request failed: ${res.error ?? res.status}`,
            latencyMs: res.latencyMs,
          } satisfies SourceMeta,
        };
      }

      const j = res.json as Record<string, unknown>;
      const ocean: MarineOcean = {
        waveHeightM: round(j.wave_height_m as number, 2),
        swellHeightM: round(j.swell_height_m as number, 2),
        wavePeriodS: round(j.wave_period_s as number, 1),
        swellPeriodS: round(j.swell_period_s as number, 1),
        currentSpeedMps: round(j.current_speed_mps as number, 3),
        currentDirectionDeg: num(j.current_direction_deg as number),
        windSpeedMps: round(j.wind_speed_mps as number, 1),
        windDirectionDeg: num(j.wind_direction_deg as number),
        sstC: round(j.sst_c as number, 1),
        chlorophyllMgM3: round(j.chlorophyll_mgm3 as number, 2),
      };

      const time = typeof j.time === "string" ? j.time : undefined;
      const fr = getFreshnessStatus({ observedAt: time, ttlKey: "incois_ocean" });

      return {
        ok: true,
        ocean,
        meta: {
          source: "INCOIS",
          kind: "ocean_forecast",
          retrievedAt: new Date().toISOString(),
          observedAt: time,
          status: fr.status,
          freshnessSeconds: fr.freshnessSeconds,
          endpointOrDataset: sanitizeUrlForLog("/osf"),
          latencyMs: res.latencyMs,
        } satisfies SourceMeta,
      };
    },
  });
}
