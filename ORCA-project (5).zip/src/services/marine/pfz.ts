/**
 * INCOIS Potential Fishing Zone advisory adapter (§3).
 *
 * ⚠️ ACCESS STATUS (honest disclosure, §38):
 * INCOIS publishes daily PFZ advisories as text bulletins, PDFs and GIS
 * downloads on incois.gov.in. There is NO verified, documented,
 * unauthenticated JSON endpoint for PFZ advisories. This adapter does NOT
 * invent one. It activates only when an official data interface is
 * configured via env (same INCOIS_API_BASE_URL / INCOIS_API_KEY pattern),
 * expecting advisories shaped like:
 *
 *   { advisories: [ { id?, valid_from, valid_until, latitude, longitude,
 *       depth?, distance_km?, bearing?, sector?,
 *       geometry?: { type:"Polygon", coordinates:[[[lng,lat],...]] } } ] }
 *
 * Until configured, getPFZAdvisories returns ok:false + status
 * "unavailable" — the UI then shows an explicit "PFZ advisory unavailable"
 * state. The mock PFZ is NEVER shown in live mode.
 */

import type { PFZAdvisory, SourceMeta } from "./types";
import { fetchJson, sanitizeUrlForLog } from "./http";
import { cached, bucketCoord, CACHE_TTL } from "./cache";
import { getFreshnessStatus } from "./freshness";
import { num, round } from "./normalizer";

export const PFZ_ENV = {
  baseUrl: process.env.INCOIS_API_BASE_URL ?? "",
  apiKey: process.env.INCOIS_API_KEY ?? "",
};

export function pfzConfigured(): boolean {
  return Boolean(PFZ_ENV.baseUrl);
}

const NOT_CONFIGURED =
  "INCOIS PFZ advisories are published as bulletin/GIS products without a verified public JSON API. Configure INCOIS_API_BASE_URL with an official interface to enable.";

export interface PFZOutcome {
  ok: boolean;
  advisories?: PFZAdvisory[];
  meta: SourceMeta;
}

function unavailableMeta(note: string = NOT_CONFIGURED): SourceMeta {
  return {
    source: "INCOIS_PFZ",
    kind: "pfz",
    retrievedAt: new Date().toISOString(),
    status: "unavailable",
    note,
  };
}

/** §3 — getPFZAdvisories(location, date). Never throws. */
export async function getPFZAdvisories(
  location: { lat: number; lon: number },
  date?: string
): Promise<PFZOutcome> {
  if (!pfzConfigured()) return { ok: false, meta: unavailableMeta() };

  const key = `incois_pfz:${bucketCoord(location.lat, location.lon, 1.0)}:${date ?? "today"}`;
  return cached({
    cacheIf: v => v.ok === true,
    key,
    ttlS: CACHE_TTL.incois_pfz,
    fetch: async () => {
      const params = new URLSearchParams({
        lat: location.lat.toFixed(3),
        lon: location.lon.toFixed(3),
      });
      if (date) params.set("date", date.slice(0, 10));
      const url = `${PFZ_ENV.baseUrl.replace(/\/$/, "")}/pfz?${params}`;
      const res = await fetchJson(url, {
        timeoutMs: 9000,
        retries: 1,
        headers: PFZ_ENV.apiKey ? { Authorization: `Bearer ${PFZ_ENV.apiKey}` } : {},
      });

      if (!res.ok || res.json == null) {
        return {
          ok: false,
          meta: {
            source: "INCOIS_PFZ",
            kind: "pfz",
            retrievedAt: new Date().toISOString(),
            status: "unavailable",
            note: `INCOIS PFZ request failed: ${res.error ?? res.status}`,
            latencyMs: res.latencyMs,
          } satisfies SourceMeta,
        };
      }

      const parsed = validatePFZ(res.json);
      if (!parsed) {
        return {
          ok: false,
          meta: {
            source: "INCOIS_PFZ",
            kind: "pfz",
            retrievedAt: new Date().toISOString(),
            status: "unavailable",
            note: "PFZ response did not match the expected advisory schema",
            latencyMs: res.latencyMs,
          } satisfies SourceMeta,
        };
      }

      const nowIso = new Date().toISOString();
      const live = parsed.filter((p) => new Date(p.validUntil).getTime() > Date.now());
      const fr = getFreshnessStatus({
        retrievedAt: nowIso,
        validUntil: live[0]?.validUntil,
        ttlKey: "incois_pfz",
      });

      return {
        ok: true,
        advisories: live,
        meta: {
          source: "INCOIS_PFZ",
          kind: "pfz",
          retrievedAt: nowIso,
          validFrom: live[0]?.validFrom,
          validUntil: live[0]?.validUntil,
          status: live.length ? fr.status : "unavailable",
          freshnessSeconds: fr.freshnessSeconds,
          endpointOrDataset: sanitizeUrlForLog("/pfz"),
          latencyMs: res.latencyMs,
          note: live.length ? undefined : "No active PFZ advisories for this area/date",
        } satisfies SourceMeta,
      };
    },
  });
}

function validatePFZ(json: unknown): PFZAdvisory[] | null {
  const fromObj =
    typeof json === "object" && json !== null && !Array.isArray(json)
      ? (json as { advisories?: unknown }).advisories
      : undefined;
  const arr: unknown[] | null = Array.isArray(json)
    ? (json as unknown[])
    : Array.isArray(fromObj)
      ? (fromObj as unknown[])
      : null;
  if (!arr) return null;
  const out: PFZAdvisory[] = [];
  for (const raw of arr) {
    if (typeof raw !== "object" || raw === null) continue;
    const r = raw as Record<string, unknown>;
    const lat = num(r.latitude as number, -90, 90);
    const lon = num(r.longitude as number, -180, 180);
    const validFrom = iso(r.valid_from ?? r.validFrom);
    const validUntil = iso(r.valid_until ?? r.validUntil);
    if (lat == null || lon == null || !validFrom || !validUntil) continue;
    const geometry = (r.geometry ?? r.polygon) as PFZAdvisory["geometry"] | undefined;
    out.push({
      id: String(r.id ?? `pfz-${lat}-${lon}`),
      validFrom,
      validUntil,
      latitude: lat,
      longitude: lon,
      depth: num(r.depth as number),
      distanceKm: round(r.distance_km as number, 1),
      bearing: typeof r.bearing === "string" ? r.bearing : undefined,
      sector: typeof r.sector === "string" ? r.sector : undefined,
      geometry:
        geometry &&
        typeof geometry === "object" &&
        (geometry as { type?: string }).type === "Polygon" &&
        Array.isArray((geometry as { coordinates?: unknown }).coordinates)
          ? (geometry as PFZAdvisory["geometry"])
          : undefined,
      source: "INCOIS_PFZ",
    });
  }
  return out;
}

function iso(v: unknown): string | undefined {
  if (typeof v !== "string" || !v) return undefined;
  const t = new Date(v).getTime();
  return Number.isFinite(t) ? new Date(t).toISOString() : undefined;
}
