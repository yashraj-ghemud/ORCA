/**
 * Open-Meteo Marine + Weather adapter (STEP 2) — the free, key-less
 * fallback/supplement (§4). Clearly labeled as MODEL data everywhere in the UI.
 *
 * Endpoints (documented, key-less):
 *   https://marine-api.open-meteo.com/v1/marine
 *   https://api.open-meteo.com/v1/forecast
 *
 * Base URLs are env-overridable (OPEN_METEO_BASE_URL / OPEN_METEO_WEATHER_URL)
 * but default to the public documented endpoints. No credentials exist.
 */

import type { MarineContext, MarineOcean, MarineWeather, SourceMeta } from "./types";
import { fetchJson } from "./http";
import { cached, bucketCoord, CACHE_TTL } from "./cache";
import { getFreshnessStatus } from "./freshness";
import { kmhToMps, num, round, wmoCondition } from "./normalizer";

const MARINE_URL =
  process.env.OPEN_METEO_BASE_URL ?? "https://marine-api.open-meteo.com/v1/marine";
const WEATHER_URL =
  process.env.OPEN_METEO_WEATHER_URL ?? "https://api.open-meteo.com/v1/forecast";

const MARINE_CURRENT_VARS = [
  "wave_height",
  "wave_direction",
  "wave_period",
  "wind_wave_height",
  "swell_wave_height",
  "swell_wave_direction",
  "swell_wave_period",
  "sea_surface_temperature",
  "ocean_current_velocity",
  "ocean_current_direction",
  "sea_level_height_msl",
].join(",");

const MARINE_HOURLY_VARS = [
  "wave_height",
  "wave_direction",
  "wave_period",
  "swell_wave_height",
  "swell_wave_period",
  "sea_surface_temperature",
  "ocean_current_velocity",
  "ocean_current_direction",
].join(",");

const WEATHER_CURRENT_VARS = [
  "wind_speed_10m",
  "wind_direction_10m",
  "wind_gusts_10m",
  "temperature_2m",
  "relative_humidity_2m",
  "surface_pressure",
  "visibility",
  "precipitation",
  "weather_code",
].join(",");

const WEATHER_HOURLY_VARS = ["wind_speed_10m", "wind_direction_10m", "wind_gusts_10m"].join(",");

interface OmFailure {
  ok: false;
  meta: SourceMeta;
}

function failMeta(
  source: SourceMeta["source"],
  kind: string,
  note: string,
  latencyMs: number
): OmFailure {
  return {
    ok: false,
    meta: {
      source,
      kind,
      retrievedAt: new Date().toISOString(),
      status: "unavailable",
      latencyMs,
      note,
    },
  };
}

/* ------------------------------------------------------------------ */
/* Marine (waves / swell / currents / SST)                              */
/* ------------------------------------------------------------------ */

export async function getOpenMeteoMarineForecast(
  lat: number,
  lon: number,
  start?: string,
  end?: string
): Promise<
  | {
      ok: true;
      ocean: MarineOcean;
      oceanHourly: { time: string[]; waveHeightM: (number | null)[]; waveDirectionDeg: (number | null)[]; wavePeriodS: (number | null)[] };
      meta: SourceMeta;
    }
  | OmFailure
> {
  const key = `om_marine:${bucketCoord(lat, lon, 0.25)}:${start ?? "cur"}`;
  return cached({
    cacheIf: v => v.ok === true,
    key,
    ttlS: CACHE_TTL.openmeteo_marine,
    fetch: async () => {
      const params = new URLSearchParams({
        latitude: lat.toFixed(3),
        longitude: lon.toFixed(3),
        current: MARINE_CURRENT_VARS,
        hourly: MARINE_HOURLY_VARS,
        forecast_days: "3",
        timezone: "auto",
      });
      if (start) params.set("start_date", start.slice(0, 10));
      if (end) params.set("end_date", end.slice(0, 10));
      const url = `${MARINE_URL}?${params}`;
      const res = await fetchJson(url, { timeoutMs: 9000, retries: 1 });

      if (!res.ok || !res.json || typeof res.json !== "object") {
        const reason =
          (res.json as { reason?: string } | undefined)?.reason ?? res.error ?? "request_failed";
        return failMeta("OPEN_METEO", "ocean_forecast", `Open-Meteo marine: ${reason}`, res.latencyMs);
      }
      const j = res.json as {
        current?: Record<string, number | string>;
        current_units?: Record<string, string>;
        hourly?: Record<string, (number | null)[] | string[]>;
        error?: boolean;
        reason?: string;
      };
      if (j.error) {
        return failMeta("OPEN_METEO", "ocean_forecast", `Open-Meteo marine: ${j.reason ?? "error"}`, res.latencyMs);
      }

      const cur = j.current ?? {};
      const units = j.current_units ?? {};
      // ocean_current_velocity arrives in km/h for the "current" block — normalize.
      const curVelUnit = units.ocean_current_velocity ?? "km/h";
      const curVel = num(cur.ocean_current_velocity as number);
      const currentSpeedMps =
        curVel != null
          ? curVelUnit.includes("km/h")
            ? kmhToMps(curVel)
            : round(curVel, 3)
          : undefined;

      const ocean: MarineOcean = {
        waveHeightM: round(cur.wave_height as number, 2),
        waveDirectionDeg: num(cur.wave_direction as number),
        wavePeriodS: round(cur.wave_period as number, 1),
        windWaveHeightM: round(cur.wind_wave_height as number, 2),
        swellHeightM: round(cur.swell_wave_height as number, 2),
        swellDirectionDeg: num(cur.swell_wave_direction as number),
        swellPeriodS: round(cur.swell_wave_period as number, 1),
        sstC: round(cur.sea_surface_temperature as number, 1),
        currentSpeedMps,
        currentDirectionDeg: num(cur.ocean_current_direction as number),
        seaLevelM: round(cur.sea_level_height_msl as number, 2),
      };

      const hourly = j.hourly ?? {};
      const oceanHourly = {
        time: (hourly.time as string[]) ?? [],
        waveHeightM: (hourly.wave_height as (number | null)[]) ?? [],
        waveDirectionDeg: (hourly.wave_direction as (number | null)[]) ?? [],
        wavePeriodS: (hourly.wave_period as (number | null)[]) ?? [],
      };

      const observedAt = typeof cur.time === "string" ? `${cur.time}:00Z` : undefined;
      const fr = getFreshnessStatus({
        observedAt,
        ttlKey: "openmeteo_marine",
      });

      return {
        ok: true as const,
        ocean,
        oceanHourly,
        meta: {
          source: "OPEN_METEO" as const,
          kind: "ocean_forecast",
          retrievedAt: new Date().toISOString(),
          observedAt,
          status: fr.status,
          freshnessSeconds: fr.freshnessSeconds,
          endpointOrDataset: "open-meteo marine v1 (model)",
          latencyMs: res.latencyMs,
        },
      };
    },
  });
}

/* ------------------------------------------------------------------ */
/* Weather (wind / gust / visibility / pressure)                        */
/* ------------------------------------------------------------------ */

export async function getOpenMeteoWeather(
  lat: number,
  lon: number
): Promise<
  | {
      ok: true;
      weather: MarineWeather;
      weatherHourly: { time: string[]; windSpeedMps: (number | null)[]; windDirectionDeg: (number | null)[]; gustMps: (number | null)[] };
      meta: SourceMeta;
    }
  | OmFailure
> {
  const key = `om_weather:${bucketCoord(lat, lon, 0.5)}`;
  return cached({
    cacheIf: v => v.ok === true,
    key,
    ttlS: CACHE_TTL.openmeteo_weather,
    fetch: async () => {
      const params = new URLSearchParams({
        latitude: lat.toFixed(3),
        longitude: lon.toFixed(3),
        current: WEATHER_CURRENT_VARS,
        hourly: WEATHER_HOURLY_VARS,
        forecast_days: "3",
        timezone: "auto",
      });
      const res = await fetchJson(`${WEATHER_URL}?${params}`, { timeoutMs: 9000, retries: 1 });

      if (!res.ok || !res.json || typeof res.json !== "object") {
        const reason =
          (res.json as { reason?: string } | undefined)?.reason ?? res.error ?? "request_failed";
        return failMeta("OPEN_METEO", "weather_forecast", `Open-Meteo weather: ${reason}`, res.latencyMs);
      }
      const j = res.json as {
        current?: Record<string, number | string>;
        hourly?: Record<string, (number | null)[] | string[]>;
        error?: boolean;
        reason?: string;
      };
      if (j.error) {
        return failMeta("OPEN_METEO", "weather_forecast", `Open-Meteo weather: ${j.reason ?? "error"}`, res.latencyMs);
      }

      const cur = j.current ?? {};
      const weather: MarineWeather = {
        windSpeedMps: kmhToMps(cur.wind_speed_10m as number),
        windDirectionDeg: num(cur.wind_direction_10m as number),
        gustSpeedMps: kmhToMps(cur.wind_gusts_10m as number),
        temperatureC: round(cur.temperature_2m as number, 1),
        humidityPct: num(cur.relative_humidity_2m as number),
        pressureHpa: round(cur.surface_pressure as number, 0),
        visibilityKm: round((num(cur.visibility as number) ?? 0) / 1000, 1) || undefined,
        precipitationMm: round(cur.precipitation as number, 1),
        conditionCode: num(cur.weather_code as number),
        conditionText: wmoCondition(cur.weather_code as number),
      };

      const hourly = j.hourly ?? {};
      const weatherHourly = {
        time: (hourly.time as string[]) ?? [],
        windSpeedMps: ((hourly.wind_speed_10m as (number | null)[]) ?? []).map((v) =>
          v == null ? null : kmhToMps(v) ?? null
        ),
        windDirectionDeg: (hourly.wind_direction_10m as (number | null)[]) ?? [],
        gustMps: ((hourly.wind_gusts_10m as (number | null)[]) ?? []).map((v) =>
          v == null ? null : kmhToMps(v) ?? null
        ),
      };

      const observedAt = typeof cur.time === "string" ? `${cur.time}:00Z` : undefined;
      const fr = getFreshnessStatus({ observedAt, ttlKey: "openmeteo_weather" });

      return {
        ok: true as const,
        weather,
        weatherHourly,
        meta: {
          source: "OPEN_METEO" as const,
          kind: "weather_forecast",
          retrievedAt: new Date().toISOString(),
          observedAt,
          status: fr.status,
          freshnessSeconds: fr.freshnessSeconds,
          endpointOrDataset: "open-meteo forecast v1 (model)",
          latencyMs: res.latencyMs,
        },
      };
    },
  });
}

/** Pick the hourly value closest to an ISO target time. */
export function pickHourly(
  time: string[],
  values: (number | null)[],
  targetIso: string
): number | null | undefined {
  if (!time.length) return undefined;
  const t = new Date(targetIso).getTime();
  let bestIdx = -1;
  let bestDiff = Infinity;
  for (let i = 0; i < time.length; i++) {
    const ts = new Date(`${time[i]}:00Z`).getTime();
    if (!Number.isFinite(ts)) continue;
    const diff = Math.abs(ts - t);
    if (diff < bestDiff) {
      bestDiff = diff;
      bestIdx = i;
    }
  }
  if (bestIdx < 0 || bestDiff > 3 * 3600_000) return undefined;
  return values[bestIdx] ?? null;
}

/** Convenience: ocean + weather in parallel for a context request. */
export async function getOpenMeteoBundle(lat: number, lon: number) {
  const [marine, weather] = await Promise.all([
    getOpenMeteoMarineForecast(lat, lon),
    getOpenMeteoWeather(lat, lon),
  ]);
  return { marine, weather };
}

/** Type guard helper used by the aggregator. */
export function isOmFailure(x: unknown): x is OmFailure {
  return typeof x === "object" && x !== null && (x as { ok?: unknown }).ok === false;
}

/* Re-export for aggregator typing convenience */
export type { MarineContext };
