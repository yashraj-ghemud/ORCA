import type { LayerToggles, MapViewId } from "@/types/orca";

/* ---------------- palette (SSR-safe) ---------------- */
export const ZONE = {
  hazardFill: "#c2410c",
  hazardStroke: "#c2410c",
  cycloneFill: "#b91c1c",
  cycloneStroke: "#b91c1c",
  pfzFill: "#0f766e",
  pfzStroke: "#0f766e",
  safeFill: "#15803d",
  safeStroke: "#15803d",
  route: "#0e7490",
  boundary: "#8296a3",
  sea: "#2f6f95",
};

/* ---------------- layer defaults per view ---------------- */

export const LAYER_DEFAULTS: Record<MapViewId, LayerToggles> = {
  default: { vessel: true, risk: false, pfz: false, weather: false, boundaries: false, seaState: false },
  safety: { vessel: true, risk: true, pfz: false, weather: true, boundaries: true, seaState: false },
  pfz: { vessel: true, risk: false, pfz: true, weather: false, boundaries: true, seaState: false },
  hazard: { vessel: true, risk: true, pfz: false, weather: true, boundaries: false, seaState: false },
  route: { vessel: true, risk: true, pfz: false, weather: false, boundaries: false, seaState: false },
  conditions: { vessel: true, risk: false, pfz: false, weather: true, boundaries: true, seaState: true },
};

export function kmToMeters(km: number) {
  return km * 1000;
}

export function fmtCoord(v: number, pos: string, neg: string) {
  return `${Math.abs(v).toFixed(4)}° ${v >= 0 ? pos : neg}`;
}
