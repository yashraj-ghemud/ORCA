"use client";

/**
 * Microphone capture → 16 kHz mono WAV base64, fully client-side.
 * MediaRecorder output (webm/ogg/mp4 depending on browser) is decoded with
 * WebAudio, downmixed, resampled and re-encoded as PCM WAV so the ASR
 * backend always receives a well-supported format.
 */

export interface MicSession {
  stream: MediaStream;
  recorder: MediaRecorder;
  chunks: Blob[];
}

const TARGET_RATE = 16000;
const MAX_SECONDS = 30;

export const MIC_MAX_SECONDS = MAX_SECONDS;

/** Start recording from the default microphone. Throws on permission denial. */
export async function startMicRecording(): Promise<MicSession> {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("unsupported");
  }
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: true },
  });

  const mimes = [
    "audio/webm;codecs=opus",
    "audio/webm",
    "audio/mp4",
    "audio/ogg;codecs=opus",
  ];
  const supported = mimes.find(
    (m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported?.(m)
  );
  const recorder = supported
    ? new MediaRecorder(stream, { mimeType: supported })
    : new MediaRecorder(stream);

  const chunks: Blob[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };
  recorder.start(250);

  return { stream, recorder, chunks };
}

/**
 * Stop the session and return the recording as base64 WAV (16 kHz mono,
 * capped at MAX_SECONDS). Resolves after all audio data is flushed.
 */
export async function stopMicRecordingToBase64Wav(
  session: MicSession
): Promise<string> {
  const blob = await new Promise<Blob>((resolve) => {
    if (session.recorder.state === "inactive") {
      resolve(new Blob(session.chunks, { type: session.chunks[0]?.type || "audio/webm" }));
      return;
    }
    session.recorder.onstop = () =>
      resolve(new Blob(session.chunks, { type: session.chunks[0]?.type || "audio/webm" }));
    session.recorder.stop();
  });
  session.stream.getTracks().forEach((t) => t.stop());

  if (blob.size === 0) throw new Error("empty");

  const raw = await blob.arrayBuffer();
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AudioCtx();
  try {
    const decoded = await ctx.decodeAudioData(raw.slice(0));
    const rendered = await resampleToMono(decoded);
    return encodeWavBase64(rendered);
  } finally {
    void ctx.close();
  }
}

/** Hard-abort a session without producing audio (cancel path). */
export function cancelMicRecording(session: MicSession) {
  try {
    if (session.recorder.state !== "inactive") session.recorder.stop();
  } catch {
    /* noop */
  }
  session.stream.getTracks().forEach((t) => t.stop());
}

async function resampleToMono(decoded: AudioBuffer): Promise<AudioBuffer> {
  const maxFrames = Math.floor(decoded.sampleRate * MAX_SECONDS);
  const frames = Math.min(decoded.length, maxFrames);

  const OfflineCtx =
    window.OfflineAudioContext ||
    (window as unknown as { webkitOfflineAudioContext: typeof OfflineAudioContext })
      .webkitOfflineAudioContext;

  try {
    const off = new OfflineCtx(1, Math.ceil((frames / decoded.sampleRate) * TARGET_RATE), TARGET_RATE);
    const src = off.createBufferSource();
    src.buffer = decoded;
    src.connect(off.destination);
    src.start(0, 0, frames / decoded.sampleRate);
    return await off.startRendering();
  } catch {
    /* offline resample unavailable — fall back to original rate */
    return decoded;
  }
}

function encodeWavBase64(audio: AudioBuffer): string {
  const channels = Math.min(audio.numberOfChannels, 2);
  const numFrames = audio.length;
  const sampleRate = audio.sampleRate;
  const bytesPerSample = 2;
  const blockAlign = channels * bytesPerSample;
  const dataSize = numFrames * blockAlign;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); /* PCM */
  view.setUint16(22, channels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, dataSize, true);

  /* interleave channels */
  const chanData: Float32Array[] = [];
  for (let c = 0; c < channels; c++) chanData.push(audio.getChannelData(c));

  let offset = 44;
  for (let i = 0; i < numFrames; i++) {
    for (let c = 0; c < channels; c++) {
      let sample = chanData[c][i];
      sample = Math.max(-1, Math.min(1, sample));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }

  /* ArrayBuffer → base64 (chunked to avoid call-stack limits) */
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(
      null,
      bytes.subarray(i, i + CHUNK) as unknown as number[]
    );
  }
  return btoa(binary);
}
