"use client";

import { useSyncExternalStore } from "react";
import type { Lang } from "@/lib/i18n";

/**
 * Global singleton voice-briefing player (client only).
 * - One audio element, sequential playback of WAV segments from /api/tts.
 * - React components subscribe via useVoiceState().
 * - Only one briefing can play at a time; starting a new one stops the old.
 */

export type VoicePhase = "idle" | "loading" | "speaking";

export interface VoiceState {
  phase: VoicePhase;
  /** message id currently loading/playing */
  id: string | null;
}

let state: VoiceState = { phase: "idle", id: null };
const listeners = new Set<() => void>();

let audioEl: HTMLAudioElement | null = null;
let queue: string[] = [];
let urls: string[] = [];
/** bumped on every stop/start — stale async chains compare and bail out */
let token = 0;

let errorHandler: ((message: string) => void) | null = null;

function set(patch: Partial<VoiceState>) {
  state = { ...state, ...patch };
  listeners.forEach((fn) => fn());
}

export function subscribeVoice(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

export function getVoiceState(): VoiceState {
  return state;
}

function getServerVoiceState(): VoiceState {
  return { phase: "idle", id: null };
}

/** React hook — re-renders when the global voice state changes. */
export function useVoiceState(): VoiceState {
  return useSyncExternalStore(subscribeVoice, getVoiceState, getServerVoiceState);
}

/** Register a handler for voice errors (e.g. pushToast). */
export function setVoiceErrorHandler(fn: (message: string) => void) {
  errorHandler = fn;
}

function ensureAudio(): HTMLAudioElement {
  if (!audioEl) {
    audioEl = new Audio();
    audioEl.preload = "auto";
  }
  return audioEl;
}

function releaseUrls() {
  urls.forEach((u) => URL.revokeObjectURL(u));
  urls = [];
  queue = [];
}

/** Stop any playing/loading briefing immediately. */
export function stopSpeaking() {
  token++;
  releaseUrls();
  if (audioEl) {
    audioEl.pause();
    audioEl.removeAttribute("src");
  }
  if (state.phase !== "idle" || state.id !== null) {
    set({ phase: "idle", id: null });
  }
}

/**
 * Speak a message briefing. Resolves when playback finishes, is stopped, or fails.
 * Calling again with the same active id toggles (stops) playback.
 */
export async function speakMessage(
  id: string,
  text: string,
  lang: Lang
): Promise<void> {
  const clean = (text ?? "").trim();
  if (!clean) return;

  /* toggle: same message already active → stop */
  if (state.id === id && state.phase !== "idle") {
    stopSpeaking();
    return;
  }

  stopSpeaking();
  const myToken = ++token;
  set({ phase: "loading", id });

  try {
    const res = await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: clean, lang }),
    });
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      throw new Error(data.error || `Voice briefing failed (${res.status})`);
    }
    const data = (await res.json()) as { segments?: string[] };
    if (myToken !== token) return; /* superseded while fetching */
    if (!data.segments || data.segments.length === 0) {
      throw new Error("No audio received");
    }

    const segUrls = data.segments.map((b64) => {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return URL.createObjectURL(new Blob([bytes], { type: "audio/wav" }));
    });
    urls = segUrls;
    queue = [...segUrls];

    const audio = ensureAudio();
    set({ phase: "speaking" });

    await new Promise<void>((resolve) => {
      const playNext = () => {
        if (myToken !== token) {
          resolve();
          return;
        }
        const next = queue.shift();
        if (!next) {
          set({ phase: "idle", id: null });
          releaseUrls();
          resolve();
          return;
        }
        audio.src = next;
        audio.onended = playNext;
        audio.onerror = () => {
          if (myToken === token) set({ phase: "idle", id: null });
          resolve();
        };
        audio.play().catch(() => {
          if (myToken === token) set({ phase: "idle", id: null });
          resolve();
        });
      };
      playNext();
    });
  } catch (err) {
    if (myToken === token) set({ phase: "idle", id: null });
    const message = err instanceof Error ? err.message : "Voice briefing failed";
    console.warn("[voice-client]", message);
    errorHandler?.(message);
  }
}
