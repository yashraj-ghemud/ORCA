import type { MarineLocation, RiskLevel } from "@/types/marine";
import type { EvidenceItem, FlowId, OrcaResponse, Tone } from "@/types/orca";
import type { Lang } from "./i18n";

/**
 * Mock ORCA reasoning service.
 * Frontend-only simulation of the multi-agent pipeline:
 * Planning/Orchestrator → Specialist agents → Response Synthesis.
 * A real backend would replace `resolveFlow` + `buildResponse` with API calls.
 */

/* ------------------------------------------------------------------ */
/* Intent routing (mock)                                               */
/* ------------------------------------------------------------------ */

const FLOW_KEYWORDS: Record<FlowId, string[]> = {
  safety: ["safe", "sail", "safety", "go fishing", "fishing tomorrow", "venture", "go out", "jaana", "surakshit", "जाना", "सुरक्षित"],
  pfz: ["pfz", "fishing zone", "nearest zone", "zone today", "where to fish", "machhli", "मछली", "क्षेत्र"],
  hazard: ["hazard", "cyclone", "alert", "storm", "danger", "risk", "khatra", "toofan", "खतरा", "चक्रवात", "तूफ़ान"],
  route: ["route", "avoid", "path", "safer zone", "safe zone", "safer fishing", "how can i", "raasta", "मार्ग", "बचाव"],
  conditions: ["tomorrow", "forecast", "outlook", "conditions", "kal", "कल", "पूर्वानुमान"],
  explain: ["why", "reason", "explain", "how did", "kyun", "kyon", "क्यों"],
};

const FLOW_ORDER: FlowId[] = ["route", "pfz", "safety", "hazard", "conditions", "explain"];

export function resolveFlow(query: string): FlowId {
  const q = query.toLowerCase();
  for (const flow of FLOW_ORDER) {
    if (FLOW_KEYWORDS[flow].some((k) => q.includes(k))) return flow;
  }
  return "conditions";
}

/* ------------------------------------------------------------------ */
/* Derived risk (simulated specialist-agent reasoning)                 */
/* ------------------------------------------------------------------ */

export function deriveRisk(loc: MarineLocation): RiskLevel {
  const { waveHeightM, windKmh } = loc.conditions;
  const cycloneNear = loc.cyclone && loc.cyclone.distanceKm <= 120;
  if (waveHeightM >= 2.5 || windKmh >= 25 || cycloneNear) return "high";
  if (waveHeightM >= 1.8 || windKmh >= 16 || loc.conditions.advisory === "watch") return "moderate";
  return "low";
}

/* ------------------------------------------------------------------ */
/* Processing timeline (ms) — drives the staged activity UI            */
/* ------------------------------------------------------------------ */

export const PROCESSING_TIMELINE = [420, 980, 1780, 2480, 3150];

/* ------------------------------------------------------------------ */
/* Response builder                                                    */
/* ------------------------------------------------------------------ */

const RISK_HEADLINE: Record<RiskLevel, { en: string; hi: string; tone: Tone }> = {
  high: { en: "HIGH MARINE RISK", hi: "उच्च समुद्री जोखिम", tone: "danger" },
  moderate: { en: "MODERATE RISK — CAUTION", hi: "मध्यम जोखिम — सावधानी", tone: "warning" },
  low: { en: "LOW RISK — FAVOURABLE", hi: "कम जोखिम — अनुकूल", tone: "good" },
};

const EVID = {
  wave: { en: "Wave height", hi: "लहर की ऊँचाई" },
  wind: { en: "Wind", hi: "हवा" },
  cyclone: { en: "Cyclone proximity", hi: "चक्रवात दूरी" },
  vis: { en: "Visibility", hi: "दृश्यता" },
  sst: { en: "Sea surface temp.", hi: "समुद्री सतह तापमान" },
  chl: { en: "Chlorophyll", hi: "क्लोरोफिल" },
  boundary: { en: "Boundary status", hi: "सीमा स्थिति" },
  advisory: { en: "Advisory", hi: "चेतावनी" },
  tide: { en: "Tide", hi: "ज्वार" },
  dist: { en: "Distance", hi: "दूरी" },
  front: { en: "SST front", hi: "एसएसटी फ्रंट" },
  species: { en: "Likely species", hi: "संभावित मछली" },
  eta: { en: "Est. time", hi: "अनुमानित समय" },
  clearance: { en: "Hazard clearance", hi: "खतरे से दूरी" },
  dest: { en: "Destination", hi: "गंतव्य" },
  path: { en: "Path length", hi: "मार्ग की लंबाई" },
  movement: { en: "Movement", hi: "गति" },
  system: { en: "System", hi: "प्रणाली" },
} as const;

function ev(
  cat: EvidenceItem["category"],
  key: keyof typeof EVID,
  value: string,
  tone?: EvidenceItem["tone"],
  short?: string
): EvidenceItem {
  return {
    category: cat,
    label: EVID[key].en,
    labelHi: EVID[key].hi,
    value,
    short,
    tone,
  };
}

export function buildResponse(flow: FlowId, loc: MarineLocation, lang: Lang): OrcaResponse {
  const c = loc.conditions;
  const risk = deriveRisk(loc);
  const cy = loc.cyclone;
  const pfz = loc.pfzZones[0];
  const hz = loc.hazardZones[0];
  const sz = loc.safeZones[0];
  const rt = loc.route;

  const followUps = {
    safety: [
      { en: "Nearest safer fishing zone?", hi: "नज़दीकी सुरक्षित मत्स्य क्षेत्र?" },
      { en: "Why this region?", hi: "यह क्षेत्र क्यों?" },
    ],
    pfz: [
      { en: "Is it safe to go fishing tomorrow?", hi: "कल मछली पकड़ने जाना सुरक्षित है?" },
      { en: "How can I avoid the hazard zone?", hi: "खतरा क्षेत्र से कैसे बचें?" },
    ],
    route: [
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
      { en: "Tomorrow's conditions", hi: "कल का पूर्वानुमान" },
    ],
    hazard: [
      { en: "How can I avoid the hazard zone?", hi: "खतरा क्षेत्र से कैसे बचें?" },
      { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
    ],
    conditions: [
      { en: "Safe to sail?", hi: "जाना सुरक्षित है?" },
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
    ],
    explain: [
      { en: "Nearest PFZ", hi: "नज़दीकी PFZ" },
      { en: "Tomorrow's conditions", hi: "कल का पूर्वानुमान" },
    ],
  } as const;

  const advisoryText =
    c.advisory === "active"
      ? lang === "hi"
        ? "सक्रिय — तटीय निगरानी जारी"
        : "Active — coastal monitoring ongoing"
      : c.advisory === "watch"
        ? lang === "hi"
          ? "सतर्क — अपडेट देखते रहें"
          : "Watch — stay updated"
        : lang === "hi"
          ? "कोई नहीं"
          : "None";

  const boundaryText =
    c.boundaryStatus === "clear"
      ? lang === "hi"
        ? "स्पष्ट"
        : "Clear"
      : c.boundaryStatus === "near"
        ? lang === "hi"
          ? "सीमा के पास"
          : "Near boundary"
        : lang === "hi"
          ? "प्रतिबंधित"
          : "Restricted";

  const weatherOcean = [
    ev("Weather & Ocean", "wave", `${c.waveHeightM} m`, c.waveHeightM >= 2.5 ? "danger" : c.waveHeightM >= 1.8 ? "warning" : "good"),
    ev("Weather & Ocean", "wind", `${c.windKmh} km/h ${c.windDir} · gust ${c.gustKmh}`, c.windKmh >= 25 ? "danger" : c.windKmh >= 16 ? "warning" : "good", `${c.windKmh} km/h ${c.windDir}`),
    ev("Weather & Ocean", "vis", `${c.visibilityKm} km`, c.visibilityKm <= 5 ? "warning" : "neutral"),
    ev("Weather & Ocean", "sst", `${c.sstC} °C`),
  ];

  const geoRisk = [
    ...(cy
      ? [ev("Geospatial & Risk", "cyclone", `${cy.distanceKm} km ${cy.bearing} · ${cy.name}`, cy.distanceKm <= 120 ? "danger" : "neutral", `${cy.distanceKm} km ${cy.bearing}`)]
      : [ev("Geospatial & Risk", "cyclone", lang === "hi" ? "300 किमी में कोई चक्रवात नहीं" : "None within 300 km", "good", lang === "hi" ? "कोई नहीं" : "None")]),
    ev("Geospatial & Risk", "boundary", boundaryText, c.boundaryStatus === "clear" ? "good" : "warning"),
  ];

  const marineData = [
    ev("Marine Data", "chl", c.chlorophyll, c.chlorophyll.includes("elevated") ? "good" : "neutral", c.chlorophyll.split(" — ")[0]),
    ev("Marine Data", "advisory", advisoryText, c.advisory === "active" ? "warning" : "neutral", c.advisory === "active" ? (lang === "hi" ? "सक्रिय" : "Active") : c.advisory === "watch" ? (lang === "hi" ? "सतर्क" : "Watch") : lang === "hi" ? "कोई नहीं" : "None"),
    ev("Marine Data", "tide", c.tide),
  ];

  /* ---------------- safety ---------------- */
  if (flow === "safety") {
    const h = RISK_HEADLINE[risk];
    const summaries: Record<RiskLevel, { en: string; hi: string }> = {
      high: {
        en: `Conditions near ${loc.name} indicate elevated marine risk. Avoid venturing into open sea tomorrow morning.`,
        hi: `${loc.nameHi} के पास स्थितियाँ उच्च समुद्री जोखिम दिखाती हैं। कल सुबह खुले समुद्र में न जाएँ।`,
      },
      moderate: {
        en: `Conditions near ${loc.name} are workable but changing. Small vessels should stay within sight of the coast.`,
        hi: `${loc.nameHi} के पास स्थितियाँ चल सकती हैं पर बदल रही हैं। छोटे जहाज़ तट की दृष्टि में ही रहें।`,
      },
      low: {
        en: `Conditions near ${loc.name} are favourable for fishing tomorrow morning. Standard precautions still apply.`,
        hi: `${loc.nameHi} के पास कल सुबह मछली पकड़ने के लिए स्थितियाँ अनुकूल हैं। सामान्य सावधानी रखें।`,
      },
    };
    return {
      flow,
      headline: h.en,
      headlineHi: h.hi,
      tone: h.tone,
      riskLevel: risk,
      summary: summaries[risk].en,
      summaryHi: summaries[risk].hi,
      evidence: [...weatherOcean, ...geoRisk, ...marineData],
      advisories:
        risk === "high"
          ? [
              `${hz.reason} near ${loc.name} (simulated)`,
              lang === "hi" ? "0600–1200 IST के बीच यात्रा टालें" : "Avoid transit between 0600–1200 IST",
            ]
          : [lang === "hi" ? "जाने से पहले स्थानीय सूचना जाँचें" : "Check local notices before departure"],
      advisoriesHi:
        risk === "high"
          ? [`${hz.reasonHi} — ${loc.nameHi} (सिम्युलेटेड)`, "0600–1200 IST के बीच यात्रा टालें"]
          : ["जाने से पहले स्थानीय सूचना जाँचें"],
      analysis: {
        intent: lang === "hi" ? "सुरक्षा जाँच" : "Safety check",
        intentHi: "सुरक्षा जाँच",
        sources: lang === "hi" ? "मौसम + सागर + भू-स्थानिक" : "Weather + Ocean + Geospatial",
        sourcesHi: "मौसम + सागर + भू-स्थानिक",
        keyEvidence:
          risk === "high"
            ? [
                `${c.waveHeightM} m ${EVID.wave.en.toLowerCase()}`,
                `${c.windKmh} km/h ${EVID.wind.en.toLowerCase()}`,
                cy ? `${cy.distanceKm} km ${EVID.cyclone.en.toLowerCase()}` : EVID.cyclone.en + ": none",
              ]
            : [`${c.waveHeightM} m waves`, `${c.windKmh} km/h wind`, `visibility ${c.visibilityKm} km`],
        keyEvidenceHi:
          risk === "high"
            ? [`${c.waveHeightM} मी लहर`, `${c.windKmh} किमी/घं हवा`, cy ? `${cy.distanceKm} किमी चक्रवात` : "कोई चक्रवात नहीं"]
            : [`${c.waveHeightM} मी लहर`, `${c.windKmh} किमी/घं हवा`, `दृश्यता ${c.visibilityKm} किमी`],
        conclusion:
          risk === "high"
            ? "High marine risk"
            : risk === "moderate"
              ? "Caution advised"
              : "Favourable conditions",
        conclusionHi:
          risk === "high" ? "उच्च समुद्री जोखिम" : risk === "moderate" ? "सावधानी रखें" : "अनुकूल स्थितियाँ",
      },
      map: {
        view: "safety",
        center: cy ? { lat: (loc.vessel.position.lat + cy.center.lat) / 2, lng: (loc.vessel.position.lng + cy.center.lng) / 2 } : loc.center,
        zoom: 9.2,
      },
      followUps: [...followUps.safety],
    };
  }

  /* ---------------- pfz ---------------- */
  if (flow === "pfz") {
    return {
      flow,
      headline: lang === "hi" ? "संभावित मत्स्य क्षेत्र" : "POTENTIAL FISHING ZONE",
      headlineHi: "संभावित मत्स्य क्षेत्र",
      tone: "good",
      riskLevel: risk,
      summary:
        lang === "hi"
          ? `${loc.nameHi} के पास आपकी स्थिति से ${pfz.distanceKm} किमी ${pfz.bearing} पर एक आशाजनक क्षेत्र पाया गया है।`
          : `A promising zone was detected ${pfz.distanceKm} km ${pfz.bearing} of your position, near ${loc.name}.`,
      summaryHi: `${loc.nameHi} के पास आपकी स्थिति से ${pfz.distanceKm} किमी ${pfz.bearing} पर एक आशाजनक क्षेत्र पाया गया है।`,
      evidence: [
        ev("Geospatial & Risk", "dist", `${pfz.distanceKm} km ${pfz.bearing}`, "good"),
        ev("Marine Data", "front", pfz.sstFront, "good", pfz.sstFront.replace(" across front", "")),
        ev("Marine Data", "chl", pfz.chlorophyll, "good", pfz.chlorophyll.split(" — ")[0]),
        ev("Marine Data", "species", pfz.likelySpecies.join(", "), undefined, pfz.likelySpecies[0]),
        ev("Weather & Ocean", "wave", `${c.waveHeightM} m`, c.waveHeightM >= 2.5 ? "warning" : "neutral"),
        ev("Marine Data", "advisory", advisoryText, c.advisory === "active" ? "warning" : "neutral", c.advisory === "active" ? (lang === "hi" ? "सक्रिय" : "Active") : c.advisory === "watch" ? (lang === "hi" ? "सतर्क" : "Watch") : lang === "hi" ? "कोई नहीं" : "None"),
      ],
      advisories:
        risk === "high"
          ? [lang === "hi" ? "निकलने से पहले खतरा क्षेत्र की जाँच करें — जोखिम ऊँचा है" : "Verify the hazard zone before departing — risk is elevated"]
          : [lang === "hi" ? "सुबह की खिड़की सबसे उपयुक्त है" : "Morning window looks most suitable"],
      advisoriesHi:
        risk === "high"
          ? ["निकलने से पहले खतरा क्षेत्र की जाँच करें — जोखिम ऊँचा है"]
          : ["सुबह की खिड़की सबसे उपयुक्त है"],
      analysis: {
        intent: lang === "hi" ? "मत्स्य क्षेत्र खोज" : "Fishing zone lookup",
        intentHi: "मत्स्य क्षेत्र खोज",
        sources: lang === "hi" ? "सागर रंजकता + SST + स्थानिक" : "Ocean colour + SST + Geospatial",
        sourcesHi: "सागर रंजकता + SST + स्थानिक",
        keyEvidence: [pfz.sstFront, pfz.chlorophyll, `${pfz.distanceKm} km ${pfz.bearing}`],
        keyEvidenceHi: [pfz.sstFront, pfz.chlorophyll, `${pfz.distanceKm} किमी ${pfz.bearing}`],
        conclusion: lang === "hi" ? "PFZ पाया गया — साक्ष्य-आधारित" : "PFZ detected — evidence-backed",
        conclusionHi: "PFZ पाया गया — साक्ष्य-आधारित",
      },
      map: { view: "pfz", center: pfz.center, zoom: 11 },
      followUps: [...followUps.pfz],
    };
  }

  /* ---------------- hazard ---------------- */
  if (flow === "hazard") {
    return {
      flow,
      headline: lang === "hi" ? "खतरा चेतावनी" : "HAZARD ADVISORY",
      headlineHi: "खतरा चेतावनी",
      tone: "warning",
      riskLevel: risk,
      summary:
        lang === "hi"
          ? `चक्रवाती गतिविधि आपके निगरानी क्षेत्र को प्रभावित कर रही है। आंधी हवाएँ और उग्र समुद्र की संभावना।`
          : "Cyclonic activity is influencing your monitored area. Squally winds and rough seas expected.",
      summaryHi: "चक्रवाती गतिविधि आपके निगरानी क्षेत्र को प्रभावित कर रही है। आंधी हवाएँ और उग्र समुद्र की संभावना।",
      evidence: [
        ...(cy
          ? [
              ev("Geospatial & Risk", "system", `${cy.name} — ${cy.category}`, "danger", `Cyclone ${cy.name}`),
              ev("Geospatial & Risk", "cyclone", `${cy.distanceKm} km ${cy.bearing}`, "danger"),
              ev("Geospatial & Risk", "movement", cy.movement, "warning", cy.movement.replace("Moving ", "")),
            ]
          : [ev("Geospatial & Risk", "system", "No cyclonic system", "good")]),
        ev("Weather & Ocean", "wave", `${c.waveHeightM} m`, "danger"),
        ev("Weather & Ocean", "wind", `${c.windKmh} km/h · gust ${c.gustKmh}`, "danger", `${c.windKmh} km/h`),
        ev("Marine Data", "advisory", advisoryText, "warning", c.advisory === "active" ? (lang === "hi" ? "सक्रिय" : "Active") : c.advisory === "watch" ? (lang === "hi" ? "सतर्क" : "Watch") : lang === "hi" ? "कोई नहीं" : "None"),
      ],
      advisories: [lang === "hi" ? hz.reasonHi : hz.reason],
      advisoriesHi: [hz.reasonHi],
      analysis: {
        intent: lang === "hi" ? "खतरा निरीक्षण" : "Hazard inspection",
        intentHi: "खतरा निरीक्षण",
        sources: lang === "hi" ? "मौसम + भू-स्थानिक + सलाहकार डेटा" : "Weather + Geospatial + Advisory feeds",
        sourcesHi: "मौसम + भू-स्थानिक + सलाहकार डेटा",
        keyEvidence: cy
          ? [`${cy.name} — ${cy.category}`, `${cy.distanceKm} km ${cy.bearing}`, `${c.waveHeightM} m waves`]
          : [`${c.waveHeightM} m waves`, `${c.windKmh} km/h wind`],
        keyEvidenceHi: cy
          ? [`${cy.name} — ${cy.category}`, `${cy.distanceKm} किमी ${cy.bearing}`, `${c.waveHeightM} मी लहर`]
          : [`${c.waveHeightM} मी लहर`, `${c.windKmh} किमी/घं हवा`],
        conclusion: lang === "hi" ? "खतरा क्षेत्र सक्रिय" : "Hazard zone active",
        conclusionHi: "खतरा क्षेत्र सक्रिय",
      },
      map: {
        view: "hazard",
        center: hz ? hz.center : loc.center,
        zoom: 9.6,
      },
      followUps: [...followUps.hazard],
    };
  }

  /* ---------------- route ---------------- */
  if (flow === "route") {
    return {
      flow,
      headline: lang === "hi" ? "सुझाया गया सुरक्षित मार्ग" : "SUGGESTED SAFER PATH",
      headlineHi: "सुझाया गया सुरक्षित मार्ग",
      tone: "info",
      riskLevel: risk,
      summary:
        lang === "hi"
          ? `खतरा क्षेत्र के चारों ओर ${rt.destinationHi} की ओर एक सुरक्षित मार्ग, लगभग ${rt.distanceKm} किमी (क्रूज़िंग गति पर ≈ ${rt.etaHours} घंटे)।`
          : `A safer route around the hazard zone toward ${rt.destination.toLowerCase()}, approx. ${rt.distanceKm} km (≈ ${rt.etaHours} h at cruising speed).`,
      summaryHi: `खतरा क्षेत्र के चारों ओर ${rt.destinationHi} की ओर एक सुरक्षित मार्ग, लगभग ${rt.distanceKm} किमी (क्रूज़िंग गति पर ≈ ${rt.etaHours} घंटे)।`,
      evidence: [
        ev("Geospatial & Risk", "path", `${rt.distanceKm} km`, "good"),
        ev("Geospatial & Risk", "eta", `≈ ${rt.etaHours} h`, "neutral"),
        ev("Geospatial & Risk", "clearance", `${rt.clearanceKm}+ km from hazard edge`, "good", `${rt.clearanceKm}+ km clear`),
        ev("Geospatial & Risk", "dest", rt.destination, "good", rt.destination.split(" ").slice(0, 2).join(" ")),
        ev("Weather & Ocean", "wave", `${c.waveHeightM} m along path`, c.waveHeightM >= 2.5 ? "warning" : "neutral", `${c.waveHeightM} m`),
      ],
      advisories: [lang === "hi" ? "सिम्युलेटेड सिफ़ारिश — वास्तविक नेविगेशन निर्देश नहीं" : "Simulated recommendation — not a navigation directive"],
      advisoriesHi: ["सिम्युलेटेड सिफ़ारिश — वास्तविक नेविगेशन निर्देश नहीं"],
      analysis: {
        intent: lang === "hi" ? "सुरक्षित मार्ग सुझाव" : "Safer route suggestion",
        intentHi: "सुरक्षित मार्ग सुझाव",
        sources: lang === "hi" ? "खतरा ज्यामिति + सागर स्थिति" : "Hazard geometry + sea state",
        sourcesHi: "खतरा ज्यामिति + सागर स्थिति",
        keyEvidence: [`${rt.distanceKm} km path`, `${rt.clearanceKm}+ km clearance`, rt.destination],
        keyEvidenceHi: [`${rt.distanceKm} किमी मार्ग`, `${rt.clearanceKm}+ किमी दूरी`, rt.destinationHi],
        conclusion: lang === "hi" ? "मार्ग सुरक्षित दिखता है" : "Route appears passable",
        conclusionHi: "मार्ग सुरक्षित दिखता है",
      },
      map: { view: "route", center: loc.center, zoom: 10.2 },
      followUps: [...followUps.route],
    };
  }

  /* ---------------- explain ---------------- */
  if (flow === "explain") {
    return {
      flow,
      headline: lang === "hi" ? "क्षेत्र मूल्यांकन" : "REGION ASSESSMENT",
      headlineHi: "क्षेत्र मूल्यांकन",
      tone: "info",
      riskLevel: risk,
      summary:
        lang === "hi"
          ? "मौसम, महासागर रंग और खतरा डेटा के अतिव्यापी संकेत ORCA के मूल्यांकन को आकार देते हैं।"
          : "Overlapping signals from weather, ocean colour and hazard data shape ORCA's assessment of your area.",
      summaryHi: "मौसम, महासागर रंग और खतरा डेटा के अतिव्यापी संकेत ORCA के मूल्यांकन को आकार देते हैं।",
      evidence: [
        ...weatherOcean.slice(0, 2),
        ev("Marine Data", "sst", `${c.sstC} °C · ${c.sstFront}`),
        ev("Marine Data", "chl", c.chlorophyll),
        ...geoRisk,
      ],
      advisories: [lang === "hi" ? "उच्च-स्तरीय साक्ष्य सारांश — आंतरिक तर्क प्रदर्शित नहीं" : "High-level evidence summary — internal reasoning is not displayed"],
      advisoriesHi: ["उच्च-स्तरीय साक्ष्य सारांश — आंतरिक तर्क प्रदर्शित नहीं"],
      analysis: {
        intent: lang === "hi" ? "व्याख्या" : "Explainability",
        intentHi: "व्याख्या",
        sources: lang === "hi" ? "सभी विशेषज्ञ एजेंट" : "All specialist agents",
        sourcesHi: "सभी विशेषज्ञ एजेंट",
        keyEvidence: [
          `${c.sstC} °C SST · ${c.sstFront}`,
          c.chlorophyll,
          cy ? `${cy.distanceKm} km cyclone proximity` : "No cyclonic influence",
        ],
        keyEvidenceHi: [
          `${c.sstC} °C SST · ${c.sstFront}`,
          c.chlorophyll,
          cy ? `${cy.distanceKm} किमी चक्रवात दूरी` : "कोई चक्रवाती प्रभाव नहीं",
        ],
        conclusion: lang === "hi" ? (risk === "high" ? "उच्च जोखिम क्षेत्र" : "मिश्रित संकेत") : risk === "high" ? "Elevated-risk area" : "Mixed signals",
        conclusionHi: risk === "high" ? "उच्च जोखिम क्षेत्र" : "मिश्रित संकेत",
      },
      map: { view: "conditions", center: loc.center, zoom: loc.defaultZoom },
      followUps: [...followUps.explain],
    };
  }

  /* ---------------- conditions (default) ---------------- */
  const rising = c.waveHeightTomorrowM > c.waveHeightM + 0.2;
  const riskTmrw: RiskLevel =
    c.waveHeightTomorrowM >= 2.5 || c.windKmhTomorrow >= 25 ? "high" : c.waveHeightTomorrowM >= 1.8 ? "moderate" : "low";
  const h2 = RISK_HEADLINE[riskTmrw];
  return {
    flow: "conditions",
    headline: lang === "hi" ? "कल का पूर्वानुमान" : "TOMORROW'S OUTLOOK",
    headlineHi: "कल का पूर्वानुमान",
    tone: riskTmrw === "high" ? "danger" : riskTmrw === "moderate" ? "warning" : "good",
    riskLevel: riskTmrw,
    summary:
      lang === "hi"
        ? `${loc.nameHi} के पास कल सुबह का पूर्वानुमान — लहर ${c.waveHeightM} → ${c.waveHeightTomorrowM} मी, हवा ${c.windKmh} → ${c.windKmhTomorrow} किमी/घं।`
        : `Forecast for tomorrow morning near ${loc.name} — waves ${c.waveHeightM} → ${c.waveHeightTomorrowM} m, wind ${c.windKmh} → ${c.windKmhTomorrow} km/h.`,
    summaryHi: `${loc.nameHi} के पास कल सुबह का पूर्वानुमान — लहर ${c.waveHeightM} → ${c.waveHeightTomorrowM} मी, हवा ${c.windKmh} → ${c.windKmhTomorrow} किमी/घं।`,
    evidence: [
      ev("Weather & Ocean", "wave", `${c.waveHeightM} → ${c.waveHeightTomorrowM} m ${rising ? "(rising)" : "(steady)"}`, rising ? "warning" : "good", `${c.waveHeightM} → ${c.waveHeightTomorrowM} m`),
      ev("Weather & Ocean", "wind", `${c.windKmh} → ${c.windKmhTomorrow} km/h ${c.windDir}`, c.windKmhTomorrow >= 25 ? "danger" : "neutral", `${c.windKmh} → ${c.windKmhTomorrow} km/h`),
      ...(cy
        ? [ev("Geospatial & Risk", "cyclone", `${cy.distanceKm} km ${cy.bearing}`, cy.distanceKm <= 120 ? "danger" : "neutral")]
        : [ev("Geospatial & Risk", "cyclone", lang === "hi" ? "कोई नहीं" : "None", "good")]),
      ev("Weather & Ocean", "sst", `${c.sstC} °C`),
      ev("Marine Data", "advisory", advisoryText, c.advisory === "active" ? "warning" : "neutral"),
      ev("Marine Data", "tide", c.tide),
    ],
    advisories:
      riskTmrw === "high"
        ? [lang === "hi" ? "दोपहर से पहले कोई सुरक्षित खिड़की नहीं" : "No safe window before noon"]
        : [lang === "hi" ? "सुबह की खिड़की उपयुक्त दिखती है" : "Morning window looks workable"],
    advisoriesHi:
      riskTmrw === "high" ? ["दोपहर से पहले कोई सुरक्षित खिड़की नहीं"] : ["सुबह की खिड़की उपयुक्त दिखती है"],
    analysis: {
      intent: lang === "hi" ? "पूर्वानुमान सारांश" : "Forecast summary",
      intentHi: "पूर्वानुमान सारांश",
      sources: lang === "hi" ? "मौसम + सागर + सलाहकार डेटा" : "Weather + Ocean + Advisory feeds",
      sourcesHi: "मौसम + सागर + सलाहकार डेटा",
      keyEvidence: [
        `waves ${c.waveHeightM} → ${c.waveHeightTomorrowM} m`,
        `wind ${c.windKmh} → ${c.windKmhTomorrow} km/h`,
        cy ? `${cy.distanceKm} km cyclone proximity` : "no cyclone",
      ],
      keyEvidenceHi: [
        `लहर ${c.waveHeightM} → ${c.waveHeightTomorrowM} मी`,
        `हवा ${c.windKmh} → ${c.windKmhTomorrow} किमी/घं`,
        cy ? `${cy.distanceKm} किमी चक्रवात` : "कोई चक्रवात नहीं",
      ],
      conclusion: h2.en.toLowerCase(),
      conclusionHi: h2.hi,
    },
    map: { view: "conditions", center: loc.center, zoom: loc.defaultZoom },
    followUps: [...followUps.conditions],
  };
}

/* Guided demo script (§31) */
export const DEMO_SEQUENCE: { query: string; en: string; hi: string }[] = [
  { query: "Is it safe to go fishing tomorrow?", en: "Is it safe to go fishing tomorrow?", hi: "कल मछली पकड़ने जाना सुरक्षित है?" },
  { query: "Nearest safer fishing zone?", en: "Nearest safer fishing zone?", hi: "नज़दीकी सुरक्षित मत्स्य क्षेत्र?" },
];
