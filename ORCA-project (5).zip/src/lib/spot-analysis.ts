import type { HazardZone, MarineLocation, PFZZone, SafeZone } from "@/types/marine";
import type { LiveMapData } from "@/services/orca/query-service";

/**
 * Spot-level marine analysis for map taps.
 * Given any tapped lat/lng, derives a localized safety verdict.
 *  - demo mode: mock zones + deterministic spatial jitter (DEMO DATA)
 *  - live mode: real model snapshot + official geometry; NO jitter, NO
 *    invented zones. Missing marine data ⇒ verdict "unknown".
 */

export type SpotVerdict = "unsafe" | "restricted" | "caution" | "safe" | "unknown";
export type SpotMode = "demo" | "live";

export interface SpotFacts {
  lat: number;
  lng: number;
  verdict: SpotVerdict;
  mode: SpotMode;
  waveM: number | null;
  windKmh: number | null;
  windDir: string;
  sstC: number | null;
  visKm: number | null;
  distFromVesselKm: number;
  bearingFromVessel: string;
  insideHazard: HazardZone | null;
  insideSafe: SafeZone | null;
  insidePFZ: PFZZone | null;
  cyInside: boolean;
  cyNear: boolean;
  cyDistKm: number | null;
  cyName: string | null;
  cyCategory: string | null;
  cyMovement: string | null;
  cyMovementHi: string | null;
  beyondBoundary: boolean;
  boundaryDistKm: number;
  openSea: boolean;
}

const toRad = (d: number) => (d * Math.PI) / 180;
const EARTH_KM = 6371;

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

const COMPASS = [
  "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW",
];

function bearingDeg(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δλ = toRad(lng2 - lng1);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (Math.atan2(y, x) * 180) / Math.PI;
}

function compass(deg: number): string {
  return COMPASS[Math.round((((deg % 360) + 360) % 360) / 22.5) % 16];
}

/* Deterministic 0..1 hash from coordinates — stable per spot, no Math.random */
function hash01(lat: number, lng: number, salt: number): number {
  const v = Math.sin(lat * 12.9898 + lng * 78.233 + salt * 37.719) * 43758.5453;
  return v - Math.floor(v);
}

/* Ray-casting point-in-polygon. Polygon rings are [lat, lng] pairs. */
export function pointInPolygon(lat: number, lng: number, poly: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    const intersect = yi > lng !== yj > lng && lat < ((xj - xi) * (lng - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

/* Equirectangular projection to km, valid for the small regional extent used here */
function projKm(lat: number, lng: number, lat0: number): { x: number; y: number } {
  return {
    x: lng * 111.32 * Math.cos(toRad(lat0)),
    y: lat * 110.57,
  };
}

function segDistSide(
  px: number, py: number, ax: number, ay: number, bx: number, by: number
): { dist: number; side: number } {
  const dx = bx - ax;
  const dy = by - ay;
  const len2 = dx * dx + dy * dy || 1e-9;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
  const cx = ax + t * dx;
  const cy = ay + t * dy;
  const dist = Math.hypot(px - cx, py - cy);
  const side = Math.sign(dx * (py - ay) - dy * (px - ax)) || 0;
  return { dist, side };
}

/**
 * Offshore boundary check: if the tapped point sits on the seaward side of
 * the nearest boundary segment (opposite side from the monitoring center),
 * treat it as beyond the approximate boundary.
 */
function boundaryCheck(
  loc: MarineLocation,
  lat: number,
  lng: number
): { beyond: boolean; distKm: number } {
  const pts = loc.boundary.points;
  const lat0 = lat;
  const p = projKm(lat, lng, lat0);
  const c = projKm(loc.center.lat, loc.center.lng, lat0);
  let minDist = Infinity;
  let sidePt = 0;
  let sideCenter = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = projKm(pts[i][0], pts[i][1], lat0);
    const b = projKm(pts[i + 1][0], pts[i + 1][1], lat0);
    const rPt = segDistSide(p.x, p.y, a.x, a.y, b.x, b.y);
    if (rPt.dist < minDist) {
      minDist = rPt.dist;
      sidePt = rPt.side;
      sideCenter = segDistSide(c.x, c.y, a.x, a.y, b.x, b.y).side;
    }
  }
  const beyond =
    sidePt !== 0 && sideCenter !== 0 && sidePt !== sideCenter && minDist < 60;
  return { beyond, distKm: Math.round(minDist) };
}

export function analyzeSpot(loc: MarineLocation, lat: number, lng: number): SpotFacts {
  const c = loc.conditions;
  const cy = loc.cyclone;

  /* zone membership */
  const insideHazard =
    loc.hazardZones.find(
      (h) => haversineKm(lat, lng, h.center.lat, h.center.lng) <= h.radiusKm
    ) ?? null;
  const insideSafe =
    loc.safeZones.find(
      (s) => haversineKm(lat, lng, s.center.lat, s.center.lng) <= s.radiusKm
    ) ?? null;
  const insidePFZ = loc.pfzZones.find((p) => pointInPolygon(lat, lng, p.polygon)) ?? null;

  /* cyclone influence */
  let cyDistKm: number | null = null;
  let cyInside = false;
  let cyNear = false;
  if (cy) {
    cyDistKm = haversineKm(lat, lng, cy.center.lat, cy.center.lng);
    cyInside = cyDistKm <= cy.influenceRadiusKm;
    cyNear = !cyInside && cyDistKm <= 160;
  }

  /* boundary */
  const bd = boundaryCheck(loc, lat, lng);
  const nearBoundary = !bd.beyond && bd.distKm <= 8;

  /* spatially varied conditions (deterministic per spot) */
  const sheltered = insideSafe != null;
  const j = (salt: number) => hash01(lat, lng, salt);

  const waveRaw =
    c.waveHeightM +
    (cyInside ? 1.5 : cyNear ? 0.6 : 0) -
    (sheltered ? 0.6 : 0) +
    (j(1) - 0.5) * 0.5;
  const waveM = Math.max(0.3, Math.round(waveRaw * 10) / 10);

  const windRaw =
    c.windKmh +
    (cyInside ? 14 : cyNear ? 6 : 0) -
    (sheltered ? 5 : 0) +
    (j(2) - 0.5) * 8;
  const windKmh = Math.max(4, Math.round(windRaw));

  const sstC =
    Math.round((c.sstC + (j(3) - 0.5) * 0.8 - (insidePFZ ? 0.4 : 0)) * 10) / 10;

  const visRaw =
    c.visibilityKm +
    (sheltered ? 1 : 0) -
    (cyInside ? 2.5 : cyNear ? 1 : 0) +
    (j(4) - 0.5) * 1.6;
  const visKm = Math.max(1, Math.min(12, Math.round(visRaw * 10) / 10));

  /* verdict — worst-case dominates */
  let verdict: SpotVerdict;
  if (insideHazard || cyInside || waveM >= 3 || windKmh >= 30) {
    verdict = "unsafe";
  } else if (bd.beyond) {
    verdict = "restricted";
  } else if (cyNear || nearBoundary || waveM >= 2 || windKmh >= 20) {
    verdict = "caution";
  } else {
    verdict = "safe";
  }

  const v = loc.vessel.position;
  const distFromVesselKm = haversineKm(lat, lng, v.lat, v.lng);
  const bearingFromVessel = compass(bearingDeg(v.lat, v.lng, lat, lng));

  const openSea =
    !insideHazard && !insideSafe && !insidePFZ && !cyInside && !cyNear && !bd.beyond && !nearBoundary;

  return {
    lat,
    lng,
    verdict,
    mode: "demo" as const,
    waveM,
    windKmh,
    windDir: c.windDir,
    sstC,
    visKm,
    distFromVesselKm: Math.round(distFromVesselKm * 10) / 10,
    bearingFromVessel,
    insideHazard,
    insideSafe,
    insidePFZ,
    cyInside,
    cyNear,
    cyDistKm: cyDistKm != null ? Math.round(cyDistKm) : null,
    cyName: cy ? cy.name : null,
    cyCategory: cy ? cy.category : null,
    cyMovement: cy ? cy.movement : null,
    cyMovementHi: cy ? cy.movementHi : null,
    beyondBoundary: bd.beyond,
    boundaryDistKm: bd.distKm,
    openSea,
  };
}

/* ------------------------------------------------------------------ */
/* LIVE spot analysis — real model snapshot, no jitter, no fake zones   */
/* ------------------------------------------------------------------ */

export function analyzeSpotLive(
  live: LiveMapData,
  loc: MarineLocation,
  lat: number,
  lng: number
): SpotFacts {
  const waveM = live.conditions.waveHeightM;
  const windKmh =
    live.conditions.windMps != null ? Math.round(live.conditions.windMps * 3.6) : null;
  const sstC = live.conditions.sstC;
  const visKm = live.conditions.visibilityKm;

  /* official PFZ geometry membership */
  const insidePFZ: PFZZone | null =
    live.pfz?.find((p) => pointInPolygon(lat, lng, p.polygon)) ?? null;

  /* real cyclone (IMD) proximity */
  const cy = live.cyclone;
  let cyDistKm: number | null = null;
  let cyInside = false;
  let cyNear = false;
  if (cy) {
    cyDistKm = haversineKm(lat, lng, cy.center.lat, cy.center.lng);
    cyInside = cyDistKm <= (cy.influenceRadiusKm ?? 55);
    cyNear = !cyInside && cyDistKm <= 160;
  }

  /* boundary (prototype geofence, labeled approx.) */
  const bd = boundaryCheck(loc, lat, lng);
  const nearBoundary = !bd.beyond && bd.distKm <= 8;

  /* verdict — generic prototype policy thresholds */
  let verdict: SpotVerdict;
  if (waveM == null && windKmh == null) {
    verdict = "unknown";
  } else if (cyInside || (waveM != null && waveM >= 3) || (windKmh != null && windKmh >= 30)) {
    verdict = "unsafe";
  } else if (bd.beyond) {
    verdict = "restricted";
  } else if (
    cyNear ||
    nearBoundary ||
    (waveM != null && waveM >= 2) ||
    (windKmh != null && windKmh >= 20)
  ) {
    verdict = "caution";
  } else {
    verdict = "safe";
  }

  const v = loc.center;
  const distFromVesselKm = haversineKm(lat, lng, v.lat, v.lng);
  const bearingFromVessel = compass(bearingDeg(v.lat, v.lng, lat, lng));

  const openSea =
    !insidePFZ && !cyInside && !cyNear && !bd.beyond && !nearBoundary && verdict === "safe";

  return {
    lat,
    lng,
    verdict,
    mode: "live" as const,
    waveM,
    windKmh,
    windDir: live.conditions.windDir ?? "—",
    sstC,
    visKm,
    distFromVesselKm: Math.round(distFromVesselKm * 10) / 10,
    bearingFromVessel,
    insideHazard: null,
    insideSafe: null,
    insidePFZ,
    cyInside,
    cyNear,
    cyDistKm: cyDistKm != null ? Math.round(cyDistKm) : null,
    cyName: cy ? cy.name : null,
    cyCategory: cy ? cy.category : null,
    cyMovement: cy ? cy.movement : null,
    cyMovementHi: null,
    beyondBoundary: bd.beyond,
    boundaryDistKm: bd.distKm,
    openSea,
  };
}
