import type { ChatMessage, OrcaResponse } from "@/types/orca";
import type { Lang } from "@/lib/i18n";

/**
 * Speech composition helpers for ORCA voice briefings.
 * Turns structured chat messages into clean, speakable plain text.
 */

export function cleanForSpeech(raw: string): string {
  return raw
    .replace(
      /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{2B00}-\u{2BFF}\u{2190}-\u{21FF}]/gu,
      " "
    )
    .replace(/[*_#`>|~·•▪►]/g, " ")
    .replace(/°C/gi, " degrees Celsius ")
    .replace(/°/g, " degrees ")
    .replace(/%/g, " percent ")
    .replace(/&/g, " and ")
    .replace(/(\d(?:\.\d+)?)\s*km\/h\b/gi, "$1 kilometers per hour")
    .replace(/(\d(?:\.\d+)?)\s*km\b/gi, "$1 kilometers")
    .replace(/(\d(?:\.\d+)?)\s*m(?![a-zA-Z])/g, "$1 meters")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Build the spoken text for a chat message.
 * Returns "" for dividers and non-speakable roles.
 */
export function orcaSpeakText(msg: ChatMessage, lang: Lang): string {
  const hi = lang === "hi";

  if (msg.divider) return "";

  if (msg.role === "system") {
    return cleanForSpeech((hi && msg.textHi ? msg.textHi : msg.text) ?? "");
  }

  if (msg.response) {
    const r: OrcaResponse = msg.response;
    const parts = [
      hi ? r.headlineHi : r.headline,
      hi ? r.summaryHi : r.summary,
    ];
    const advisories = (hi ? r.advisoriesHi : r.advisories).slice(0, 2);
    if (advisories.length > 0) parts.push(advisories.join(". "));
    return cleanForSpeech(parts.filter(Boolean).join(". "));
  }

  if (msg.role === "orca") {
    return cleanForSpeech((hi && msg.textHi ? msg.textHi : msg.text) ?? "");
  }

  return "";
}
