import L from "leaflet";

/* Leaflet div-icon factories — client-only (imported inside dynamically loaded map). */

export const ICON_PALETTE = {
  hazardFill: "#c2410c",
  cycloneFill: "#b91c1c",
  pfzFill: "#0f766e",
  safeFill: "#15803d",
  route: "#0e7490",
  boundary: "#8296a3",
  sea: "#2f6f95",
};

function vesselSvg(deg: number) {
  return `
  <div class="vessel-wrap">
    <span class="pulse-ring"></span>
    <div class="vessel-pin" style="transform: rotate(${deg}deg)">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff" stroke="none" style="transform: rotate(-90deg)">
        <path d="M12 2 L19 21 L12 17 L5 21 Z"/>
      </svg>
    </div>
  </div>`;
}

export function vesselIcon(deg: number) {
  return L.divIcon({
    html: vesselSvg(deg),
    className: "",
    iconSize: [34, 34],
    iconAnchor: [17, 17],
  });
}

export function cycloneIcon() {
  return L.divIcon({
    html: `
    <div class="cyclone-pin">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <circle cx="12" cy="12" r="2.4" fill="currentColor" stroke="none"/>
        <path d="M12 2.5a9.5 9.5 0 0 1 9.5 9.5"/>
        <path d="M12 21.5A9.5 9.5 0 0 1 2.5 12"/>
        <path d="M17.8 6.2 21.5 12l-6.8 1.2"/>
        <path d="M6.2 17.8 2.5 12l6.8-1.2"/>
      </svg>
    </div>`,
    className: "",
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  });
}

export function flagIcon() {
  return L.divIcon({
    html: `
    <div class="flag-pin">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
        <line x1="4" x2="4" y1="22" y2="15"/>
      </svg>
    </div>`,
    className: "",
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
}

function arrowIcon(deg: number, color: string, size: number, label?: string) {
  return L.divIcon({
    html: `
    <div style="display:flex;flex-direction:column;align-items:center;gap:1px;">
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" style="transform: rotate(${deg}deg)" fill="none" stroke="${color}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 19V5"/><path d="m5 12 7-7 7 7"/>
      </svg>
      ${label ? `<span style="font-size:9px;font-weight:600;color:#40525e;background:rgba(255,255,255,.9);border:1px solid #d9e3e8;border-radius:4px;padding:0 4px;white-space:nowrap;">${label}</span>` : ""}
    </div>`,
    className: "",
    iconSize: [size, size + 14],
    iconAnchor: [size / 2, size / 2],
  });
}

export function seaArrowIcon(deg: number, label: string) {
  return arrowIcon(deg, ICON_PALETTE.sea, 18, label);
}

export function windArrowIcon(deg: number) {
  return arrowIcon(deg, "#a1352c", 15);
}
