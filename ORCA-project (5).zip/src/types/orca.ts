import type { LatLng, RiskLevel } from "./marine";

export type AgentId =
  | "weatherOcean"
  | "geospatialRisk"
  | "dataDiscovery"
  | "synthesis";
export type AgentState = "pending" | "active" | "complete";

export interface AgentStatus {
  id: AgentId;
  name: string;
  nameHi: string;
  state: AgentState;
}

export type EvidenceCategory = "Weather & Ocean" | "Geospatial & Risk" | "Marine Data";

export interface EvidenceItem {
  category: EvidenceCategory;
  label: string;
  labelHi: string;
  value: string;
  /** compact value for the verdict card grid (full value stays in evidence panel) */
  short?: string;
  tone?: "danger" | "warning" | "good" | "neutral";
}

export type FlowId = "safety" | "pfz" | "hazard" | "route" | "conditions" | "explain";

export type MapViewId = "default" | "safety" | "pfz" | "hazard" | "route" | "conditions";

export type Tone = "danger" | "warning" | "good" | "info";

export interface OrcaMapAction {
  view: MapViewId;
  center: LatLng;
  zoom: number;
}

export interface AnalysisSummaryData {
  intent: string;
  intentHi: string;
  sources: string;
  sourcesHi: string;
  keyEvidence: string[];
  keyEvidenceHi: string[];
  conclusion: string;
  conclusionHi: string;
}

export interface OrcaResponse {
  flow: FlowId;
  headline: string;
  headlineHi: string;
  tone: Tone;
  summary: string;
  summaryHi: string;
  riskLevel: RiskLevel;
  evidence: EvidenceItem[];
  advisories: string[];
  advisoriesHi: string[];
  analysis: AnalysisSummaryData;
  map: OrcaMapAction;
  followUps: { en: string; hi: string }[];
  /** live-mode provenance: per-source metadata (server-provided) */
  sources?: import("@/services/marine/types").SourceMeta[];
  /** live-mode data quality flag */
  dataQuality?: import("@/services/marine/types").DataQuality;
}

export type ChatRole = "user" | "orca" | "system";

export interface ChatMessage {
  id: string;
  role: ChatRole;
  /** plain text message (user / orca brief / system divider) */
  text?: string;
  textHi?: string;
  /** divider label, e.g. "Monitoring switched to Goa Coast" */
  divider?: string;
  response?: OrcaResponse;
  ts: number;
}

export type StepState = "pending" | "active" | "done" | "warn" | "fail";

export interface ProcessingState {
  step: number; // demo mode: 0..5 timeline
  query: string;
  /** which pipeline produced the step statuses */
  mode: "demo" | "live";
  /** live mode: per-step real statuses (§19) — demo mode uses the timeline */
  steps?: StepState[];
}

export interface MarineAlertData {
  id: string;
  title: string;
  titleHi: string;
  body: string;
  bodyHi: string;
  center: LatLng;
  ts: number;
  read: boolean;
  /** live alerts originate from an official source (IMD) — not simulated */
  live?: boolean;
  /** alert content is a clearly-labeled demo substitute (source not configured) */
  demo?: boolean;
  sourceLabel?: string;
}

export interface AppToast {
  id: string;
  kind: "ok" | "info" | "alert" | "prototype";
  title: string;
  body?: string;
  /** if present, toast is an actionable alert card */
  alert?: MarineAlertData;
  ts: number;
}

export interface LayerToggles {
  vessel: boolean;
  risk: boolean;
  pfz: boolean;
  weather: boolean;
  boundaries: boolean;
  seaState: boolean;
}
