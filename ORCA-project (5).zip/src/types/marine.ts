export type RiskLevel = "low" | "moderate" | "high";
export type AdvisoryStatus = "active" | "watch" | "none";
export type BoundaryStatus = "clear" | "near" | "restricted";

export interface LatLng {
  lat: number;
  lng: number;
}

export interface HazardZone {
  id: string;
  label: string;
  labelHi: string;
  center: LatLng;
  radiusKm: number;
  reason: string;
  reasonHi: string;
}

export interface SafeZone {
  id: string;
  label: string;
  labelHi: string;
  center: LatLng;
  radiusKm: number;
  note: string;
  noteHi: string;
}

export interface PFZZone {
  id: string;
  label: string;
  labelHi: string;
  /** [lat, lng] ring */
  polygon: [number, number][];
  center: LatLng;
  distanceKm: number;
  bearing: string;
  sstFront: string;
  chlorophyll: string;
  likelySpecies: string[];
}

export interface CycloneInfo {
  name: string;
  category: string;
  center: LatLng;
  distanceKm: number;
  bearing: string;
  influenceRadiusKm: number;
  movement: string;
  movementHi: string;
  /** simulated demo cyclone (IMD not connected) — labeled in the UI */
  demo?: boolean;
}

export interface Conditions {
  waveHeightM: number;
  waveHeightTomorrowM: number;
  windKmh: number;
  windKmhTomorrow: number;
  windDir: string;
  gustKmh: number;
  sstC: number;
  sstFront: string;
  chlorophyll: string;
  visibilityKm: number;
  tide: string;
  advisory: AdvisoryStatus;
  boundaryStatus: BoundaryStatus;
}

export interface SeaArrow {
  position: LatLng;
  dirDeg: number;
  label: string;
}

export interface WindArrow {
  position: LatLng;
  dirDeg: number;
}

export interface BoundaryLine {
  points: [number, number][];
  label: string;
  labelHi: string;
}

export interface RoutePath {
  points: [number, number][];
  distanceKm: number;
  etaHours: number;
  clearanceKm: number;
  destination: string;
  destinationHi: string;
}

export interface MarineLocation {
  id: string;
  name: string;
  nameHi: string;
  state: string;
  stateHi: string;
  region: "Arabian Sea" | "Bay of Bengal";
  regionHi: string;
  center: LatLng;
  defaultZoom: number;
  vessel: {
    position: LatLng;
    name: string;
    type: string;
    headingDeg: number;
  };
  conditions: Conditions;
  cyclone: CycloneInfo | null;
  hazardZones: HazardZone[];
  safeZones: SafeZone[];
  pfzZones: PFZZone[];
  route: RoutePath;
  boundary: BoundaryLine;
  seaArrows: SeaArrow[];
  windArrows: WindArrow[];
}
