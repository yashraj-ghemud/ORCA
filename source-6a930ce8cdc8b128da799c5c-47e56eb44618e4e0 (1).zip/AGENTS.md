# AGENTS.md

## Project

ORCA — Marine Ecosystem Reasoning with Collaborative Agents. A frontend prototype of a conversational marine intelligence workspace: an interactive ocean map paired with a chat-driven, simulated multi-agent reasoning pipeline. All data is mocked; the UI carries "DEMO DATA" badges throughout.

## Stack

- Next.js (App Router) + TypeScript
- Tailwind CSS + shadcn/ui (Radix primitives) for components
- Leaflet with an Esri Ocean basemap for the map view
- Zustand (`src/lib/store.ts`) for client state

## Key directories

- `src/app` — routes; `page.tsx` renders the `OrcaWorkspace` root component
- `src/components/workspace` — top-level workspace layout tying map, chat, and evidence panels together
- `src/components/map` — Leaflet map and marine overlay components
- `src/components/chat` — conversational UI for the simulated agent pipeline
- `src/components/evidence` / `src/components/alerts` — supporting panels for the reasoning workflow
- `src/components/intro` — onboarding/intro screens
- `src/components/ui` — shadcn/ui primitives
- `src/lib/mock-marine-data.ts`, `src/lib/mock-orca.ts` — simulated datasets driving the demo
- `src/lib/i18n.ts` — copy/translation strings
- `src/types` — shared TypeScript types for marine and orca domain models

## Non-obvious decisions

- `prisma/` and `src/lib/db.ts` exist but are unused dead code from the starter template — no route or component imports them. There is no live database; do not wire up features to Prisma without first setting up a real Netlify Database (see the `netlify-database` skill).
- `next.config.ts` intentionally does not set `output: "standalone"` — Netlify's Next.js runtime manages the build/runtime output itself.
- Map tiles are fetched from Esri at runtime, so the map view requires network access even in local dev.
