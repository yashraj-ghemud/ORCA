"use client";

/**
 * ORCA — Cinematic intro choreography helpers.
 *
 * The intro is a store-driven phase machine (boot → playing → assembly →
 * done). Shell elements subscribe through `useIntroGate`, which hands them
 * a `shown` flag plus calibrated delays: the full cinematic cascade on
 * first play, a compressed version on repeat loads (fast path).
 *
 * Hydration safety: initial render is deterministic on server and client
 * (everything hidden during `boot`); every viewport/visibility decision
 * happens after mount.
 */

import { useOrcaStore } from "@/lib/store";

/** sessionStorage flag — the full cinematic plays once per browser session. */
export const INTRO_SEEN_KEY = "orca.intro.seen";

/** Assembly delays (seconds) — full cinematic vs fast repeat-visit path. */
export function introDelay(fast: boolean, full: number): number {
  return fast ? Math.max(0.02, full * 0.32) : full;
}

export function useIntroGate() {
  const phase = useOrcaStore((s) => s.introPhase);
  const fast = useOrcaStore((s) => s.introFast);
  return {
    /** True once the overlay lifts and the assembly cascade may run. */
    shown: phase === "assembly" || phase === "done",
    /** True while the cinematic overlay is on stage. */
    playing: phase === "playing",
    fast,
    phase,
  };
}

/** Shared spring for elements landing during the assembly. */
export const ASSEMBLY_SPRING = { type: "spring", stiffness: 380, damping: 26 } as const;

/** Cinematic ease used across entrances. */
export const EASE_CINEMA = [0.22, 1, 0.36, 1] as const;
