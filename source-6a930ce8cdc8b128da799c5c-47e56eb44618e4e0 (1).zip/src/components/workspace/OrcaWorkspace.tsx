"use client";

/**
 * ORCA — Workspace shell: header + (conversation | marine map) split.
 * Owns the responsive layout, floating map furniture, proactive alert
 * timing, toasts and the evidence drawer.
 *
 * During the cinematic intro every shell element sits hidden; when the
 * overlay lifts (phase → assembly) the whole workspace builds itself in
 * a choreographed cascade — chat rises, the map wipes in, furniture
 * cascades from its edges, and the map hint floats in last.
 */

import { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import { CheckCircle2, Info, TriangleAlert, X } from "lucide-react";
import { TopHeader } from "./TopHeader";
import { ChatPanel } from "@/components/chat/ChatPanel";
import { MapLayersPanel, MapQuickActions, MapLegend } from "@/components/map/MapControls";
import { EvidenceDrawer } from "@/components/evidence/EvidenceDrawer";
import { AlertToast } from "@/components/alerts/AlertToast";
import { OceanRibbon } from "@/components/intro/OceanRibbon";
import { SonarDome3D } from "@/components/intro/SonarDome3D";
import { CinematicIntro } from "@/components/intro/CinematicIntro";
import { useOrcaStore } from "@/lib/store";
import { t } from "@/lib/i18n";
import { buildRegionAlert } from "@/lib/store";
import { useIntroGate, introDelay, EASE_CINEMA } from "@/lib/intro";
import { useReducedMotion } from "framer-motion";
import type { Language } from "@/types/orca";

const MarineMap = dynamic(() => import("@/components/map/MarineMap"), {
  ssr: false,
  loading: () => (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-[#dce9f2]">
      {/* A living 3D sea while the chart boots */}
      <OceanRibbon className="absolute inset-x-0 bottom-0 h-[46%] w-full opacity-70" />
      {/* Sonar sweep above the ribbon */}
      <span className="logo-ping rounded-full" style={{ inset: "auto", width: 120, height: 120, position: "absolute", border: "1.5px solid rgba(74,122,150,.55)" }} aria-hidden />
      <span className="logo-ping rounded-full" style={{ inset: "auto", width: 120, height: 120, position: "absolute", border: "1.5px solid rgba(74,122,150,.35)", animationDelay: "1.4s" }} aria-hidden />
      <div className="relative flex items-center gap-2 text-[12px] font-medium text-[#4A7A96]">
        <span className="stage-spin inline-block h-4 w-4 rounded-full border-2 border-[#4A7A96] border-t-transparent" />
        Loading marine chart…
      </div>
    </div>
  ),
});

/* ── Toasts ────────────────────────────────────────────────── */

function ToastStack() {
  const toasts = useOrcaStore((s) => s.toasts);
  const dismiss = useOrcaStore((s) => s.dismissToast);
  const language = useOrcaStore((s) => s.language);
  const activeResponse = useOrcaStore((s) => s.activeResponse);

  const ICONS = {
    info: Info,
    success: CheckCircle2,
    warn: TriangleAlert,
    danger: TriangleAlert,
  } as const;
  const TONES = {
    info: "text-ocean-blue",
    success: "text-ocean-success",
    warn: "text-ocean-warn-fg",
    danger: "text-ocean-danger-fg",
  } as const;

  if (toasts.length === 0) return null;
  return (
    <div
      className="pointer-events-none absolute left-1/2 z-[900] flex -translate-x-1/2 flex-col items-center gap-2 transition-all duration-300"
      style={{ bottom: activeResponse ? 240 : 20 }}
    >
      {toasts.map((toast, i) => {
        const Icon = ICONS[toast.tone];
        return (
          <motion.div
            key={toast.id}
            role="status"
            initial={{ opacity: 0, y: -22, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ type: "spring", stiffness: 460, damping: 26, delay: i * 0.06 }}
            whileHover={{ scale: 1.03, y: -1 }}
            className="pointer-events-auto flex items-center gap-2.5 rounded-full border border-ocean-line bg-white/97 py-2 pl-3.5 pr-2 shadow-[0_4px_18px_rgba(23,35,45,0.14)]"
          >
            <span className="pop-in">
              <Icon className={`h-4 w-4 shrink-0 ${TONES[toast.tone]}`} strokeWidth={2.1} />
            </span>
            <span className="text-[12.5px] font-medium text-ocean-ink">{toast.title}</span>
            {toast.description && (
              <span className="text-[12px] text-ocean-slate">· {toast.description}</span>
            )}
            <button
              type="button"
              onClick={() => dismiss(toast.id)}
              aria-label="Dismiss"
              className="ml-1 flex h-5 w-5 items-center justify-center rounded-full text-ocean-slate transition-colors hover:bg-ocean-bg"
            >
              <X className="h-3 w-3" strokeWidth={2.4} />
            </button>
            <span className="sr-only">{language === "hi" ? "सूचना" : "notification"}</span>
          </motion.div>
        );
      })}
    </div>
  );
}

/* ── Map empty-state hint ──────────────────────────────────── */

function MapHint({ language }: { language: Language }) {
  const messages = useOrcaStore((s) => s.messages.length);
  const activeResponse = useOrcaStore((s) => s.activeResponse);
  const { shown, fast } = useIntroGate();
  if (messages > 0 || activeResponse) return null;
  return (
    <motion.div
      className="pointer-events-none absolute left-1/2 top-[56px] z-[500] -translate-x-1/2 lg:top-4"
      initial={{ opacity: 0, y: -14, scale: 0.92 }}
      animate={shown ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: -14, scale: 0.92 }}
      transition={{ delay: introDelay(fast, 3.55), type: "spring", stiffness: 380, damping: 24 }}
    >
      <div className="drift-soft flex items-center gap-2.5 rounded-full border border-ocean-line bg-white/95 px-4 py-2 shadow-[0_2px_12px_rgba(23,35,45,0.10)] backdrop-blur-[2px]">
        <span className="soft-blink h-1.5 w-1.5 rounded-full bg-ocean-blue" />
        <span className="text-[12px] font-medium text-ocean-ink/85">{t(language, "selectQueryHint")}</span>
      </div>
    </motion.div>
  );
}

/* ── Workspace ─────────────────────────────────────────────── */

export function OrcaWorkspace() {
  const language = useOrcaStore((s) => s.language);
  const activeAlert = useOrcaStore((s) => s.activeAlert);
  const demoMode = useOrcaStore((s) => s.demoMode);
  const raiseAlert = useOrcaStore((s) => s.raiseAlert);
  const activeResponse = useOrcaStore((s) => s.activeResponse);
  const { shown, fast } = useIntroGate();
  const reduced = useReducedMotion();
  const [proactiveFired, setProactiveFired] = useState(false);

  /* ── Assembly storyline beats (full) / compressed (fast) ──
     0.55 chart power-on → header collision → 1.9 comms deck
     → 2.9 instruments dock → 3.9 systems sweep finale */
  const dMap = introDelay(fast, 0.55);
  const dGridFlash = introDelay(fast, 0.72);
  const dWipe = introDelay(fast, 1.15);
  const dChat = introDelay(fast, 1.9);
  const dFurniture = introDelay(fast, 2.9);
  const dSweep = introDelay(fast, 3.9);

  /* Proactive alert — fires once, ~45s into the session, only in demo mode */
  useEffect(() => {
    if (!demoMode || proactiveFired) return;
    const timer = window.setTimeout(() => {
      if (useOrcaStore.getState().demoMode) {
        raiseAlert(buildRegionAlert(useOrcaStore.getState().regionId));
        setProactiveFired(true);
      }
    }, 45_000);
    return () => window.clearTimeout(timer);
  }, [demoMode, proactiveFired, raiseAlert]);

  /* QA/demo hook — lets scripted demos trigger the alert on demand */
  useEffect(() => {
    (window as unknown as { __orca?: object }).__orca = {
      fireAlert: () => raiseAlert(buildRegionAlert(useOrcaStore.getState().regionId)),
      store: useOrcaStore,
    };
    return () => {
      delete (window as unknown as { __orca?: object }).__orca;
    };
  }, [raiseAlert]);

  /* One-shot shimmer wipe across the map as it materialises */
  const wipe = useMemo(
    () =>
      shown ? { x: ["-130%", "130%"], opacity: [0, 1, 1, 0] } : { x: "-130%", opacity: 0 },
    [shown],
  );

  return (
    <div className="flex h-screen min-h-[560px] w-full flex-col overflow-hidden bg-ocean-bg">
      <CinematicIntro />
      <TopHeader />

      <main className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* Conversation — 35% on desktop, stacked above map on mobile.
            Beat 3 · COMMS DECK — the console rises with a 3D tilt. */}
        <motion.div
          className="relative h-[46vh] w-full shrink-0 lg:h-auto lg:w-[400px] xl:w-[430px]"
          initial={{ opacity: 0, y: 44, rotateX: 8, transformPerspective: 900 }}
          animate={shown ? { opacity: 1, y: 0, rotateX: 0, transformPerspective: 900 } : { opacity: 0, y: 44, rotateX: 8, transformPerspective: 900 }}
          transition={{ delay: dChat, type: "spring", stiffness: 240, damping: 26 }}
        >
          <ChatPanel language={language} />
          {shown && !reduced && (
            <span aria-hidden className="scan-once inset-0 z-20" style={{ "--scan-delay": "0.35s" } as React.CSSProperties} />
          )}
        </motion.div>

        {/* Marine intelligence map — dominant surface.
            Beat 1 · CHART POWER-ON — the table levels flat in 3D. */}
        <motion.div
          className="relative min-h-[54vh] flex-1 lg:min-h-0"
          initial={{ opacity: 0, scale: 1.05, rotateX: 12, transformPerspective: 1300 }}
          animate={shown ? { opacity: 1, scale: 1, rotateX: 0, transformPerspective: 1300 } : { opacity: 0, scale: 1.05, rotateX: 12, transformPerspective: 1300 }}
          transition={{ delay: dMap, duration: 0.95, ease: EASE_CINEMA }}
        >
          <MarineMap />

          {/* Chart power-on — coordinate grid flashes then dissolves */}
          {shown && !reduced && (
            <span aria-hidden className="map-grid-flash absolute inset-0 z-[640]" style={{ animationDelay: `${Math.max(0, dGridFlash - dMap)}s` }} />
          )}

          {/* Cinematic shimmer wipe */}
          <motion.div
            aria-hidden
            className="pointer-events-none absolute inset-0 z-[650]"
            style={{
              background:
                "linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.5) 50%, transparent 70%)",
            }}
            initial={{ x: "-130%", opacity: 0 }}
            animate={wipe}
            transition={{ delay: dWipe, duration: 1.05, ease: [0.22, 1, 0.36, 1], opacity: { times: [0, 0.15, 0.8, 1] } }}
          />

          {/* Live 3D sea strip — the map's own tide gauge (decorative) */}
          <span
            aria-hidden
            className="pointer-events-none absolute inset-x-0 bottom-0 z-[450] block h-[22px] opacity-60 lg:h-[30px]"
            style={{
              WebkitMaskImage: "linear-gradient(90deg, transparent 0%, #000 12%, #000 88%, transparent 100%)",
              maskImage: "linear-gradient(90deg, transparent 0%, #000 12%, #000 88%, transparent 100%)",
            }}
          >
            <OceanRibbon className="h-full w-full" />
          </span>

          {/* Floating furniture — cascades from the map edges */}
          <motion.div
            className="pointer-events-none absolute left-3 top-3 z-[600] flex flex-col gap-2"
            initial={{ opacity: 0, x: -20 }}
            animate={shown ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ delay: dFurniture, type: "spring", stiffness: 400, damping: 27 }}
          >
            <MapLayersPanel language={language} />
          </motion.div>
          <motion.div
            className="pointer-events-none absolute right-3 top-3 z-[600]"
            initial={{ opacity: 0, x: 20 }}
            animate={shown ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
            transition={{ delay: dFurniture + 0.09, type: "spring", stiffness: 400, damping: 27 }}
          >
            <MapQuickActions language={language} />
          </motion.div>
          <motion.div
            className="pointer-events-none absolute left-3 z-[600] transition-all duration-300"
            style={{ bottom: activeResponse ? 214 : 12 }}
            initial={{ opacity: 0, y: 18 }}
            animate={shown ? { opacity: 1, y: 0 } : { opacity: 0, y: 18 }}
            transition={{ delay: dFurniture + 0.18, type: "spring", stiffness: 400, damping: 27 }}
          >
            <MapLegend language={language} />
          </motion.div>

          {/* Beat 4 · INSTRUMENT — the sonar dome docks on the right rail */}
          <motion.div
            className="pointer-events-none absolute right-3 top-1/2 z-[600] -translate-y-1/2"
            initial={{ opacity: 0, scale: 0.5, rotate: -24 }}
            animate={shown ? { opacity: 1, scale: 1, rotate: 0 } : { opacity: 0, scale: 0.5, rotate: -24 }}
            transition={{ delay: dFurniture + 0.26, type: "spring", stiffness: 430, damping: 21 }}
          >
            <SonarDome3D size={72} />
          </motion.div>

          <MapHint language={language} />
          <EvidenceDrawer language={language} />
        </motion.div>
      </main>

      {/* Proactive alert toast */}
      <div className="pointer-events-none fixed right-4 top-[66px] z-[950]">
        {activeAlert && <AlertToast alert={activeAlert} language={language} />}
      </div>

      <ToastStack />

      {/* Beat 5 · ALL SYSTEMS ONLINE — one light-bar sweep + status pill */}
      {shown && !reduced && (
        <>
          <div aria-hidden className="pointer-events-none fixed inset-0 z-[1400] overflow-hidden">
            <span className="sys-sweep inset-y-0" style={{ "--sweep-delay": `${dSweep}s` } as React.CSSProperties} />
          </div>
          <motion.div
            aria-hidden
            className="pointer-events-none fixed left-1/2 top-[62px] z-[1400] -translate-x-1/2"
            initial={{ opacity: 0, y: -12, scale: 0.9 }}
            animate={{
              opacity: [0, 1, 1, 0],
              y: [-12, 0, 0, -6],
              scale: [0.9, 1, 1, 0.97],
            }}
            transition={{ delay: dSweep + 0.35, duration: 2.6, times: [0, 0.14, 0.72, 1], ease: "easeOut" }}
          >
            <span className="badge-shimmer flex items-center gap-1.5 rounded-full border border-ocean-line bg-white/95 px-3 py-1.5 shadow-[0_2px_14px_rgba(23,35,45,0.12)]">
              <span className="soft-blink h-1.5 w-1.5 rounded-full bg-ocean-success" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ocean-navy">
                All systems online
              </span>
            </span>
          </motion.div>
        </>
      )}
    </div>
  );
}
